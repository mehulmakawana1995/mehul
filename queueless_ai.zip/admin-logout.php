<?php
/**
 * QueueLess AI — Administrator Logout Handler
 */

require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/functions.php';

logoutAdmin();
setFlash('info', 'You have been safely signed out.');

header('Location: ' . BASE_URL . '/admin-login.php');
exit;
