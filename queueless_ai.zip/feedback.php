<?php
/**
 * QueueLess AI — Customer Feedback Submission
 */

$pageTitle = "Service Feedback";
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/csrf.php';
require_once __DIR__ . '/includes/functions.php';

$pdo = getDB();
$requestId = (int)($_REQUEST['request_id'] ?? 0);
$tokenNumber = trim($_REQUEST['token_number'] ?? '');

$requestData = null;
$existingFeedback = null;
$error = null;
$success = null;

// Look up request
if ($requestId > 0) {
    $stmt = $pdo->prepare("
        SELECT r.id, r.request_code, r.subject, r.status, r.created_at, r.completed_at,
               c.full_name, c.mobile_number, s.service_name, t.token_number
        FROM requests r
        JOIN customers c ON c.id = r.customer_id
        JOIN services s ON s.id = r.service_id
        LEFT JOIN tokens t ON t.request_id = r.id
        WHERE r.id = :id
        LIMIT 1
    ");
    $stmt->execute(['id' => $requestId]);
    $requestData = $stmt->fetch();
} elseif (!empty($tokenNumber)) {
    $stmt = $pdo->prepare("
        SELECT r.id, r.request_code, r.subject, r.status, r.created_at, r.completed_at,
               c.full_name, c.mobile_number, s.service_name, t.token_number
        FROM tokens t
        JOIN requests r ON r.id = t.request_id
        JOIN customers c ON c.id = r.customer_id
        JOIN services s ON s.id = r.service_id
        WHERE t.token_number = :tn
        LIMIT 1
    ");
    $stmt->execute(['tn' => $tokenNumber]);
    $requestData = $stmt->fetch();
    if ($requestData) {
        $requestId = (int)$requestData['id'];
    }
}

// Check existing feedback
if ($requestData) {
    $fbCheck = $pdo->prepare("SELECT id, rating, comments, created_at FROM feedback WHERE request_id = :rid LIMIT 1");
    $fbCheck->execute(['rid' => $requestData['id']]);
    $existingFeedback = $fbCheck->fetch();
}

// Handle POST Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $requestData) {
    $csrfToken = $_POST['csrf_token'] ?? '';
    if (!verifyCsrfToken($csrfToken)) {
        $error = 'Security session expired. Please refresh the page and submit again.';
    } elseif ($requestData['status'] !== 'Completed') {
        $error = 'Feedback can only be submitted for completed requests.';
    } elseif ($existingFeedback) {
        $error = 'Feedback has already been submitted for this request.';
    } else {
        $rating = (int)($_POST['rating'] ?? 0);
        $comments = trim($_POST['comments'] ?? '');

        if ($rating < 1 || $rating > 5) {
            $error = 'Please select a rating between 1 and 5 stars.';
        } else {
            $insertFb = $pdo->prepare("INSERT INTO feedback (request_id, rating, comments, created_at) VALUES (:rid, :r, :c, NOW())");
            $insertFb->execute([
                'rid' => $requestData['id'],
                'r'   => $rating,
                'c'   => !empty($comments) ? $comments : null
            ]);

            setFlash('success', 'Thank you! Your feedback has been recorded successfully.');
            header("Location: " . BASE_URL . "/feedback.php?request_id=" . $requestData['id']);
            exit;
        }
    }
}

require_once __DIR__ . '/includes/header.php';
?>

<div class="container section-padding" style="padding-top: 40px;">
    <div style="max-width: 680px; margin: 0 auto;">

        <div style="text-align: center; margin-bottom: 36px;">
            <span class="section-tag">Quality Assurance</span>
            <h1 style="font-size: 34px; margin-bottom: 12px;">Customer <span class="text-gradient">Feedback</span></h1>
            <p style="color: var(--text-muted); font-size: 15px;">
                Help us improve public service efficiency by rating your service experience.
            </p>
        </div>

        <?php if (!$requestData): ?>
            <!-- Lookup Form if no request was passed -->
            <div class="form-card">
                <h3 style="font-size: 18px; margin-bottom: 14px;">Find Your Completed Request</h3>
                <form action="<?php echo BASE_URL; ?>/feedback.php" method="GET">
                    <div class="form-group">
                        <label for="fb_token">Enter Your Token Number <span class="required">*</span></label>
                        <div class="input-with-icon">
                            <i class="fa-solid fa-ticket"></i>
                            <input type="text" id="fb_token" name="token_number" class="form-control" placeholder="e.g. QL-20261010-0004" required>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary btn-block">Find Request</button>
                </form>
            </div>

        <?php elseif ($existingFeedback): ?>
            <!-- Already Submitted Feedback Card -->
            <div class="form-card" style="text-align: center;">
                <div style="font-size: 48px; color: #fbbf24; margin-bottom: 14px;">
                    <?php for ($i = 1; $i <= 5; $i++): ?>
                        <i class="fa-solid fa-star" style="color: <?php echo $i <= $existingFeedback['rating'] ? '#fbbf24' : 'rgba(255,255,255,0.1)'; ?>;"></i>
                    <?php endfor; ?>
                </div>
                <h2 style="font-size: 24px; margin-bottom: 8px;">Feedback Already Submitted</h2>
                <p style="color: var(--text-muted); font-size: 14px; margin-bottom: 20px;">
                    You rated this service <strong><?php echo $existingFeedback['rating']; ?> out of 5 stars</strong> on <?php echo formatDateTime($existingFeedback['created_at']); ?>.
                </p>
                <?php if (!empty($existingFeedback['comments'])): ?>
                    <div style="background: rgba(255,255,255,0.03); border: 1px solid var(--border-subtle); border-radius: var(--radius-sm); padding: 16px; font-style: italic; color: #cbd5e1; margin-bottom: 24px;">
                        "<?php echo htmlspecialchars($existingFeedback['comments']); ?>"
                    </div>
                <?php endif; ?>
                <a href="<?php echo BASE_URL; ?>/index.php" class="btn btn-secondary btn-sm">Return to Home</a>
            </div>

        <?php elseif ($requestData['status'] !== 'Completed'): ?>
            <!-- Request Not Completed Yet -->
            <div class="form-card" style="text-align: center;">
                <div style="font-size: 44px; color: #fbbf24; margin-bottom: 14px;">
                    <i class="fa-solid fa-hourglass-half"></i>
                </div>
                <h2 style="font-size: 22px; margin-bottom: 10px;">Request Still In Progress</h2>
                <p style="color: var(--text-muted); font-size: 14px; margin-bottom: 24px;">
                    Token <strong><?php echo htmlspecialchars($requestData['token_number']); ?></strong> is currently marked as 
                    <?php echo getStatusBadge($requestData['status']); ?>. Feedback can only be provided after an administrator completes your service.
                </p>
                <a href="<?php echo BASE_URL; ?>/track-token.php?token_number=<?php echo urlencode($requestData['token_number']); ?>&mobile_number=<?php echo urlencode($requestData['mobile_number']); ?>" class="btn btn-primary btn-sm">
                    <i class="fa-solid fa-radar"></i> Track Live Status
                </a>
            </div>

        <?php else: ?>
            <!-- Feedback Form -->
            <?php if ($error): ?>
                <div class="alert-box alert-error">
                    <i class="fa-solid fa-triangle-exclamation"></i>
                    <span><?php echo htmlspecialchars($error); ?></span>
                </div>
            <?php endif; ?>

            <div class="form-card">
                <!-- Request Summary Header -->
                <div style="background: rgba(255,255,255,0.03); border: 1px solid var(--border-subtle); border-radius: var(--radius-sm); padding: 16px; margin-bottom: 24px;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
                        <span class="table-token-badge"><?php echo htmlspecialchars($requestData['token_number']); ?></span>
                        <span style="font-size: 13px; color: #34d399;"><i class="fa-solid fa-circle-check"></i> Completed</span>
                    </div>
                    <div style="font-size: 15px; font-weight: 700; color: #fff; margin-bottom: 2px;">
                        <?php echo htmlspecialchars($requestData['subject']); ?>
                    </div>
                    <div style="font-size: 13px; color: var(--text-dim);">
                        Department: <?php echo htmlspecialchars($requestData['service_name']); ?> &bull; Served for <?php echo htmlspecialchars($requestData['full_name']); ?>
                    </div>
                </div>

                <form method="POST" action="<?php echo BASE_URL; ?>/feedback.php">
                    <?php echo csrfField(); ?>
                    <input type="hidden" name="request_id" value="<?php echo $requestData['id']; ?>">

                    <div class="form-group" style="text-align: center; margin-bottom: 28px;">
                        <label style="font-size: 15px; margin-bottom: 12px;">How was your service experience? <span class="required">*</span></label>
                        <div style="display: flex; justify-content: center; gap: 14px; font-size: 32px;">
                            <?php for ($s = 1; $s <= 5; $s++): ?>
                                <label style="cursor: pointer; margin: 0; display: inline-flex; flex-direction: column; align-items: center;">
                                    <input type="radio" name="rating" value="<?php echo $s; ?>" required style="margin-bottom: 6px; accent-color: #fbbf24;">
                                    <span style="font-size: 12px; color: var(--text-dim);"><?php echo $s; ?>★</span>
                                </label>
                            <?php endfor; ?>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="fb_comments">Additional Comments & Remarks (Optional):</label>
                        <textarea id="fb_comments" name="comments" class="form-control" placeholder="Share your suggestions, officer conduct remarks, or waiting time feedback..." rows="4"></textarea>
                    </div>

                    <button type="submit" class="btn btn-primary btn-block btn-lg" style="margin-top: 20px;">
                        <i class="fa-solid fa-paper-plane"></i> Submit Feedback
                    </button>
                </form>
            </div>
        <?php endif; ?>

    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
