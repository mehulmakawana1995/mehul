<?php
/**
 * QueueLess AI — Smart Digital Queue Management System
 * Global Application Configuration
 */

// Report errors in development, keep display controlled
error_reporting(E_ALL);
ini_set('display_errors', '1');

// Set application timezone
date_default_timezone_set('Asia/Kolkata');

// Database Connection Settings (Standard XAMPP default)
define('DB_HOST', 'localhost');
define('DB_PORT', '3306');
define('DB_NAME', 'queueless_ai');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

// Application Details
define('APP_NAME', 'QueueLess AI');
define('APP_TAGLINE', 'Smart Digital Queue Management System');
define('APP_VERSION', '2.5.0');
define('ORG_NAME', 'IT Institute Technothon');

// Default queue parameters
define('DEFAULT_AVG_SERVICE_MINUTES', 15);
define('QUEUE_REFRESH_INTERVAL_SEC', 10); // Auto-refresh interval for queue boards

// Session security configuration
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', '1');
    ini_set('session.use_only_cookies', '1');
    session_start();
}

/**
 * Dynamically resolve base application URL
 */
function getBaseUrl(): string {
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || (isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == 443)) ? "https://" : "http://";
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    
    // Determine script directory relative to document root
    $scriptName = $_SERVER['SCRIPT_NAME'] ?? '';
    $dir = str_replace('\\', '/', dirname($scriptName));
    
    // Normalize if we are inside /admin subdirectory
    if (str_ends_with($dir, '/admin')) {
        $dir = substr($dir, 0, -6);
    }
    
    $trimmedDir = rtrim($dir, '/');
    return $protocol . $host . ($trimmedDir ? $trimmedDir : '');
}

define('BASE_URL', getBaseUrl());
