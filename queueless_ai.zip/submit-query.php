<?php
/**
 * QueueLess AI — Customer Query Submission & Token Generator
 */

$pageTitle = "Generate Digital Queue Token";
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/csrf.php';
require_once __DIR__ . '/includes/functions.php';

$pdo = getDB();
$services = getServices($pdo, true);

$errors = [];
$generatedToken = null;

// Preselected service via query parameter
$selectedServiceId = isset($_GET['service_id']) ? (int)$_GET['service_id'] : 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 1. CSRF Verification
    $csrfToken = $_POST['csrf_token'] ?? '';
    if (!verifyCsrfToken($csrfToken)) {
        $errors[] = 'Security token expired or invalid. Please refresh the form and try again.';
    }

    // 2. Extract and Sanitize Inputs
    $fullName = trim($_POST['full_name'] ?? '');
    $mobileNumber = trim($_POST['mobile_number'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $serviceId = (int)($_POST['service_id'] ?? 0);
    $branchName = trim($_POST['branch_name'] ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $description = trim($_POST['description'] ?? '');

    // 3. Validation
    if (empty($fullName)) {
        $errors[] = 'Customer full name is required.';
    } elseif (strlen($fullName) < 2) {
        $errors[] = 'Full name must be at least 2 characters.';
    }

    // Sanitize mobile: retain only digits
    $cleanMobile = preg_replace('/[^0-9]/', '', $mobileNumber);
    if (empty($cleanMobile) || strlen($cleanMobile) !== 10) {
        $errors[] = 'Please provide a valid 10-digit mobile number.';
    }

    if (!empty($email) && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Please enter a valid email address.';
    }

    if ($serviceId <= 0) {
        $errors[] = 'Please select a service category.';
    } else {
        // Verify valid service in database
        $svcCheck = $pdo->prepare("SELECT id, service_name, average_service_minutes FROM services WHERE id = :id AND is_active = 1");
        $svcCheck->execute(['id' => $serviceId]);
        $serviceRecord = $svcCheck->fetch();
        if (!$serviceRecord) {
            $errors[] = 'Selected service category is invalid or currently inactive.';
        }
    }

    if (empty($subject)) {
        $errors[] = 'Please enter a brief subject or inquiry title.';
    }

    if (empty($description)) {
        $errors[] = 'Please enter a detailed description of your query.';
    }

    // 4. Save to MySQL and Generate Token
    if (empty($errors) && !empty($serviceRecord)) {
        try {
            $pdo->beginTransaction();

            // A. Customer Record (Reuse existing customer or create new)
            $custStmt = $pdo->prepare("SELECT id FROM customers WHERE mobile_number = :m LIMIT 1");
            $custStmt->execute(['m' => $cleanMobile]);
            $existingCust = $custStmt->fetch();

            if ($existingCust) {
                $customerId = (int)$existingCust['id'];
                // Update customer name and email
                $updateCust = $pdo->prepare("UPDATE customers SET full_name = :n, email = :e, updated_at = NOW() WHERE id = :id");
                $updateCust->execute([
                    'n'  => $fullName,
                    'e'  => !empty($email) ? $email : null,
                    'id' => $customerId
                ]);
            } else {
                $insertCust = $pdo->prepare("INSERT INTO customers (full_name, mobile_number, email, created_at) VALUES (:n, :m, :e, NOW())");
                $insertCust->execute([
                    'n' => $fullName,
                    'm' => $cleanMobile,
                    'e' => !empty($email) ? $email : null
                ]);
                $customerId = (int)$pdo->lastInsertId();
            }

            // B. Generate Unique Request Code
            $requestCode = generateUniqueRequestCode($pdo);

            // C. Insert Request
            $reqStmt = $pdo->prepare("
                INSERT INTO requests (request_code, customer_id, service_id, branch_name, subject, description, status, priority, created_at)
                VALUES (:rc, :cid, :sid, :b, :sub, :desc, 'Waiting', 'Normal', NOW())
            ");
            $reqStmt->execute([
                'rc'   => $requestCode,
                'cid'  => $customerId,
                'sid'  => $serviceId,
                'b'    => !empty($branchName) ? $branchName : null,
                'sub'  => $subject,
                'desc' => $description
            ]);
            $requestId = (int)$pdo->lastInsertId();

            // D. Generate Unique Token Number
            $tokenNumber = generateUniqueTokenNumber($pdo);

            // E. Calculate Queue Position
            $queuePosition = calculateQueuePosition($pdo, $serviceId, $requestId);

            // F. Insert Token Record
            $tokenStmt = $pdo->prepare("
                INSERT INTO tokens (request_id, token_number, queue_date, queue_position, created_at)
                VALUES (:rid, :tn, CURRENT_DATE(), :qp, NOW())
            ");
            $tokenStmt->execute([
                'rid' => $requestId,
                'tn'  => $tokenNumber,
                'qp'  => $queuePosition
            ]);
            $tokenId = (int)$pdo->lastInsertId();

            // G. Record Status History Audit Trail
            logStatusChange($pdo, $requestId, null, 'Waiting', null, 'Token generated online by customer');

            // H. Create Customer Notification
            createNotification(
                $pdo,
                $customerId,
                $requestId,
                'Token Generated Successfully',
                "Your token {$tokenNumber} for {$serviceRecord['service_name']} has been issued. Your queue position is #{$queuePosition}."
            );

            // Commit Transaction
            $pdo->commit();

            // Recalculate queue positions for this service category
            recalculateQueuePositions($pdo, $serviceId);

            // Compute Estimated Wait Minutes
            $estimatedWaitMins = calculateEstimatedWaitMinutes($pdo, $serviceId, $queuePosition);

            // Set generated token payload for presentation
            $generatedToken = [
                'token_number'        => $tokenNumber,
                'request_code'        => $requestCode,
                'full_name'           => $fullName,
                'mobile_number'       => $cleanMobile,
                'service_name'        => $serviceRecord['service_name'],
                'branch_name'         => $branchName,
                'subject'             => $subject,
                'queue_position'      => $queuePosition,
                'estimated_wait_mins' => $estimatedWaitMins,
                'created_at'          => date('Y-m-d H:i:s')
            ];

            setFlash('success', 'Your digital queue token has been generated successfully! Please save your token number.');

        } catch (Exception $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $errors[] = 'A database error occurred while creating your queue request: ' . $e->getMessage();
        }
    }
}

require_once __DIR__ . '/includes/header.php';
?>

<div class="container section-padding" style="padding-top: 40px;">

    <?php if ($generatedToken): ?>
        <!-- Token Success Slip & Receipt -->
        <div style="max-width: 680px; margin: 0 auto;">
            <div style="text-align: center; margin-bottom: 24px;">
                <div style="display: inline-flex; width: 64px; height: 64px; border-radius: 50%; background: rgba(16, 185, 129, 0.2); color: var(--success); align-items: center; justify-content: center; font-size: 28px; margin-bottom: 12px; border: 2px solid rgba(16, 185, 129, 0.4);">
                    <i class="fa-solid fa-check"></i>
                </div>
                <h1 style="font-size: 32px; margin-bottom: 8px;">Token Generated Successfully!</h1>
                <p style="color: var(--text-muted); font-size: 15px;">
                    Your request has been registered in the live queue. Present or track this token when arriving at the service desk.
                </p>
            </div>

            <!-- Printable Coupon Slip -->
            <div class="token-slip" id="printableTokenSlip">
                <div class="token-slip-header">
                    <div style="display: flex; align-items: center; justify-content: center; gap: 8px; margin-bottom: 6px;">
                        <span class="live-pill" style="font-size: 11px;"><i class="fa-solid fa-bolt"></i> Virtual Token</span>
                        <span style="font-size: 13px; color: var(--text-muted); font-weight: 600;"><?php echo APP_NAME; ?></span>
                    </div>
                    <div class="token-slip-number" id="tokenDisplayNumber"><?php echo htmlspecialchars($generatedToken['token_number']); ?></div>
                    <div style="font-size: 13px; color: var(--text-dim); font-family: monospace;">
                        Request Code: <strong><?php echo htmlspecialchars($generatedToken['request_code']); ?></strong>
                    </div>
                </div>

                <div class="token-details-grid">
                    <div class="token-detail-row">
                        <span>Customer Name</span>
                        <strong><?php echo htmlspecialchars($generatedToken['full_name']); ?></strong>
                    </div>
                    <div class="token-detail-row">
                        <span>Mobile Number</span>
                        <strong><?php echo htmlspecialchars($generatedToken['mobile_number']); ?></strong>
                    </div>
                    <div class="token-detail-row">
                        <span>Service Department</span>
                        <strong style="color: #38bdf8;"><?php echo htmlspecialchars($generatedToken['service_name']); ?></strong>
                    </div>
                    <div class="token-detail-row">
                        <span>Branch / Desk</span>
                        <strong><?php echo !empty($generatedToken['branch_name']) ? htmlspecialchars($generatedToken['branch_name']) : 'Main Counter'; ?></strong>
                    </div>
                    <div class="token-detail-row" style="background: rgba(99, 102, 241, 0.08); border-color: rgba(99, 102, 241, 0.25);">
                        <span style="color: #a5b4fc;">Position In Line</span>
                        <strong style="color: #fff; font-size: 18px;">
                            #<?php echo $generatedToken['queue_position']; ?> in queue
                        </strong>
                    </div>
                    <div class="token-detail-row" style="background: rgba(6, 182, 212, 0.08); border-color: rgba(6, 182, 212, 0.25);">
                        <span style="color: #67e8f9;">Estimated Wait Time</span>
                        <strong style="color: #fff; font-size: 18px;">
                            ~<?php echo $generatedToken['estimated_wait_mins']; ?> minutes
                        </strong>
                    </div>
                </div>

                <div style="background: rgba(255,255,255,0.02); border: 1px solid var(--border-subtle); border-radius: var(--radius-sm); padding: 14px; margin-bottom: 20px;">
                    <div style="font-size: 12px; color: var(--text-dim); text-transform: uppercase; margin-bottom: 4px;">Inquiry Subject</div>
                    <div style="color: #f1f5f9; font-weight: 500; font-size: 14px;"><?php echo htmlspecialchars($generatedToken['subject']); ?></div>
                    <div style="font-size: 12px; color: var(--text-muted); margin-top: 6px;">
                        Issued on <?php echo formatDateTime($generatedToken['created_at']); ?>
                    </div>
                </div>

                <div style="display: flex; gap: 12px; flex-wrap: wrap;" class="no-print">
                    <button type="button" class="btn btn-secondary btn-sm btn-copy-token" data-token="<?php echo htmlspecialchars($generatedToken['token_number']); ?>">
                        <i class="fa-regular fa-copy"></i> Copy Token
                    </button>
                    <button type="button" class="btn btn-secondary btn-sm btn-print-token">
                        <i class="fa-solid fa-print"></i> Print Token Slip
                    </button>
                    <a href="<?php echo BASE_URL; ?>/track-token.php?token_number=<?php echo urlencode($generatedToken['token_number']); ?>&mobile_number=<?php echo urlencode($generatedToken['mobile_number']); ?>" class="btn btn-glow-cyan btn-sm" style="margin-left: auto;">
                        <i class="fa-solid fa-radar"></i> Live Track Status &rarr;
                    </a>
                </div>
            </div>

            <div style="text-align: center; margin-top: 24px;" class="no-print">
                <a href="<?php echo BASE_URL; ?>/submit-query.php" class="btn btn-secondary btn-sm">
                    <i class="fa-solid fa-plus"></i> Generate Another Token
                </a>
            </div>
        </div>

    <?php else: ?>
        <!-- Query Submission Form -->
        <div style="max-width: 840px; margin: 0 auto;">
            <div style="text-align: center; margin-bottom: 36px;">
                <span class="section-tag">Instant Queue Access</span>
                <h1 style="font-size: 36px; margin-bottom: 12px;">Generate Your <span class="text-gradient">Digital Token</span></h1>
                <p style="color: var(--text-muted); font-size: 16px;">
                    Submit your query online. Your token will be saved immediately to the database and queued for administrative review.
                </p>
            </div>

            <?php if (!empty($errors)): ?>
                <div class="alert-box alert-error">
                    <i class="fa-solid fa-triangle-exclamation"></i>
                    <div>
                        <strong>Please resolve the following issues:</strong>
                        <ul style="margin: 6px 0 0 16px; padding: 0;">
                            <?php foreach ($errors as $err): ?>
                                <li><?php echo htmlspecialchars($err); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>
            <?php endif; ?>

            <div class="form-card">
                <form id="querySubmissionForm" method="POST" action="<?php echo BASE_URL; ?>/submit-query.php">
                    <?php echo csrfField(); ?>

                    <div class="form-row">
                        <!-- Full Name -->
                        <div class="form-group">
                            <label for="full_name">Customer Full Name <span class="required">*</span></label>
                            <div class="input-with-icon">
                                <i class="fa-regular fa-user"></i>
                                <input type="text" id="full_name" name="full_name" class="form-control" placeholder="e.g. Rahul Sharma" value="<?php echo htmlspecialchars($_POST['full_name'] ?? ''); ?>" required>
                            </div>
                        </div>

                        <!-- Mobile Number -->
                        <div class="form-group">
                            <label for="mobile_number">Mobile Number <span class="required">*</span></label>
                            <div class="input-with-icon">
                                <i class="fa-solid fa-phone"></i>
                                <input type="tel" id="mobile_number" name="mobile_number" class="form-control" placeholder="10-digit mobile number" value="<?php echo htmlspecialchars($_POST['mobile_number'] ?? ''); ?>" required pattern="[0-9]{10}" maxlength="10">
                            </div>
                            <span class="form-text">Used to verify your identity and track your token.</span>
                        </div>
                    </div>

                    <div class="form-row">
                        <!-- Email Address -->
                        <div class="form-group">
                            <label for="email">Email Address (Optional)</label>
                            <div class="input-with-icon">
                                <i class="fa-regular fa-envelope"></i>
                                <input type="email" id="email" name="email" class="form-control" placeholder="e.g. rahul@example.com" value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>">
                            </div>
                        </div>

                        <!-- Service Category -->
                        <div class="form-group">
                            <label for="service_id">Service Category <span class="required">*</span></label>
                            <div class="input-with-icon">
                                <i class="fa-solid fa-briefcase"></i>
                                <select id="service_id" name="service_id" class="form-control" required>
                                    <option value="">-- Select Service Department --</option>
                                    <?php foreach ($services as $svc): 
                                        $selected = ($svc['id'] == ($selectedServiceId ?: ($_POST['service_id'] ?? 0))) ? 'selected' : '';
                                    ?>
                                        <option value="<?php echo $svc['id']; ?>" <?php echo $selected; ?>>
                                            <?php echo htmlspecialchars($svc['service_name']); ?> (~<?php echo $svc['average_service_minutes']; ?> min/person)
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="form-row">
                        <!-- Branch or Department -->
                        <div class="form-group">
                            <label for="branch_name">Branch / Specific Department (Optional)</label>
                            <div class="input-with-icon">
                                <i class="fa-solid fa-building"></i>
                                <input type="text" id="branch_name" name="branch_name" class="form-control" placeholder="e.g. OPD Wing 2, Admission Desk, Cash Counter" value="<?php echo htmlspecialchars($_POST['branch_name'] ?? ''); ?>">
                            </div>
                        </div>

                        <!-- Subject -->
                        <div class="form-group">
                            <label for="subject">Query Subject <span class="required">*</span></label>
                            <div class="input-with-icon">
                                <i class="fa-solid fa-heading"></i>
                                <input type="text" id="subject" name="subject" class="form-control" placeholder="e.g. Doctor Consultation, Fee Verification, Certificate" value="<?php echo htmlspecialchars($_POST['subject'] ?? ''); ?>" required>
                            </div>
                        </div>
                    </div>

                    <!-- Problem Description -->
                    <div class="form-group">
                        <label for="description">Detailed Query / Problem Description <span class="required">*</span></label>
                        <textarea id="description" name="description" class="form-control" placeholder="Provide relevant details about your inquiry or required service..." rows="4" required><?php echo htmlspecialchars($_POST['description'] ?? ''); ?></textarea>
                    </div>

                    <div style="display: flex; align-items: center; justify-content: space-between; margin-top: 30px; flex-wrap: wrap; gap: 16px;">
                        <span style="font-size: 13px; color: var(--text-dim);">
                            <i class="fa-solid fa-shield-halved" style="color: var(--cyan);"></i> Saved securely to MySQL. Instant queue ranking.
                        </span>
                        <button type="submit" class="btn btn-primary btn-lg" style="min-width: 240px;">
                            <i class="fa-solid fa-ticket"></i> Generate My Token
                        </button>
                    </div>
                </form>
            </div>
        </div>
    <?php endif; ?>

</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
