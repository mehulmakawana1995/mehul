<?php
/**
 * QueueLess AI — Administrator Secure Login
 */

$pageTitle = "Administrator Sign In";
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/csrf.php';
require_once __DIR__ . '/includes/functions.php';

// If already authenticated, redirect directly to admin dashboard
if (isAdminLoggedIn()) {
    header('Location: ' . BASE_URL . '/admin/dashboard.php');
    exit;
}

$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrfToken = $_POST['csrf_token'] ?? '';
    if (!verifyCsrfToken($csrfToken)) {
        $error = 'Security session expired. Please refresh the page and try again.';
    } else {
        $username = trim($_POST['username'] ?? '');
        $password = trim($_POST['password'] ?? '');

        if (empty($username) || empty($password)) {
            $error = 'Please enter both username and password.';
        } else {
            $auth = authenticateAdmin($username, $password);
            if ($auth['success']) {
                setFlash('success', 'Welcome back, ' . htmlspecialchars($auth['admin']['name']) . '!');
                $redirectUrl = $_SESSION['redirect_after_login'] ?? (BASE_URL . '/admin/dashboard.php');
                unset($_SESSION['redirect_after_login']);
                header('Location: ' . $redirectUrl);
                exit;
            } else {
                $error = $auth['message'];
            }
        }
    }
}

require_once __DIR__ . '/includes/header.php';
?>

<div class="container section-padding" style="padding-top: 50px;">
    <div style="max-width: 480px; margin: 0 auto;">

        <div style="text-align: center; margin-bottom: 30px;">
            <div style="width: 64px; height: 64px; border-radius: 18px; background: linear-gradient(135deg, var(--primary) 0%, var(--cyan) 100%); display: inline-flex; align-items: center; justify-content: center; font-size: 28px; color: #fff; box-shadow: 0 0 30px var(--primary-glow); margin-bottom: 16px;">
                <i class="fa-solid fa-shield-halved"></i>
            </div>
            <h1 style="font-size: 28px; margin-bottom: 8px;">Admin <span class="text-gradient">Control Center</span></h1>
            <p style="color: var(--text-muted); font-size: 14px;">
                Secure session-based authentication for queue administrators and desk operators.
            </p>
        </div>

        <?php if ($error): ?>
            <div class="alert-box alert-error">
                <i class="fa-solid fa-triangle-exclamation"></i>
                <span><?php echo htmlspecialchars($error); ?></span>
            </div>
        <?php endif; ?>

        <!-- Demo Credentials Helper Callout for Technothon Presentation -->
        <div style="background: rgba(99, 102, 241, 0.1); border: 1px dashed rgba(99, 102, 241, 0.35); border-radius: var(--radius-md); padding: 14px 18px; margin-bottom: 24px; font-size: 13px;">
            <div style="color: #a5b4fc; font-weight: 700; margin-bottom: 4px;">
                <i class="fa-solid fa-key"></i> Default Demo Credentials:
            </div>
            <div style="color: #cbd5e1;">
                Username: <code style="background: rgba(0,0,0,0.3); color: #38bdf8; padding: 2px 6px; border-radius: 4px;">admin</code> &bull; 
                Password: <code style="background: rgba(0,0,0,0.3); color: #38bdf8; padding: 2px 6px; border-radius: 4px;">Admin@12345</code>
            </div>
        </div>

        <div class="form-card" style="padding: 32px;">
            <form method="POST" action="<?php echo BASE_URL; ?>/admin-login.php">
                <?php echo csrfField(); ?>

                <div class="form-group">
                    <label for="admin_username">Admin Username <span class="required">*</span></label>
                    <div class="input-with-icon">
                        <i class="fa-regular fa-user"></i>
                        <input type="text" id="admin_username" name="username" class="form-control" placeholder="Enter username" value="<?php echo htmlspecialchars($_POST['username'] ?? 'admin'); ?>" required autofocus>
                    </div>
                </div>

                <div class="form-group">
                    <label for="admin_password">Password <span class="required">*</span></label>
                    <div class="input-with-icon">
                        <i class="fa-solid fa-lock"></i>
                        <input type="password" id="admin_password" name="password" class="form-control" placeholder="Enter password" required>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary btn-block btn-lg" style="margin-top: 24px;">
                    <i class="fa-solid fa-right-to-bracket"></i> Sign In to Dashboard
                </button>
            </form>
        </div>

        <div style="text-align: center; margin-top: 24px;">
            <a href="<?php echo BASE_URL; ?>/create-admin.php" style="color: var(--text-muted); font-size: 13px;">
                <i class="fa-solid fa-user-plus"></i> Need to create or reset an admin account?
            </a>
        </div>

    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
