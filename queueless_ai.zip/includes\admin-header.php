<?php
/**
 * QueueLess AI — Admin Layout Header
 */
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/functions.php';

// Protect all admin pages
requireAdminLogin();

$admin = getCurrentAdmin();
$currentPage = basename($_SERVER['PHP_SELF']);
$pdo = getDB();

// Quick count of active waiting customers for sidebar badge
$waitingBadgeCount = (int)$pdo->query("SELECT COUNT(*) FROM requests WHERE status = 'Waiting'")->fetchColumn();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#090d16">
    <title><?php echo isset($adminTitle) ? htmlspecialchars($adminTitle) . ' — QueueLess Admin' : 'Admin Control Center — QueueLess AI'; ?></title>

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

    <!-- Font Awesome 6 CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <!-- Chart.js 4 CDN -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <!-- Base & Admin Styles -->
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/assets/css/style.css">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/assets/css/admin.css">
</head>
<body class="admin-body">

    <!-- Sidebar -->
    <aside class="admin-sidebar">
        <div class="sidebar-header">
            <div class="sidebar-logo-icon">
                <i class="fa-solid fa-bolt-lightning"></i>
            </div>
            <div class="sidebar-brand-name">
                Queue<span>Less</span> <small style="font-size: 11px; color: var(--text-dim);">ADMIN</small>
            </div>
        </div>

        <nav class="sidebar-nav">
            <div class="nav-section-title">Core Operations</div>
            <ul class="sidebar-nav-list">
                <li class="sidebar-nav-item">
                    <a href="<?php echo BASE_URL; ?>/admin/dashboard.php" class="sidebar-nav-link <?php echo $currentPage === 'dashboard.php' ? 'active' : ''; ?>">
                        <i class="fa-solid fa-gauge-high"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                <li class="sidebar-nav-item">
                    <a href="<?php echo BASE_URL; ?>/admin/queue.php" class="sidebar-nav-link <?php echo $currentPage === 'queue.php' ? 'active' : ''; ?>">
                        <i class="fa-solid fa-users-rays"></i>
                        <span>Live Queue Board</span>
                        <?php if ($waitingBadgeCount > 0): ?>
                            <span class="nav-badge-pill" style="background: rgba(245, 158, 11, 0.2); color: #fbbf24;"><?php echo $waitingBadgeCount; ?></span>
                        <?php endif; ?>
                    </a>
                </li>
                <li class="sidebar-nav-item">
                    <a href="<?php echo BASE_URL; ?>/admin/requests.php" class="sidebar-nav-link <?php echo in_array($currentPage, ['requests.php', 'request-details.php']) ? 'active' : ''; ?>">
                        <i class="fa-solid fa-receipt"></i>
                        <span>All Requests</span>
                    </a>
                </li>
            </ul>

            <div class="nav-section-title">Management</div>
            <ul class="sidebar-nav-list">
                <li class="sidebar-nav-item">
                    <a href="<?php echo BASE_URL; ?>/admin/services.php" class="sidebar-nav-link <?php echo $currentPage === 'services.php' ? 'active' : ''; ?>">
                        <i class="fa-solid fa-cubes-stacked"></i>
                        <span>Services & Desks</span>
                    </a>
                </li>
                <li class="sidebar-nav-item">
                    <a href="<?php echo BASE_URL; ?>/admin/customers.php" class="sidebar-nav-link <?php echo $currentPage === 'customers.php' ? 'active' : ''; ?>">
                        <i class="fa-solid fa-address-book"></i>
                        <span>Customers Directory</span>
                    </a>
                </li>
                <li class="sidebar-nav-item">
                    <a href="<?php echo BASE_URL; ?>/admin/settings.php" class="sidebar-nav-link <?php echo $currentPage === 'settings.php' ? 'active' : ''; ?>">
                        <i class="fa-solid fa-sliders"></i>
                        <span>Queue Settings</span>
                    </a>
                </li>
            </ul>

            <div class="nav-section-title">Public Portal</div>
            <ul class="sidebar-nav-list">
                <li class="sidebar-nav-item">
                    <a href="<?php echo BASE_URL; ?>/index.php" target="_blank" class="sidebar-nav-link">
                        <i class="fa-solid fa-arrow-up-right-from-square"></i>
                        <span>View Customer Site</span>
                    </a>
                </li>
                <li class="sidebar-nav-item">
                    <a href="<?php echo BASE_URL; ?>/create-admin.php" class="sidebar-nav-link">
                        <i class="fa-solid fa-user-plus"></i>
                        <span>Admin Provisioning</span>
                    </a>
                </li>
            </ul>
        </nav>

        <div class="sidebar-footer">
            <div class="admin-user-profile">
                <div class="admin-avatar">
                    <?php echo strtoupper(substr($admin['name'] ?? 'A', 0, 1)); ?>
                </div>
                <div class="admin-profile-info">
                    <div class="admin-profile-name"><?php echo htmlspecialchars($admin['name']); ?></div>
                    <div class="admin-profile-role"><?php echo htmlspecialchars($admin['role']); ?></div>
                </div>
                <a href="<?php echo BASE_URL; ?>/admin-logout.php" title="Sign Out" style="color: var(--rose); padding: 4px; font-size: 15px;">
                    <i class="fa-solid fa-right-from-bracket"></i>
                </a>
            </div>
        </div>
    </aside>

    <!-- Main Container -->
    <div class="admin-main">
        <!-- Topbar -->
        <header class="admin-topbar">
            <div class="topbar-left">
                <button type="button" id="adminSidebarToggle" class="btn-action-icon" style="display: none;" aria-label="Toggle Sidebar">
                    <i class="fa-solid fa-bars"></i>
                </button>
                <div class="topbar-title">
                    <h1><?php echo isset($adminTitle) ? htmlspecialchars($adminTitle) : 'Admin Dashboard'; ?></h1>
                </div>
            </div>

            <div class="topbar-right">
                <div class="auto-refresh-tag">
                    <span class="refresh-dot"></span>
                    <span>Live Auto-Sync: <strong id="adminRefreshTimer">15s</strong></span>
                    <label style="margin: 0 0 0 6px; cursor: pointer; display: flex; align-items: center;" title="Toggle automatic refresh">
                        <input type="checkbox" id="autoRefreshToggle" checked style="accent-color: var(--primary); cursor: pointer;">
                    </label>
                </div>

                <a href="<?php echo BASE_URL; ?>/admin/queue.php" class="btn btn-primary btn-sm">
                    <i class="fa-solid fa-headset"></i> Call Next Customer
                </a>

                <a href="<?php echo BASE_URL; ?>/admin-logout.php" class="btn btn-secondary btn-sm" style="color: var(--rose);">
                    <i class="fa-solid fa-power-off"></i> Logout
                </a>
            </div>
        </header>

        <!-- Admin Page Content -->
        <main class="admin-content">
            <?php echo renderFlash(); ?>
