<?php
/**
 * QueueLess AI — Core Utility Functions
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db.php';

/**
 * Sanitize user string input safely
 */
function cleanInput(?string $data): string {
    if ($data === null) {
        return '';
    }
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

/**
 * Format timestamp into readable localized date and time
 */
function formatDateTime(?string $datetime, bool $includeTime = true): string {
    if (!$datetime) return '—';
    $timestamp = strtotime($datetime);
    if (!$timestamp) return '—';
    return date($includeTime ? 'M d, Y h:i A' : 'M d, Y', $timestamp);
}

/**
 * Human friendly relative time (e.g. 5 mins ago)
 */
function timeAgo(?string $datetime): string {
    if (!$datetime) return '—';
    $timestamp = strtotime($datetime);
    if (!$timestamp) return '—';
    $diff = time() - $timestamp;

    if ($diff < 60) {
        return 'Just now';
    } elseif ($diff < 3600) {
        $mins = floor($diff / 60);
        return $mins . ' min' . ($mins > 1 ? 's' : '') . ' ago';
    } elseif ($diff < 86400) {
        $hours = floor($diff / 3600);
        return $hours . ' hr' . ($hours > 1 ? 's' : '') . ' ago';
    } else {
        $days = floor($diff / 86400);
        return $days . ' day' . ($days > 1 ? 's' : '') . ' ago';
    }
}

/**
 * Render modern HTML badge for request status
 */
function getStatusBadge(string $status): string {
    $status = trim($status);
    switch ($status) {
        case 'Waiting':
            return '<span class="status-badge badge-waiting"><i class="fa-solid fa-hourglass-half"></i> Waiting</span>';
        case 'Serving':
            return '<span class="status-badge badge-serving"><i class="fa-solid fa-bell animate-pulse"></i> Now Serving</span>';
        case 'Completed':
            return '<span class="status-badge badge-completed"><i class="fa-solid fa-circle-check"></i> Completed</span>';
        case 'Cancelled':
            return '<span class="status-badge badge-cancelled"><i class="fa-solid fa-circle-xmark"></i> Cancelled</span>';
        default:
            return '<span class="status-badge badge-default">' . htmlspecialchars($status) . '</span>';
    }
}

/**
 * Render priority badge
 */
function getPriorityBadge(string $priority): string {
    $p = strtolower(trim($priority));
    switch ($p) {
        case 'high':
            return '<span class="priority-badge priority-high"><i class="fa-solid fa-angles-up"></i> High</span>';
        case 'low':
            return '<span class="priority-badge priority-low"><i class="fa-solid fa-angle-down"></i> Low</span>';
        default:
            return '<span class="priority-badge priority-normal"><i class="fa-solid fa-minus"></i> Normal</span>';
    }
}

/**
 * Flash messaging helpers
 */
function setFlash(string $type, string $message): void {
    $_SESSION['flash'] = [
        'type' => $type, // 'success', 'error', 'warning', 'info'
        'message' => $message
    ];
}

function getFlash(): ?array {
    if (!empty($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

/**
 * Render flash message container if set
 */
function renderFlash(): string {
    $flash = getFlash();
    if (!$flash) return '';

    $typeClass = 'alert-' . htmlspecialchars($flash['type']);
    $icon = 'fa-info-circle';
    if ($flash['type'] === 'success') $icon = 'fa-circle-check';
    if ($flash['type'] === 'error') $icon = 'fa-triangle-exclamation';
    if ($flash['type'] === 'warning') $icon = 'fa-circle-exclamation';

    return '
    <div class="alert-box ' . $typeClass . '" role="alert">
        <i class="fa-solid ' . $icon . '"></i>
        <span>' . htmlspecialchars($flash['message']) . '</span>
        <button type="button" class="close-alert" onclick="this.parentElement.remove();">&times;</button>
    </div>';
}

/**
 * Fetch all active services
 */
function getServices(PDO $pdo, bool $activeOnly = true): array {
    $sql = "SELECT id, service_name, description, average_service_minutes, is_active FROM services";
    if ($activeOnly) {
        $sql .= " WHERE is_active = 1";
    }
    $sql .= " ORDER BY service_name ASC";
    return $pdo->query($sql)->fetchAll();
}

/**
 * Generate unique daily request code: REQ-YYYYMMDD-XXXX
 */
function generateUniqueRequestCode(PDO $pdo): string {
    $today = date('Ymd');
    $prefix = "REQ-{$today}-";

    $stmt = $pdo->prepare("SELECT COUNT(*) FROM requests WHERE request_code LIKE :pfx");
    $stmt->execute(['pfx' => $prefix . '%']);
    $count = (int)$stmt->fetchColumn() + 1;

    return sprintf("%s%04d", $prefix, $count);
}

/**
 * Generate unique daily token number: QL-YYYYMMDD-XXXX
 */
function generateUniqueTokenNumber(PDO $pdo): string {
    $today = date('Ymd');
    $prefix = "QL-{$today}-";

    $stmt = $pdo->prepare("SELECT COUNT(*) FROM tokens WHERE token_number LIKE :pfx");
    $stmt->execute(['pfx' => $prefix . '%']);
    $count = (int)$stmt->fetchColumn() + 1;

    // Safety check in case of collision
    $token = sprintf("%s%04d", $prefix, $count);
    $check = $pdo->prepare("SELECT id FROM tokens WHERE token_number = :t");
    $check->execute(['t' => $token]);
    while ($check->fetch()) {
        $count++;
        $token = sprintf("%s%04d", $prefix, $count);
        $check->execute(['t' => $token]);
    }

    return $token;
}

/**
 * Calculate dynamic queue position for a waiting request within its service category
 */
function calculateQueuePosition(PDO $pdo, int $serviceId, int $requestId): int {
    // Check if the request is still Waiting
    $reqStmt = $pdo->prepare("SELECT status, created_at, id FROM requests WHERE id = :rid");
    $reqStmt->execute(['rid' => $requestId]);
    $req = $reqStmt->fetch();

    if (!$req || $req['status'] !== 'Waiting') {
        return 0; // Not waiting
    }

    // Count how many requests are waiting in the same service created before or at the same time
    $sql = "SELECT COUNT(*) FROM requests 
            WHERE service_id = :sid 
              AND status = 'Waiting' 
              AND (created_at < :ca1 OR (created_at = :ca2 AND id <= :rid))";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        'sid' => $serviceId,
        'ca1' => $req['created_at'],
        'ca2' => $req['created_at'],
        'rid' => $requestId
    ]);

    $position = (int)$stmt->fetchColumn();
    return max(1, $position);
}

/**
 * Estimate waiting minutes based on queue position and service duration
 */
function calculateEstimatedWaitMinutes(PDO $pdo, int $serviceId, int $position): int {
    if ($position <= 0) {
        return 0;
    }

    $stmt = $pdo->prepare("SELECT average_service_minutes FROM services WHERE id = :sid");
    $stmt->execute(['sid' => $serviceId]);
    $avg = (int)$stmt->fetchColumn();
    if ($avg <= 0) {
        $avg = DEFAULT_AVG_SERVICE_MINUTES;
    }

    // If customer is #1, wait is approx half service duration or immediate
    if ($position === 1) {
        return max(2, (int)round($avg * 0.5));
    }

    // Customers ahead = ($position - 1)
    return ($position - 1) * $avg;
}

/**
 * Recalculate stored token queue positions for a service
 */
function recalculateQueuePositions(PDO $pdo, int $serviceId): void {
    $sql = "SELECT r.id AS request_id, t.id AS token_id
            FROM requests r
            JOIN tokens t ON t.request_id = r.id
            WHERE r.service_id = :sid AND r.status = 'Waiting'
            ORDER BY r.created_at ASC, r.id ASC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['sid' => $serviceId]);
    $waitingList = $stmt->fetchAll();

    $upStmt = $pdo->prepare("UPDATE tokens SET queue_position = :pos WHERE id = :tid");
    $pos = 1;
    foreach ($waitingList as $item) {
        $upStmt->execute(['pos' => $pos, 'tid' => $item['token_id']]);
        $pos++;
    }
}

/**
 * Log status transition in status_history table
 */
function logStatusChange(PDO $pdo, int $requestId, ?string $oldStatus, string $newStatus, ?int $adminId = null, ?string $note = null): void {
    $stmt = $pdo->prepare("INSERT INTO status_history (request_id, old_status, new_status, changed_by_admin_id, note, changed_at) 
                           VALUES (:rid, :old, :new, :aid, :note, NOW())");
    $stmt->execute([
        'rid'  => $requestId,
        'old'  => $oldStatus,
        'new'  => $newStatus,
        'aid'  => $adminId,
        'note' => $note
    ]);
}

/**
 * Create a customer notification entry
 */
function createNotification(PDO $pdo, int $customerId, int $requestId, string $title, string $message): void {
    $stmt = $pdo->prepare("INSERT INTO notifications (customer_id, request_id, title, message, is_read, created_at) 
                           VALUES (:cid, :rid, :title, :msg, 0, NOW())");
    $stmt->execute([
        'cid'   => $customerId,
        'rid'   => $requestId,
        'title' => $title,
        'msg'   => $message
    ]);
}

/**
 * Fetch high-level queue stats for dashboard
 */
function getQueueStats(PDO $pdo): array {
    $sql = "SELECT 
                COUNT(*) AS total_requests,
                SUM(CASE WHEN status = 'Waiting' THEN 1 ELSE 0 END) AS waiting_count,
                SUM(CASE WHEN status = 'Serving' THEN 1 ELSE 0 END) AS serving_count,
                SUM(CASE WHEN status = 'Completed' THEN 1 ELSE 0 END) AS completed_count,
                SUM(CASE WHEN status = 'Cancelled' THEN 1 ELSE 0 END) AS cancelled_count,
                SUM(CASE WHEN DATE(created_at) = CURRENT_DATE() THEN 1 ELSE 0 END) AS today_requests
            FROM requests";
    $stats = $pdo->query($sql)->fetch();

    return [
        'total'     => (int)($stats['total_requests'] ?? 0),
        'waiting'   => (int)($stats['waiting_count'] ?? 0),
        'serving'   => (int)($stats['serving_count'] ?? 0),
        'completed' => (int)($stats['completed_count'] ?? 0),
        'cancelled' => (int)($stats['cancelled_count'] ?? 0),
        'today'     => (int)($stats['today_requests'] ?? 0)
    ];
}
