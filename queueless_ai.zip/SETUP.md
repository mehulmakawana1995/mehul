# QueueLess AI — Installation & Setup Guide (XAMPP on Windows)

Welcome to **QueueLess AI: Smart Digital Queue Management System**. This guide provides step-by-step instructions to set up, configure, and run the complete web application locally on Windows using XAMPP.

---

## 1. Prerequisites

Make sure you have installed on your Windows computer:
* **XAMPP** (with Apache, PHP 8.0+ and MySQL / MariaDB)
* A web browser (Google Chrome, Microsoft Edge, Firefox, or Brave)

---

## 2. Quick Setup Steps

### Step 1: Start XAMPP Services
1. Open the **XAMPP Control Panel** (Run as Administrator if necessary).
2. Click the **Start** button next to **Apache**. (Status turns Green).
3. Click the **Start** button next to **MySQL**. (Status turns Green).

### Step 2: Place Project in `htdocs`
Ensure the project folder `queueless_ai` is placed inside the XAMPP web root directory:
```
C:\xampp\htdocs\queueless_ai
```
*(This allows the Apache web server to serve the application at `http://localhost/queueless_ai/`)*.

### Step 3: Create & Import the Database in phpMyAdmin
1. Open your browser and navigate to:
   ```
   http://localhost/phpmyadmin/
   ```
2. Click on the **Databases** tab at the top.
3. Under **Create database**, enter:
   - Database name: `queueless_ai`
   - Collation: `utf8mb4_unicode_ci` (or `utf8mb4_general_ci`)
   - Click **Create**.
4. Select the newly created `queueless_ai` database from the left sidebar.
5. Click on the **Import** tab in the top navigation.
6. Click **Choose File** and select:
   ```
   C:\xampp\htdocs\queueless_ai\database.sql
   ```
7. Scroll to the bottom and click **Import** (or **Go**).
8. You should see a green success banner confirming that all 8 tables and default services were imported successfully.

---

## 3. Database Connection Configuration

Configuration settings are centralized in a single file:
```
C:\xampp\htdocs\queueless_ai\includes\config.php
```

Default settings for standard XAMPP installations:
```php
define('DB_HOST', 'localhost');
define('DB_PORT', '3306');
define('DB_NAME', 'queueless_ai');
define('DB_USER', 'root');
define('DB_PASS', ''); // Empty by default in XAMPP
```

> **Note:** If your MySQL root account has a password, enter it in `DB_PASS`. Otherwise, leave it empty `''`.

---

## 4. Default Administrator Credentials

A verified administrator account is automatically seeded in `database.sql`:

* **Admin Portal URL:** `http://localhost/queueless_ai/admin-login.php`
* **Username:** `admin`
* **Password:** `Admin@12345`
* **Role:** `superadmin`

*(Password is hashed using PHP's native `password_hash()` with BCRYPT)*.

---

## 5. Provisioning / Resetting Admin Accounts

If you need to create additional administrator accounts or reset the existing admin password:

### Option A: Web Interface
1. Visit: `http://localhost/queueless_ai/create-admin.php`
2. Enter Officer Full Name, Username, Role, and Password.
3. Click **Save Administrator**.

### Option B: Command Line (CLI)
Open PowerShell or Command Prompt and run:
```bash
C:\xampp\php\php.exe C:\xampp\htdocs\queueless_ai\create-admin.php admin Admin@12345 "Lead Officer" superadmin
```

> ⚠️ **Security Notice:** For production deployment beyond local evaluation, delete or restrict access to `create-admin.php`.

---

## 6. Accessing the Application

* **Customer Portal (Public Homepage):**
  [http://localhost/queueless_ai/](http://localhost/queueless_ai/)
* **Generate Token:**
  [http://localhost/queueless_ai/submit-query.php](http://localhost/queueless_ai/submit-query.php)
* **Track Token Status:**
  [http://localhost/queueless_ai/track-token.php](http://localhost/queueless_ai/track-token.php)
* **My Request History:**
  [http://localhost/queueless_ai/my-requests.php](http://localhost/queueless_ai/my-requests.php)
* **Customer Feedback:**
  [http://localhost/queueless_ai/feedback.php](http://localhost/queueless_ai/feedback.php)
* **Admin Dashboard:**
  [http://localhost/queueless_ai/admin/dashboard.php](http://localhost/queueless_ai/admin/dashboard.php)
* **Live Queue Command Board:**
  [http://localhost/queueless_ai/admin/queue.php](http://localhost/queueless_ai/admin/queue.php)

---

## 7. Technothon Live Presentation Demonstration Workflow

Follow this 5-minute presentation script to showcase the system to judges:

1. **Open Customer Portal:**
   - Open `http://localhost/queueless_ai/` in a browser window.
   - Highlight the futuristic dark/glassmorphic design, dynamic live stats, and 6 service departments.
2. **Generate a Customer Token:**
   - Click **Generate Your Token**.
   - Enter Customer Name (*e.g., Aarav Sharma*), Mobile (*9876543210*), Service (*Hospital*), Subject, and Query.
   - Click **Generate My Token**.
   - Show the generated **Token Slip Receipt** (`QL-YYYYMMDD-XXXX`), position, and calculated wait time.
3. **Open Admin Console in Side-by-Side Window:**
   - Log into `http://localhost/queueless_ai/admin-login.php` with `admin` / `Admin@12345`.
   - Show the **Dashboard** charts (Daily trend & Service breakdown) and KPI cards.
4. **Demonstrate FIFO Queue Dispatch:**
   - Navigate to **Live Queue Board** (`admin/queue.php`).
   - Click **Call Next Customer**.
   - Observe the synthesized polyphonic audio bell ring, and see the customer status change to **Now Serving**.
5. **Demonstrate Customer Live Radar Tracker:**
   - On the customer window (`track-token.php`), show the status transition to **Now Serving** with the progress stepper.
6. **Complete & Rate Request:**
   - From the admin panel, click **Mark Completed**.
   - Customer submits a 5-star rating with comments on `feedback.php`.
   - The admin dashboard KPIs and customer directory update immediately.

---

## 8. Troubleshooting Common Errors

### Problem: "Port 80 in use by another program" (Apache won't start)
* **Cause:** Skype, IIS, or VMware may be occupying port 80 or 443.
* **Fix:** In XAMPP Control Panel, click Apache **Config** -> `httpd.conf` and change `Listen 80` to `Listen 8080`. Then access the app at `http://localhost:8080/queueless_ai/`.

### Problem: "Unable to connect to MySQL database"
* **Cause:** MySQL service is stopped or port 3306 is blocked.
* **Fix:** Verify MySQL status in XAMPP is green. If using custom credentials, update `includes/config.php`.

### Problem: "#1046 - No database selected" during import
* **Cause:** Importing before selecting the database in phpMyAdmin.
* **Fix:** Create `queueless_ai` database first, click it in the left sidebar, then click the **Import** tab. Note that `database.sql` also contains `CREATE DATABASE IF NOT EXISTS queueless_ai; USE queueless_ai;` to prevent this error.

---

## 9. Verification & Self-Test Script

You can verify all application functionality at any time by running:
```bash
C:\xampp\php\php.exe C:\xampp\htdocs\queueless_ai\test_flows.php
```
All 10 verification steps will execute and output pass/fail indicators.
