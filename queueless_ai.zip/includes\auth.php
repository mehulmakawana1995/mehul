<?php
/**
 * QueueLess AI — Authentication & Session Manager
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db.php';

function isAdminLoggedIn(): bool {
    return !empty($_SESSION['admin_id']) && !empty($_SESSION['admin_username']);
}

function getCurrentAdmin(): ?array {
    if (!isAdminLoggedIn()) {
        return null;
    }
    return [
        'id'       => $_SESSION['admin_id'],
        'username' => $_SESSION['admin_username'],
        'name'     => $_SESSION['admin_name'] ?? 'Admin',
        'role'     => $_SESSION['admin_role'] ?? 'admin'
    ];
}

function requireAdminLogin(): void {
    if (!isAdminLoggedIn()) {
        $_SESSION['flash_error'] = 'Access restricted. Please log in with admin credentials.';
        $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'] ?? (BASE_URL . '/admin/dashboard.php');
        header('Location: ' . BASE_URL . '/admin-login.php');
        exit;
    }
}

function authenticateAdmin(string $username, string $password): array {
    $pdo = getDB();
    $username = trim($username);

    $stmt = $pdo->prepare("SELECT id, name, username, email, password_hash, role, is_active FROM admins WHERE username = :u LIMIT 1");
    $stmt->execute(['u' => $username]);
    $admin = $stmt->fetch();

    if (!$admin) {
        return ['success' => false, 'message' => 'Invalid username or password.'];
    }

    if ((int)$admin['is_active'] !== 1) {
        return ['success' => false, 'message' => 'This admin account has been deactivated. Contact the system administrator.'];
    }

    if (!password_verify($password, $admin['password_hash'])) {
        return ['success' => false, 'message' => 'Invalid username or password.'];
    }

    // Authentication succeeded: regenerate session ID for security
    if (session_status() === PHP_SESSION_ACTIVE && !headers_sent()) {
        session_regenerate_id(true);
    }
    $_SESSION['admin_id'] = (int)$admin['id'];
    $_SESSION['admin_username'] = $admin['username'];
    $_SESSION['admin_name'] = $admin['name'];
    $_SESSION['admin_role'] = $admin['role'];

    // Update last activity or timestamp
    $upStmt = $pdo->prepare("UPDATE admins SET updated_at = NOW() WHERE id = :id");
    $upStmt->execute(['id' => $admin['id']]);

    return ['success' => true, 'admin' => $admin];
}

function logoutAdmin(): void {
    unset($_SESSION['admin_id'], $_SESSION['admin_username'], $_SESSION['admin_name'], $_SESSION['admin_role']);
    if (session_status() === PHP_SESSION_ACTIVE && !headers_sent()) {
        session_regenerate_id(true);
    }
}
