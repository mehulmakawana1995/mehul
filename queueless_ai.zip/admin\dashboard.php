<?php
/**
 * QueueLess AI — Admin Analytics & Dashboard
 */

$adminTitle = "Operations Dashboard";
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

$pdo = getDB();
$stats = getQueueStats($pdo);
$services = getServices($pdo, false);

// 1. Chart Data: Daily requests for past 7 days
$dailyLabels = [];
$dailyValues = [];
for ($i = 6; $i >= 0; $i--) {
    $d = date('Y-m-d', strtotime("-{$i} days"));
    $dailyLabels[$d] = date('D (M d)', strtotime($d));
    $dailyValues[$d] = 0;
}

$dailyStmt = $pdo->query("
    SELECT DATE(created_at) AS req_date, COUNT(*) AS total
    FROM requests
    WHERE created_at >= DATE_SUB(CURRENT_DATE(), INTERVAL 6 DAY)
    GROUP BY DATE(created_at)
    ORDER BY req_date ASC
");
while ($row = $dailyStmt->fetch()) {
    if (isset($dailyValues[$row['req_date']])) {
        $dailyValues[$row['req_date']] = (int)$row['total'];
    }
}

$chartDailyData = [
    'labels' => array_values($dailyLabels),
    'values' => array_values($dailyValues)
];

// 2. Chart Data: Service Category Distribution
$catStmt = $pdo->query("
    SELECT s.service_name, COUNT(r.id) AS total
    FROM services s
    LEFT JOIN requests r ON r.service_id = s.id
    GROUP BY s.id, s.service_name
    ORDER BY total DESC
");
$catLabels = [];
$catValues = [];
while ($row = $catStmt->fetch()) {
    $catLabels[] = $row['service_name'];
    $catValues[] = (int)$row['total'];
}
$chartCatData = [
    'labels' => $catLabels,
    'values' => $catValues
];

// 3. Search & Filter Parameters for Recent Requests Table
$searchQuery = trim($_GET['search'] ?? '');
$statusFilter = trim($_GET['status'] ?? '');
$serviceFilter = (int)($_GET['service_id'] ?? 0);

$where = ["1=1"];
$params = [];

if (!empty($searchQuery)) {
    $where[] = "(t.token_number LIKE :q OR c.full_name LIKE :q OR c.mobile_number LIKE :q OR r.request_code LIKE :q OR r.subject LIKE :q)";
    $params['q'] = "%{$searchQuery}%";
}
if (!empty($statusFilter) && in_array($statusFilter, ['Waiting', 'Serving', 'Completed', 'Cancelled'])) {
    $where[] = "r.status = :st";
    $params['st'] = $statusFilter;
}
if ($serviceFilter > 0) {
    $where[] = "r.service_id = :sid";
    $params['sid'] = $serviceFilter;
}

$whereSql = implode(" AND ", $where);

// Fetch recent requests (limit 10 for dashboard)
$reqSql = "
    SELECT 
        r.id, r.request_code, r.subject, r.status, r.priority, r.created_at,
        c.full_name, c.mobile_number,
        s.service_name,
        t.token_number
    FROM requests r
    JOIN customers c ON c.id = r.customer_id
    JOIN services s ON s.id = r.service_id
    LEFT JOIN tokens t ON t.request_id = r.id
    WHERE {$whereSql}
    ORDER BY r.created_at DESC
    LIMIT 10
";
$stmt = $pdo->prepare($reqSql);
$stmt->execute($params);
$recentRequests = $stmt->fetchAll();

// Currently Serving requests count
$servingList = $pdo->query("
    SELECT r.id, t.token_number, c.full_name, s.service_name, r.updated_at
    FROM requests r
    JOIN customers c ON c.id = r.customer_id
    JOIN services s ON s.id = r.service_id
    JOIN tokens t ON t.request_id = r.id
    WHERE r.status = 'Serving'
    ORDER BY r.updated_at DESC
    LIMIT 3
")->fetchAll();

require_once __DIR__ . '/../includes/admin-header.php';
?>

<!-- Inject Chart Data to JS -->
<script>
    window.DAILY_CHART_DATA = <?php echo json_encode($chartDailyData); ?>;
    window.CATEGORY_CHART_DATA = <?php echo json_encode($chartCatData); ?>;
</script>

<!-- KPI Metrics Grid -->
<div class="metrics-grid">
    <div class="metric-card metric-total">
        <div class="metric-header">
            <span class="metric-title">Total Requests</span>
            <div class="metric-icon-wrap"><i class="fa-solid fa-receipt"></i></div>
        </div>
        <div class="metric-value"><?php echo number_format($stats['total']); ?></div>
        <div class="metric-subtext"><?php echo $stats['today']; ?> generated today</div>
    </div>

    <div class="metric-card metric-waiting">
        <div class="metric-header">
            <span class="metric-title">Waiting In Queue</span>
            <div class="metric-icon-wrap"><i class="fa-solid fa-hourglass-half"></i></div>
        </div>
        <div class="metric-value" style="color: #fbbf24;"><?php echo $stats['waiting']; ?></div>
        <div class="metric-subtext">Virtual tokens pending call</div>
    </div>

    <div class="metric-card metric-serving">
        <div class="metric-header">
            <span class="metric-title">Currently Serving</span>
            <div class="metric-icon-wrap"><i class="fa-solid fa-bell animate-pulse"></i></div>
        </div>
        <div class="metric-value" style="color: #38bdf8;"><?php echo $stats['serving']; ?></div>
        <div class="metric-subtext">Active at service desks</div>
    </div>

    <div class="metric-card metric-completed">
        <div class="metric-header">
            <span class="metric-title">Completed</span>
            <div class="metric-icon-wrap"><i class="fa-solid fa-circle-check"></i></div>
        </div>
        <div class="metric-value" style="color: #34d399;"><?php echo $stats['completed']; ?></div>
        <div class="metric-subtext">Finished consultations</div>
    </div>

    <div class="metric-card metric-cancelled">
        <div class="metric-header">
            <span class="metric-title">Cancelled</span>
            <div class="metric-icon-wrap"><i class="fa-solid fa-circle-xmark"></i></div>
        </div>
        <div class="metric-value" style="color: #f87171;"><?php echo $stats['cancelled']; ?></div>
        <div class="metric-subtext">Revoked or no-shows</div>
    </div>
</div>

<!-- Hero Call Next Customer Action Bar -->
<div class="queue-call-banner">
    <div class="call-banner-info">
        <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 4px;">
            <span class="live-pill" style="font-size: 11px;"><i class="fa-solid fa-bolt"></i> FIFO Queue Controller</span>
            <span style="font-size: 13px; color: #a5b4fc; font-weight: 600;">Queue Depth: <?php echo $stats['waiting']; ?> Customers</span>
        </div>
        <h2>Instant Customer Dispatcher</h2>
        <p>Call the next waiting customer in First-In-First-Out sequence with atomic transaction locking.</p>
    </div>

    <div class="call-actions">
        <form method="POST" action="<?php echo BASE_URL; ?>/admin/queue.php" onsubmit="window.playQueueChime();">
            <?php echo csrfField(); ?>
            <input type="hidden" name="action" value="call_next">
            <button type="submit" class="btn-call-next" <?php echo $stats['waiting'] === 0 ? 'disabled style="opacity: 0.6; cursor: not-allowed;"' : ''; ?>>
                <i class="fa-solid fa-bullhorn"></i>
                <span>Call Next Customer</span>
            </button>
        </form>
        <a href="<?php echo BASE_URL; ?>/admin/queue.php" class="btn btn-secondary">
            <i class="fa-solid fa-users-rays"></i> Full Queue Board
        </a>
    </div>
</div>

<!-- Charts Section -->
<div class="charts-grid">
    <!-- Daily Volume Trend -->
    <div class="card-box">
        <div class="card-box-header">
            <h3><i class="fa-solid fa-chart-line" style="color: var(--primary);"></i> 7-Day Request Volume Trend</h3>
            <span style="font-size: 12px; color: var(--text-dim);">Real-time DB aggregate</span>
        </div>
        <div style="height: 270px; position: relative;">
            <canvas id="dailyRequestsChart"></canvas>
        </div>
    </div>

    <!-- Category Distribution -->
    <div class="card-box">
        <div class="card-box-header">
            <h3><i class="fa-solid fa-chart-pie" style="color: var(--cyan);"></i> Service Category Load</h3>
            <span style="font-size: 12px; color: var(--text-dim);">Distribution</span>
        </div>
        <div style="height: 270px; position: relative;">
            <canvas id="categoryDistributionChart"></canvas>
        </div>
    </div>
</div>

<!-- Currently Serving Live Strip (if any) -->
<?php if (!empty($servingList)): ?>
    <div class="card-box" style="margin-bottom: 28px; background: rgba(99, 102, 241, 0.08); border-color: rgba(99, 102, 241, 0.25);">
        <div class="card-box-header" style="border-bottom-color: rgba(99, 102, 241, 0.2);">
            <h3 style="color: #a5b4fc;"><i class="fa-solid fa-headset"></i> Desks Currently Active</h3>
            <span style="font-size: 12px; color: #38bdf8; font-weight: 700;"><?php echo count($servingList); ?> customer(s) at counter</span>
        </div>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 16px;">
            <?php foreach ($servingList as $srv): ?>
                <div style="background: rgba(11, 16, 32, 0.7); border: 1px solid rgba(99, 102, 241, 0.3); border-radius: var(--radius-md); padding: 16px; display: flex; justify-content: space-between; align-items: center;">
                    <div>
                        <div class="table-token-badge" style="display: inline-block; margin-bottom: 4px;"><?php echo htmlspecialchars($srv['token_number']); ?></div>
                        <div style="font-size: 15px; font-weight: 700; color: #fff;"><?php echo htmlspecialchars($srv['full_name']); ?></div>
                        <div style="font-size: 12px; color: var(--text-dim);"><?php echo htmlspecialchars($srv['service_name']); ?> &bull; Called <?php echo timeAgo($srv['updated_at']); ?></div>
                    </div>
                    <div>
                        <button type="button" class="btn btn-primary btn-sm" onclick="openStatusModal(<?php echo $srv['id']; ?>, 'Serving', 'Completed', '<?php echo htmlspecialchars($srv['token_number']); ?>');">
                            <i class="fa-solid fa-check"></i> Complete
                        </button>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
<?php endif; ?>

<!-- Recent Customer Requests Table -->
<div class="card-box">
    <div class="card-box-header">
        <h3><i class="fa-solid fa-clock-rotate-left"></i> Recent Customer Requests</h3>
        <a href="<?php echo BASE_URL; ?>/admin/requests.php" class="btn btn-secondary btn-sm">
            View All Requests &rarr;
        </a>
    </div>

    <!-- Filter & Search Toolbar -->
    <form method="GET" action="<?php echo BASE_URL; ?>/admin/dashboard.php" class="filter-bar">
        <div class="filter-group">
            <input type="text" name="search" class="admin-search-input" placeholder="Search token, name, phone, subject..." value="<?php echo htmlspecialchars($searchQuery); ?>">
            
            <select name="service_id" class="admin-select">
                <option value="">All Services</option>
                <?php foreach ($services as $s): ?>
                    <option value="<?php echo $s['id']; ?>" <?php echo $serviceFilter === (int)$s['id'] ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($s['service_name']); ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <select name="status" class="admin-select">
                <option value="">All Statuses</option>
                <option value="Waiting" <?php echo $statusFilter === 'Waiting' ? 'selected' : ''; ?>>Waiting</option>
                <option value="Serving" <?php echo $statusFilter === 'Serving' ? 'selected' : ''; ?>>Serving</option>
                <option value="Completed" <?php echo $statusFilter === 'Completed' ? 'selected' : ''; ?>>Completed</option>
                <option value="Cancelled" <?php echo $statusFilter === 'Cancelled' ? 'selected' : ''; ?>>Cancelled</option>
            </select>

            <button type="submit" class="btn btn-secondary btn-sm">
                <i class="fa-solid fa-filter"></i> Apply Filter
            </button>

            <?php if (!empty($searchQuery) || !empty($statusFilter) || $serviceFilter > 0): ?>
                <a href="<?php echo BASE_URL; ?>/admin/dashboard.php" class="btn btn-secondary btn-sm" style="color: var(--rose);">
                    <i class="fa-solid fa-xmark"></i> Clear
                </a>
            <?php endif; ?>
        </div>

        <div>
            <a href="<?php echo BASE_URL; ?>/admin/dashboard.php" class="btn btn-secondary btn-sm" title="Refresh Dashboard Now">
                <i class="fa-solid fa-arrows-rotate"></i> Refresh Data
            </a>
        </div>
    </form>

    <div class="table-responsive">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Token Number</th>
                    <th>Customer Name</th>
                    <th>Mobile</th>
                    <th>Service Department</th>
                    <th>Subject</th>
                    <th>Submitted</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($recentRequests)): ?>
                    <?php foreach ($recentRequests as $row): ?>
                        <tr>
                            <td>
                                <span class="table-token-badge">
                                    <?php echo htmlspecialchars($row['token_number'] ?? $row['request_code']); ?>
                                </span>
                            </td>
                            <td><strong style="color: #fff;"><?php echo htmlspecialchars($row['full_name']); ?></strong></td>
                            <td style="color: var(--text-muted); font-family: monospace;"><?php echo htmlspecialchars($row['mobile_number']); ?></td>
                            <td style="color: #38bdf8;"><?php echo htmlspecialchars($row['service_name']); ?></td>
                            <td style="color: var(--text-muted); max-width: 200px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                                <?php echo htmlspecialchars($row['subject']); ?>
                            </td>
                            <td style="color: var(--text-dim); font-size: 13px;">
                                <?php echo timeAgo($row['created_at']); ?>
                            </td>
                            <td>
                                <?php echo getStatusBadge($row['status']); ?>
                            </td>
                            <td>
                                <div style="display: flex; gap: 6px;">
                                    <a href="<?php echo BASE_URL; ?>/admin/request-details.php?id=<?php echo $row['id']; ?>" class="btn-action-icon" title="View Details">
                                        <i class="fa-solid fa-eye"></i>
                                    </a>

                                    <?php if ($row['status'] === 'Waiting'): ?>
                                        <button type="button" class="btn-action-icon" style="color: #38bdf8;" title="Call to Serve" onclick="openStatusModal(<?php echo $row['id']; ?>, 'Waiting', 'Serving', '<?php echo htmlspecialchars($row['token_number']); ?>');">
                                            <i class="fa-solid fa-headset"></i>
                                        </button>
                                    <?php elseif ($row['status'] === 'Serving'): ?>
                                        <button type="button" class="btn-action-icon" style="color: #34d399;" title="Mark Completed" onclick="openStatusModal(<?php echo $row['id']; ?>, 'Serving', 'Completed', '<?php echo htmlspecialchars($row['token_number']); ?>');">
                                            <i class="fa-solid fa-check"></i>
                                        </button>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="8" style="text-align: center; padding: 30px; color: var(--text-dim);">
                            No customer requests matching the selected filters.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/admin-footer.php'; ?>
