<?php
/**
 * QueueLess AI — Public Layout Footer
 */
require_once __DIR__ . '/config.php';
?>
    </main>

    <footer class="site-footer">
        <div class="container">
            <div class="footer-grid">
                <div class="footer-col">
                    <div class="brand-logo" style="margin-bottom: 16px;">
                        <div class="brand-icon" style="width: 36px; height: 36px; font-size: 16px;">
                            <i class="fa-solid fa-bolt-lightning"></i>
                        </div>
                        <span style="font-size: 18px;">Queue<span style="color: var(--cyan);">Less</span> AI</span>
                    </div>
                    <p style="color: var(--text-muted); font-size: 14px; line-height: 1.6; margin-bottom: 18px;">
                        An intelligent digital queue management platform designed for public institutions, healthcare hubs, schools, and banks. Eliminating physical waiting lines through digital tokens and real-time status tracking.
                    </p>
                    <span class="live-pill" style="font-size: 11px;">
                        <span class="live-pulse-dot"></span> XAMPP Localhost Server Active
                    </span>
                </div>

                <div class="footer-col">
                    <h4>Quick Services</h4>
                    <ul class="footer-links">
                        <li><a href="<?php echo BASE_URL; ?>/submit-query.php"><i class="fa-solid fa-angle-right"></i> Hospital OPD & Clinics</a></li>
                        <li><a href="<?php echo BASE_URL; ?>/submit-query.php"><i class="fa-solid fa-angle-right"></i> School / College Admissions</a></li>
                        <li><a href="<?php echo BASE_URL; ?>/submit-query.php"><i class="fa-solid fa-angle-right"></i> Government Citizen Desks</a></li>
                        <li><a href="<?php echo BASE_URL; ?>/submit-query.php"><i class="fa-solid fa-angle-right"></i> Banking & Finance Queries</a></li>
                        <li><a href="<?php echo BASE_URL; ?>/submit-query.php"><i class="fa-solid fa-angle-right"></i> Customer Support Helpdesk</a></li>
                    </ul>
                </div>

                <div class="footer-col">
                    <h4>Customer Links</h4>
                    <ul class="footer-links">
                        <li><a href="<?php echo BASE_URL; ?>/submit-query.php"><i class="fa-solid fa-angle-right"></i> Generate Digital Token</a></li>
                        <li><a href="<?php echo BASE_URL; ?>/track-token.php"><i class="fa-solid fa-angle-right"></i> Live Queue Tracker</a></li>
                        <li><a href="<?php echo BASE_URL; ?>/my-requests.php"><i class="fa-solid fa-angle-right"></i> My Request History</a></li>
                        <li><a href="<?php echo BASE_URL; ?>/feedback.php"><i class="fa-solid fa-angle-right"></i> Submit Service Feedback</a></li>
                        <li><a href="<?php echo BASE_URL; ?>/admin-login.php"><i class="fa-solid fa-angle-right"></i> Administration Login</a></li>
                    </ul>
                </div>

                <div class="footer-col">
                    <h4>Technothon Project</h4>
                    <p style="color: var(--text-muted); font-size: 14px; margin-bottom: 12px;">
                        Built for <strong>IT Institute Technothon</strong> with pure PHP 8+, MySQL, and responsive modern CSS.
                    </p>
                    <div style="background: rgba(255,255,255,0.03); border: 1px solid var(--border-subtle); border-radius: var(--radius-sm); padding: 12px; font-size: 13px;">
                        <div style="color: var(--text-dim); margin-bottom: 4px;">System Clock</div>
                        <div style="color: #38bdf8; font-weight: 700; font-family: monospace;">
                            <?php echo date('d M Y, h:i A'); ?> (IST)
                        </div>
                    </div>
                </div>
            </div>

            <div class="footer-bottom">
                <div>
                    &copy; <?php echo date('Y'); ?> <strong>QueueLess AI</strong>. Developed for Technothon Live Demo.
                </div>
                <div>
                    <span style="color: var(--text-muted);">Database: MySQL (InnoDB) | PHP 8+ | No External Paid APIs</span>
                </div>
            </div>
        </div>
    </footer>

    <!-- Scripts -->
    <script src="<?php echo BASE_URL; ?>/assets/js/main.js"></script>
</body>
</html>
