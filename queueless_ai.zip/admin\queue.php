<?php
/**
 * QueueLess AI — Live Queue Management Command Center
 * Atomic FIFO Queue Processing with Database Locking & Real-Time Sync
 */

$adminTitle = "Live Queue Management";
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/functions.php';

$pdo = getDB();
$admin = getCurrentAdmin();
$services = getServices($pdo, false);

// Filter by service
$selectedServiceId = (int)($_GET['service_id'] ?? 0);

// ============================================================================
// Handle POST Actions (Call Next, Update Status, Revert, Cancel)
// ============================================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    validatePostCsrf();
    $action = $_POST['action'] ?? '';

    // --- Action 1: Call Next Customer (FIFO with Transaction & Row Locking) ---
    if ($action === 'call_next') {
        $targetServiceId = (int)($_POST['service_id'] ?? 0);

        try {
            $pdo->beginTransaction();

            $sql = "SELECT r.id, r.service_id, r.customer_id, r.subject, t.token_number, c.full_name 
                    FROM requests r
                    JOIN tokens t ON t.request_id = r.id
                    JOIN customers c ON c.id = r.customer_id
                    WHERE r.status = 'Waiting'";
            
            $params = [];
            if ($targetServiceId > 0) {
                $sql .= " AND r.service_id = :sid";
                $params['sid'] = $targetServiceId;
            }
            $sql .= " ORDER BY r.created_at ASC, r.id ASC LIMIT 1 FOR UPDATE";

            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            $nextRequest = $stmt->fetch();

            if (!$nextRequest) {
                $pdo->rollBack();
                setFlash('info', 'No waiting customers in the queue to call.');
            } else {
                $reqId = (int)$nextRequest['id'];
                $svcId = (int)$nextRequest['service_id'];

                // Update request to Serving
                $upStmt = $pdo->prepare("UPDATE requests SET status = 'Serving', updated_at = NOW() WHERE id = :id");
                $upStmt->execute(['id' => $reqId]);

                // Log audit trail in status_history
                $auditNote = "Called to service counter by " . $admin['name'] . " (" . $admin['role'] . ")";
                logStatusChange($pdo, $reqId, 'Waiting', 'Serving', (int)$admin['id'], $auditNote);

                // Notify customer
                createNotification(
                    $pdo,
                    (int)$nextRequest['customer_id'],
                    $reqId,
                    'Now Serving at Desk',
                    "Token {$nextRequest['token_number']}: Please proceed to the service counter immediately."
                );

                $pdo->commit();

                // Recalculate remaining waiting positions
                recalculateQueuePositions($pdo, $svcId);

                setFlash('success', "Called Next Customer: Token {$nextRequest['token_number']} ({$nextRequest['full_name']}) is now SERVING.");
            }
        } catch (Exception $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            setFlash('error', 'Error calling next customer: ' . $e->getMessage());
        }

        header('Location: ' . BASE_URL . '/admin/queue.php' . ($targetServiceId > 0 ? '?service_id=' . $targetServiceId : ''));
        exit;
    }

    // --- Action 2: Update Request Status (Serving, Completed, Cancelled, Return to Waiting) ---
    if ($action === 'update_status') {
        $requestId = (int)($_POST['request_id'] ?? 0);
        $newStatus = trim($_POST['new_status'] ?? '');
        $note = trim($_POST['note'] ?? '');

        $validStatuses = ['Waiting', 'Serving', 'Completed', 'Cancelled'];
        if ($requestId <= 0 || !in_array($newStatus, $validStatuses)) {
            setFlash('error', 'Invalid request ID or target status specified.');
        } else {
            try {
                $pdo->beginTransaction();

                // Lock the request row
                $chkStmt = $pdo->prepare("SELECT id, service_id, status, customer_id FROM requests WHERE id = :id FOR UPDATE");
                $chkStmt->execute(['id' => $requestId]);
                $req = $chkStmt->fetch();

                if (!$req) {
                    $pdo->rollBack();
                    setFlash('error', 'Request not found in database.');
                } else {
                    $oldStatus = $req['status'];
                    $svcId = (int)$req['service_id'];

                    // Update request
                    if ($newStatus === 'Completed') {
                        $upStmt = $pdo->prepare("UPDATE requests SET status = :st, completed_at = NOW(), updated_at = NOW() WHERE id = :id");
                    } else {
                        $upStmt = $pdo->prepare("UPDATE requests SET status = :st, completed_at = NULL, updated_at = NOW() WHERE id = :id");
                    }
                    $upStmt->execute(['st' => $newStatus, 'id' => $requestId]);

                    // Audit history
                    $fullNote = !empty($note) ? $note : ("Status transitioned to " . $newStatus . " by " . $admin['name']);
                    logStatusChange($pdo, $requestId, $oldStatus, $newStatus, (int)$admin['id'], $fullNote);

                    // Notify customer on key milestones
                    if ($newStatus === 'Completed') {
                        createNotification($pdo, (int)$req['customer_id'], $requestId, 'Service Completed', 'Your request has been resolved. Thank you for using QueueLess AI.');
                    } elseif ($newStatus === 'Cancelled') {
                        createNotification($pdo, (int)$req['customer_id'], $requestId, 'Request Cancelled', 'Your queue request has been marked as cancelled.');
                    }

                    $pdo->commit();

                    // Recalculate queue positions
                    recalculateQueuePositions($pdo, $svcId);

                    setFlash('success', "Request #{$requestId} status updated from '{$oldStatus}' to '{$newStatus}'.");
                }
            } catch (Exception $e) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                setFlash('error', 'Failed to update request: ' . $e->getMessage());
            }
        }

        header('Location: ' . BASE_URL . '/admin/queue.php' . ($selectedServiceId > 0 ? '?service_id=' . $selectedServiceId : ''));
        exit;
    }
}

// ============================================================================
// Query Queue Lists
// ============================================================================

// A. Currently Serving
$servingSql = "
    SELECT 
        r.id, r.request_code, r.subject, r.description, r.branch_name, r.updated_at,
        c.full_name, c.mobile_number,
        s.service_name,
        t.token_number
    FROM requests r
    JOIN customers c ON c.id = r.customer_id
    JOIN services s ON s.id = r.service_id
    JOIN tokens t ON t.request_id = r.id
    WHERE r.status = 'Serving'
";
$servingParams = [];
if ($selectedServiceId > 0) {
    $servingSql .= " AND r.service_id = :sid";
    $servingParams['sid'] = $selectedServiceId;
}
$servingSql .= " ORDER BY r.updated_at DESC";
$servingStmt = $pdo->prepare($servingSql);
$servingStmt->execute($servingParams);
$servingCustomers = $servingStmt->fetchAll();

// B. Waiting in FIFO Queue
$waitingSql = "
    SELECT 
        r.id, r.request_code, r.subject, r.description, r.branch_name, r.priority, r.created_at,
        c.full_name, c.mobile_number,
        s.id AS service_id, s.service_name, s.average_service_minutes,
        t.token_number, t.queue_position
    FROM requests r
    JOIN customers c ON c.id = r.customer_id
    JOIN services s ON s.id = r.service_id
    JOIN tokens t ON t.request_id = r.id
    WHERE r.status = 'Waiting'
";
$waitingParams = [];
if ($selectedServiceId > 0) {
    $waitingSql .= " AND r.service_id = :sid";
    $waitingParams['sid'] = $selectedServiceId;
}
$waitingSql .= " ORDER BY r.created_at ASC, r.id ASC";
$waitingStmt = $pdo->prepare($waitingSql);
$waitingStmt->execute($waitingParams);
$waitingCustomers = $waitingStmt->fetchAll();

require_once __DIR__ . '/../includes/admin-header.php';
?>

<!-- Queue Filter Header Tabs -->
<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; flex-wrap: wrap; gap: 16px;">
    <div style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap;">
        <span style="font-size: 13px; font-weight: 700; color: var(--text-dim); text-transform: uppercase;">Service Queue:</span>
        <a href="<?php echo BASE_URL; ?>/admin/queue.php" class="btn btn-sm <?php echo $selectedServiceId === 0 ? 'btn-primary' : 'btn-secondary'; ?>">
            All Services (<?php echo count($waitingCustomers); ?>)
        </a>
        <?php foreach ($services as $svc): 
            $countStmt = $pdo->prepare("SELECT COUNT(*) FROM requests WHERE service_id = :sid AND status = 'Waiting'");
            $countStmt->execute(['sid' => $svc['id']]);
            $svcWaiting = (int)$countStmt->fetchColumn();
        ?>
            <a href="<?php echo BASE_URL; ?>/admin/queue.php?service_id=<?php echo $svc['id']; ?>" class="btn btn-sm <?php echo $selectedServiceId === (int)$svc['id'] ? 'btn-primary' : 'btn-secondary'; ?>">
                <?php echo htmlspecialchars($svc['service_name']); ?>
                <span style="font-size: 11px; opacity: 0.8; margin-left: 4px;">(<?php echo $svcWaiting; ?>)</span>
            </a>
        <?php endforeach; ?>
    </div>

    <div>
        <a href="<?php echo BASE_URL; ?>/admin/queue.php<?php echo $selectedServiceId > 0 ? '?service_id=' . $selectedServiceId : ''; ?>" class="btn btn-secondary btn-sm" title="Refresh Queue">
            <i class="fa-solid fa-arrows-rotate"></i> Sync Board
        </a>
    </div>
</div>

<!-- Queue Dispatcher Hero Block -->
<div class="queue-call-banner">
    <div class="call-banner-info">
        <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 4px;">
            <span class="live-pill" style="font-size: 11px;"><i class="fa-solid fa-headset"></i> Active Desk Dispatcher</span>
            <span style="font-size: 13px; color: #a5b4fc; font-weight: 600;">
                <?php echo count($waitingCustomers); ?> Customer(s) Waiting in Line
            </span>
        </div>
        <h2>Process Next Customer in FIFO Order</h2>
        <p>Safely advances the earliest queued customer to "Serving" status and triggers instant desk arrival alerts.</p>
    </div>

    <div class="call-actions">
        <form method="POST" action="<?php echo BASE_URL; ?>/admin/queue.php" onsubmit="window.playQueueChime();">
            <?php echo csrfField(); ?>
            <input type="hidden" name="action" value="call_next">
            <input type="hidden" name="service_id" value="<?php echo $selectedServiceId; ?>">
            <button type="submit" class="btn-call-next" <?php echo empty($waitingCustomers) ? 'disabled style="opacity: 0.6; cursor: not-allowed;"' : ''; ?>>
                <i class="fa-solid fa-bullhorn"></i>
                <span>Call Next Customer</span>
            </button>
        </form>
    </div>
</div>

<!-- SECTION 1: Now Serving Desks -->
<div class="card-box" style="margin-bottom: 30px; border-color: rgba(99, 102, 241, 0.35);">
    <div class="card-box-header">
        <h3 style="color: #38bdf8; display: flex; align-items: center; gap: 8px;">
            <i class="fa-solid fa-bell animate-pulse"></i> Currently Serving (<?php echo count($servingCustomers); ?> Active)
        </h3>
        <span style="font-size: 12px; color: var(--text-dim);">Live at Service Counters</span>
    </div>

    <?php if (!empty($servingCustomers)): ?>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 18px;">
            <?php foreach ($servingCustomers as $serv): ?>
                <div style="background: rgba(11, 16, 32, 0.85); border: 1px solid rgba(99, 102, 241, 0.4); border-radius: var(--radius-md); padding: 20px; box-shadow: 0 4px 15px rgba(0,0,0,0.3);">
                    <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 12px;">
                        <span class="table-token-badge" style="font-size: 18px; padding: 6px 12px;">
                            <?php echo htmlspecialchars($serv['token_number']); ?>
                        </span>
                        <span class="status-badge badge-serving">
                            <i class="fa-solid fa-circle-play"></i> In Consultation
                        </span>
                    </div>

                    <div style="font-size: 18px; font-weight: 700; color: #fff; margin-bottom: 2px;">
                        <?php echo htmlspecialchars($serv['full_name']); ?>
                    </div>
                    <div style="font-size: 13px; color: #38bdf8; margin-bottom: 8px;">
                        <?php echo htmlspecialchars($serv['service_name']); ?>
                        <?php if (!empty($serv['branch_name'])): ?>
                            &bull; <?php echo htmlspecialchars($serv['branch_name']); ?>
                        <?php endif; ?>
                    </div>

                    <div style="background: rgba(255,255,255,0.03); border: 1px solid var(--admin-card-border); border-radius: var(--radius-sm); padding: 10px; margin-bottom: 16px; font-size: 13px; color: var(--text-muted);">
                        <strong>Subject:</strong> <?php echo htmlspecialchars($serv['subject']); ?><br>
                        <span style="font-size: 11px; color: var(--text-dim);">Called <?php echo timeAgo($serv['updated_at']); ?> &bull; Mobile: <?php echo htmlspecialchars($serv['mobile_number']); ?></span>
                    </div>

                    <!-- Action Controls for Serving Customers -->
                    <div style="display: flex; gap: 8px; flex-wrap: wrap;">
                        <button type="button" class="btn btn-primary btn-sm" style="flex: 1;" onclick="openStatusModal(<?php echo $serv['id']; ?>, 'Serving', 'Completed', '<?php echo htmlspecialchars($serv['token_number']); ?>');">
                            <i class="fa-solid fa-check-double"></i> Mark Completed
                        </button>
                        <button type="button" class="btn btn-secondary btn-sm" title="Return to Waiting" onclick="openStatusModal(<?php echo $serv['id']; ?>, 'Serving', 'Waiting', '<?php echo htmlspecialchars($serv['token_number']); ?>');">
                            <i class="fa-solid fa-rotate-left"></i> Revert
                        </button>
                        <button type="button" class="btn btn-secondary btn-sm" style="color: var(--rose);" title="Cancel Request" onclick="openStatusModal(<?php echo $serv['id']; ?>, 'Serving', 'Cancelled', '<?php echo htmlspecialchars($serv['token_number']); ?>');">
                            <i class="fa-solid fa-ban"></i> Cancel
                        </button>
                        <a href="<?php echo BASE_URL; ?>/admin/request-details.php?id=<?php echo $serv['id']; ?>" class="btn btn-secondary btn-sm" title="View Details">
                            <i class="fa-solid fa-eye"></i>
                        </a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div style="text-align: center; padding: 30px; color: var(--text-dim); background: rgba(255,255,255,0.02); border-radius: var(--radius-md);">
            <i class="fa-solid fa-circle-check" style="font-size: 28px; color: var(--success); margin-bottom: 8px; display: block;"></i>
            No customers currently at the service desks. Click "Call Next Customer" above to begin serving the next token.
        </div>
    <?php endif; ?>
</div>

<!-- SECTION 2: FIFO Waiting Queue Table -->
<div class="card-box">
    <div class="card-box-header">
        <h3 style="color: #fbbf24; display: flex; align-items: center; gap: 8px;">
            <i class="fa-solid fa-hourglass-half"></i> Virtual Waiting Queue (<?php echo count($waitingCustomers); ?> Waiting in FIFO Order)
        </h3>
        <span style="font-size: 12px; color: var(--text-dim);">
            <i class="fa-solid fa-circle-info"></i> Sorted by Arrival Time (Earliest First)
        </span>
    </div>

    <div class="table-responsive">
        <table class="data-table">
            <thead>
                <tr>
                    <th style="width: 70px;">Rank</th>
                    <th>Token Number</th>
                    <th>Customer Name</th>
                    <th>Contact</th>
                    <th>Department</th>
                    <th>Est. Waiting Time*</th>
                    <th>Submitted</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($waitingCustomers)): ?>
                    <?php 
                    $rank = 1;
                    foreach ($waitingCustomers as $wait): 
                        // Estimated wait = (customers ahead) * average service minutes
                        $aheadCount = $rank - 1;
                        $estMinutes = calculateEstimatedWaitMinutes($pdo, (int)$wait['service_id'], $rank);
                    ?>
                        <tr>
                            <td>
                                <span style="display: inline-flex; width: 32px; height: 32px; border-radius: 50%; background: <?php echo $rank === 1 ? 'rgba(16, 185, 129, 0.2)' : 'rgba(255,255,255,0.05)'; ?>; color: <?php echo $rank === 1 ? '#34d399' : '#fff'; ?>; font-weight: 800; align-items: center; justify-content: center; font-size: 13px; border: 1px solid <?php echo $rank === 1 ? 'rgba(16, 185, 129, 0.4)' : 'rgba(255,255,255,0.1)'; ?>;">
                                    #<?php echo $rank; ?>
                                </span>
                            </td>
                            <td>
                                <span class="table-token-badge">
                                    <?php echo htmlspecialchars($wait['token_number']); ?>
                                </span>
                            </td>
                            <td>
                                <strong style="color: #fff;"><?php echo htmlspecialchars($wait['full_name']); ?></strong>
                                <div style="font-size: 12px; color: var(--text-dim); max-width: 220px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                                    <?php echo htmlspecialchars($wait['subject']); ?>
                                </div>
                            </td>
                            <td style="font-family: monospace; color: var(--text-muted); font-size: 13px;">
                                <?php echo htmlspecialchars($wait['mobile_number']); ?>
                            </td>
                            <td>
                                <span style="color: #38bdf8; font-weight: 600;"><?php echo htmlspecialchars($wait['service_name']); ?></span>
                                <?php if (!empty($wait['branch_name'])): ?>
                                    <div style="font-size: 11px; color: var(--text-dim);"><?php echo htmlspecialchars($wait['branch_name']); ?></div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span style="color: #fbbf24; font-weight: 700; font-size: 14px;">
                                    ~<?php echo $estMinutes; ?> mins
                                </span>
                                <div style="font-size: 11px; color: var(--text-dim);">
                                    <?php echo $aheadCount === 0 ? 'Next in line' : ($aheadCount . ' ahead'); ?>
                                </div>
                            </td>
                            <td style="color: var(--text-dim); font-size: 13px;">
                                <?php echo timeAgo($wait['created_at']); ?>
                            </td>
                            <td>
                                <div style="display: flex; gap: 6px;">
                                    <button type="button" class="btn btn-primary btn-sm" onclick="openStatusModal(<?php echo $wait['id']; ?>, 'Waiting', 'Serving', '<?php echo htmlspecialchars($wait['token_number']); ?>');" title="Serve Now">
                                        <i class="fa-solid fa-headset"></i> Serve
                                    </button>
                                    <a href="<?php echo BASE_URL; ?>/admin/request-details.php?id=<?php echo $wait['id']; ?>" class="btn-action-icon" title="View Full Details">
                                        <i class="fa-solid fa-eye"></i>
                                    </a>
                                    <button type="button" class="btn-action-icon" style="color: var(--rose);" onclick="openStatusModal(<?php echo $wait['id']; ?>, 'Waiting', 'Cancelled', '<?php echo htmlspecialchars($wait['token_number']); ?>');" title="Cancel Token">
                                        <i class="fa-solid fa-ban"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                        <?php $rank++; ?>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="8" style="text-align: center; padding: 40px; color: var(--text-dim);">
                            <i class="fa-solid fa-check" style="font-size: 32px; color: var(--success); margin-bottom: 12px; display: block;"></i>
                            No customers currently waiting in this service category!
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div style="padding-top: 16px; margin-top: 16px; border-top: 1px solid var(--admin-card-border); font-size: 12px; color: var(--text-dim);">
        * <strong>Estimated waiting time note:</strong> This duration is calculated by multiplying the number of customers ahead by the configured department service duration. It represents an operational benchmark and not a guaranteed time.
    </div>
</div>

<?php require_once __DIR__ . '/../includes/admin-footer.php'; ?>
