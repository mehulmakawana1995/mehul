# QueueLess AI — Smart Digital Queue Management System

[![PHP 8+](https://img.shields.io/badge/PHP-8.0%2B-blue.svg)](https://www.php.net/)
[![MySQL InnoDB](https://img.shields.io/badge/MySQL-InnoDB%20utf8mb4-orange.svg)](https://www.mysql.com/)
[![XAMPP Localhost](https://img.shields.io/badge/XAMPP-Apache%20%2B%20MySQL-fb7185.svg)](https://www.apachefriends.org/)
[![UI/UX](https://img.shields.io/badge/Design-Futuristic%20Glassmorphism-6366f1.svg)]()
[![Technothon 2026](https://img.shields.io/badge/Event-IT%20Institute%20Technothon-10b981.svg)]()

> **"Skip the Line, Save Your Time."**  
> An enterprise-grade, responsive digital queue management system designed to eliminate physical waiting lines in hospitals, academic institutions, government civic centers, and banking branches.

---

## 📌 Executive Summary

Traditional waiting queues result in overcrowded lobbies, customer anxiety, lost productivity, and unpredictable waiting times. **QueueLess AI** solves this by providing a unified digital portal where:

1. **Customers** can issue virtual tokens from their phone, receive immediate queue positions with wait-time estimations, and track status live without downloading an app.
2. **Administrators** operate an advanced command center with **strict FIFO dispatching**, row-level transaction concurrency locking, Chart.js metrics, and a full status change audit trail.
3. Both panels share the exact same normalized **MySQL database**, providing instant, real-time consistency.

---

## 🚀 Key Highlights & Technothon Innovations

* **Zero External Dependencies / No Paid APIs:** Runs 100% locally on Windows using standard XAMPP (Apache + MySQL/MariaDB).
* **Strict FIFO Queue Processing:** Processes waiting requests in exact First-In-First-Out sequence per department or globally.
* **Concurrency Locking (`FOR UPDATE`):** Prevents two desk officers from accidentally claiming the same waiting customer at the same millisecond.
* **Algorithmic Waiting Time Estimation:** Transparently calculates estimated wait time:
  $$\text{Estimated Wait} = (\text{Queue Position} - 1) \times \text{Average Service Duration}$$
* **HTML5 Web Audio Synthesizer:** Built-in polyphonic chime alerts desk staff when calling customers without requiring external audio files.
* **Audited Status History:** Every transition (`Waiting` $\to$ `Serving` $\to$ `Completed` $\to$ `Cancelled`) is timestamped and attributed to the specific administrator.
* **Printable Virtual Token Receipts:** Perforated slip design with quick QR styling, print trigger, and clipboard copy.

---

## 🛠️ Technology Stack

| Layer | Technologies Used |
|---|---|
| **Frontend** | HTML5, Modern CSS3 (Vanilla design tokens, CSS variables, Glassmorphism), JavaScript (ES6+) |
| **Backend** | PHP 8.0+ (PDO, Object-Oriented Architecture, Strict typing) |
| **Database** | MySQL / MariaDB (InnoDB Engine, `utf8mb4_unicode_ci`, Foreign Keys, Indexes) |
| **Local Server** | XAMPP (Apache 2.4 + MySQL 3306) |
| **Visuals & Charts**| Chart.js 4 (Line & Doughnut charts), Font Awesome 6 Icons, Google Fonts (Plus Jakarta Sans) |
| **Security** | CSRF Tokens, `password_hash()` BCRYPT, Prepared Statements, Session Hardening |

---

## 📂 Project Directory Structure

```
queueless_ai/
├── index.php                 # Public home landing page with live queue showcase
├── submit-query.php          # Customer query form & digital token generator
├── track-token.php           # Real-time token tracking radar & stepper timeline
├── my-requests.php           # Customer request history lookup by mobile number
├── feedback.php              # 5-star customer rating and review submission
├── admin-login.php           # Secure administrator sign-in page
├── admin-logout.php          # Session termination handler
├── create-admin.php          # Setup & admin provisioning utility (Web + CLI)
├── test_flows.php            # Automated 10-step end-to-end integration test
├── database.sql              # Normalized MySQL schema with seed data
├── SETUP.md                  # Comprehensive XAMPP installation guide
├── README.md                 # Project documentation & presentation script
├── admin/                    # Administrative Control Suite
│   ├── dashboard.php         # Analytics dashboard, KPIs & Chart.js charts
│   ├── queue.php             # Dedicated FIFO Live Queue Command Board
│   ├── requests.php          # Full requests directory with multi-filters
│   ├── request-details.php   # Deep-dive request inspection & audit log
│   ├── services.php          # Service departments & wait duration tuning
│   ├── customers.php         # Registered customer directory
│   └── settings.php          # System health diagnostics & maintenance
├── includes/                 # Reusable Core Modules
│   ├── config.php            # App constants, DB credentials & URL resolution
│   ├── db.php                # PDO database connection handler
│   ├── auth.php              # Session auth, role verification & password_verify
│   ├── csrf.php              # CSRF protection tokens and verification
│   ├── functions.php         # Queue calculation, badges & audit logging
│   ├── header.php            # Public layout header & navigation
│   ├── footer.php            # Public layout footer & branding
│   ├── admin-header.php      # Admin sidebar, topbar & navigation
│   └── admin-footer.php      # Admin status transition modals & scripts
└── assets/                   # Static Frontend Assets
    ├── css/
    │   ├── style.css         # Public dark/glassmorphic design system
    │   └── admin.css         # Admin operations console styles
    └── js/
        ├── main.js           # Public interactions, copy token, print receipt
        └── admin.js          # Web Audio chime, Chart.js & auto-refresh sync
```

---

## 🗄️ Database Architecture (`queueless_ai`)

The application features 8 normalized tables with foreign keys and cascade rules:

1. **`admins`**: Stores administrative users, roles (`superadmin`, `admin`, `operator`), and bcrypt password hashes.
2. **`customers`**: Stores unique customer profiles keyed by mobile number to prevent data duplication.
3. **`services`**: Stores service departments (`Hospital`, `School / College`, `Government Office`, `Banking`, `Customer Service`, `Other Services`) and their `average_service_minutes`.
4. **`requests`**: Stores customer queries, status (`Waiting`, `Serving`, `Completed`, `Cancelled`), priority, and timestamps.
5. **`tokens`**: Stores unique readable tokens (`QL-YYYYMMDD-XXXX`), queue date, and position.
6. **`status_history`**: Audit log recording every status change, previous status, timestamp, administrator ID, and desk remarks.
7. **`notifications`**: Customer notifications generated at key milestones.
8. **`feedback`**: Post-service customer evaluations (1–5 star ratings and comments).

---

## ⚡ Quick Start with XAMPP

1. Copy the folder to `C:\xampp\htdocs\queueless_ai`.
2. Start **Apache** and **MySQL** in XAMPP Control Panel.
3. Open `http://localhost/phpmyadmin/` and import `database.sql`.
4. Open the public site at [http://localhost/queueless_ai/](http://localhost/queueless_ai/).
5. Log into admin at [http://localhost/queueless_ai/admin-login.php](http://localhost/queueless_ai/admin-login.php) with:
   - **Username:** `admin`
   - **Password:** `Admin@12345`

*See [SETUP.md](SETUP.md) for detailed instructions.*

---

## ✅ Functional Verification Checklist

- [x] Customer submits query with validation
- [x] Unique token generated with format `QL-YYYYMMDD-XXXX`
- [x] Initial status set to `Waiting` in MySQL
- [x] Dynamic queue position and estimated wait time computed
- [x] Customer tracks token in real-time with verified mobile number
- [x] Admin logs in securely using `password_verify()`
- [x] Real-time Chart.js volume and category distribution charts load from DB
- [x] Admin calls next customer in strict FIFO order
- [x] Status changes to `Serving` and triggers customer notification
- [x] Admin marks request `Completed`
- [x] Status change audit log recorded with admin ID and timestamps
- [x] Eligible completed requests accept 1–5 star customer feedback
- [x] All 24 PHP source files pass syntax lint checks with 0 errors

---

**Developed for IT Institute Technothon 2026**
