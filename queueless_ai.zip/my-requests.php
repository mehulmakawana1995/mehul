<?php
/**
 * QueueLess AI — Customer Request History Portal
 */

$pageTitle = "My Requests";
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';

$pdo = getDB();
$mobileNumber = trim($_REQUEST['mobile_number'] ?? '');
$cleanMobile = preg_replace('/[^0-9]/', '', $mobileNumber);

$requestsList = [];
$customerInfo = null;
$searched = false;

if (!empty($cleanMobile)) {
    $searched = true;

    // 1. Fetch customer
    $custStmt = $pdo->prepare("SELECT id, full_name, mobile_number, email FROM customers WHERE mobile_number = :m LIMIT 1");
    $custStmt->execute(['m' => $cleanMobile]);
    $customerInfo = $custStmt->fetch();

    if ($customerInfo) {
        // 2. Fetch all requests
        $reqStmt = $pdo->prepare("
            SELECT 
                r.id AS request_id,
                r.request_code,
                r.subject,
                r.status,
                r.priority,
                r.branch_name,
                r.created_at,
                r.completed_at,
                s.service_name,
                t.token_number,
                fb.rating AS feedback_rating
            FROM requests r
            JOIN services s ON s.id = r.service_id
            LEFT JOIN tokens t ON t.request_id = r.id
            LEFT JOIN feedback fb ON fb.request_id = r.id
            WHERE r.customer_id = :cid
            ORDER BY r.created_at DESC
        ");
        $reqStmt->execute(['cid' => $customerInfo['id']]);
        $requestsList = $reqStmt->fetchAll();
    }
}

require_once __DIR__ . '/includes/header.php';
?>

<div class="container section-padding" style="padding-top: 40px;">
    <div style="max-width: 860px; margin: 0 auto;">
        
        <div style="text-align: center; margin-bottom: 36px;">
            <span class="section-tag">Customer Portal</span>
            <h1 style="font-size: 34px; margin-bottom: 12px;">My Request <span class="text-gradient">History</span></h1>
            <p style="color: var(--text-muted); font-size: 15px;">
                Enter your mobile number to view all your past and active digital tokens across all service departments.
            </p>

            <div class="form-card" style="padding: 24px; margin-top: 24px; text-align: left;">
                <form action="<?php echo BASE_URL; ?>/my-requests.php" method="GET" style="display: flex; gap: 14px; flex-wrap: wrap;">
                    <div style="flex: 1; min-width: 260px;">
                        <label for="mobile_input" style="font-size: 13px;">Registered Mobile Number</label>
                        <div class="input-with-icon">
                            <i class="fa-solid fa-phone"></i>
                            <input type="tel" id="mobile_input" name="mobile_number" class="form-control" placeholder="10-digit mobile number" value="<?php echo htmlspecialchars($cleanMobile); ?>" required pattern="[0-9]{10}" maxlength="10">
                        </div>
                    </div>
                    <div style="align-self: flex-end;">
                        <button type="submit" class="btn btn-primary" style="height: 48px; padding: 0 24px;">
                            <i class="fa-solid fa-list-check"></i> Look Up Requests
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <?php if ($searched): ?>
            <?php if ($customerInfo && !empty($requestsList)): ?>
                <div class="card-box" style="margin-bottom: 24px;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
                        <div>
                            <h3 style="font-size: 18px; margin-bottom: 4px;">Requests for <?php echo htmlspecialchars($customerInfo['full_name']); ?></h3>
                            <span style="font-size: 13px; color: var(--text-muted);"><?php echo count($requestsList); ?> total request(s) found</span>
                        </div>
                        <a href="<?php echo BASE_URL; ?>/submit-query.php" class="btn btn-primary btn-sm">
                            <i class="fa-solid fa-plus"></i> New Request
                        </a>
                    </div>

                    <div class="table-responsive">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Token / Code</th>
                                    <th>Department</th>
                                    <th>Subject</th>
                                    <th>Date Issued</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($requestsList as $req): ?>
                                    <tr>
                                        <td>
                                            <span class="table-token-badge">
                                                <?php echo htmlspecialchars($req['token_number'] ?? $req['request_code']); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <strong style="color: #fff;"><?php echo htmlspecialchars($req['service_name']); ?></strong>
                                            <?php if (!empty($req['branch_name'])): ?>
                                                <div style="font-size: 12px; color: var(--text-dim);"><?php echo htmlspecialchars($req['branch_name']); ?></div>
                                            <?php endif; ?>
                                        </td>
                                        <td style="color: var(--text-muted); max-width: 220px;">
                                            <?php echo htmlspecialchars($req['subject']); ?>
                                        </td>
                                        <td style="color: var(--text-dim); font-size: 13px;">
                                            <?php echo formatDateTime($req['created_at']); ?>
                                        </td>
                                        <td>
                                            <?php echo getStatusBadge($req['status']); ?>
                                        </td>
                                        <td>
                                            <div style="display: flex; gap: 8px;">
                                                <a href="<?php echo BASE_URL; ?>/track-token.php?token_number=<?php echo urlencode($req['token_number']); ?>&mobile_number=<?php echo urlencode($customerInfo['mobile_number']); ?>" class="btn btn-secondary btn-sm" title="Live Track">
                                                    <i class="fa-solid fa-radar"></i> Track
                                                </a>
                                                <?php if ($req['status'] === 'Completed' && empty($req['feedback_rating'])): ?>
                                                    <a href="<?php echo BASE_URL; ?>/feedback.php?request_id=<?php echo $req['request_id']; ?>" class="btn btn-glow-cyan btn-sm" title="Rate Service">
                                                        <i class="fa-solid fa-star"></i> Rate
                                                    </a>
                                                <?php elseif (!empty($req['feedback_rating'])): ?>
                                                    <span style="font-size: 12px; color: #fbbf24; display: inline-flex; align-items: center; gap: 4px; padding: 4px 8px;">
                                                        <i class="fa-solid fa-star"></i> <?php echo $req['feedback_rating']; ?>/5
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php else: ?>
                <div class="card-box" style="text-align: center; padding: 40px;">
                    <div style="font-size: 40px; color: var(--text-dim); margin-bottom: 14px;">
                        <i class="fa-regular fa-folder-open"></i>
                    </div>
                    <h3 style="font-size: 20px; margin-bottom: 8px;">No Requests Found</h3>
                    <p style="color: var(--text-muted); font-size: 14px; margin-bottom: 20px;">
                        We couldn't find any tokens associated with mobile number <strong><?php echo htmlspecialchars($cleanMobile); ?></strong>.
                    </p>
                    <a href="<?php echo BASE_URL; ?>/submit-query.php" class="btn btn-primary">
                        <i class="fa-solid fa-plus-circle"></i> Generate Your First Token
                    </a>
                </div>
            <?php endif; ?>
        <?php endif; ?>

    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
