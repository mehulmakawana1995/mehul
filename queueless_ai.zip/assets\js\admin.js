/**
 * QueueLess AI — Admin Dashboard JavaScript
 * Charts, Audio Synthesizer, Modal Handlers & Auto-Refresh
 */

document.addEventListener('DOMContentLoaded', function () {
    // Mobile Sidebar Toggle
    const sidebarToggle = document.getElementById('adminSidebarToggle');
    const adminSidebar = document.querySelector('.admin-sidebar');
    if (sidebarToggle && adminSidebar) {
        sidebarToggle.addEventListener('click', function () {
            adminSidebar.classList.toggle('open');
        });
    }

    // Modern Web Audio Chime for "Call Next Customer"
    window.playQueueChime = function () {
        try {
            const ctx = new (window.AudioContext || window.webkitAudioContext)();
            const now = ctx.currentTime;
            
            // Note 1: E5
            const osc1 = ctx.createOscillator();
            const gain1 = ctx.createGain();
            osc1.type = 'sine';
            osc1.frequency.setValueAtTime(659.25, now);
            gain1.gain.setValueAtTime(0.15, now);
            gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.5);
            osc1.connect(gain1);
            gain1.connect(ctx.destination);
            osc1.start(now);
            osc1.stop(now + 0.5);

            // Note 2: G#5
            const osc2 = ctx.createOscillator();
            const gain2 = ctx.createGain();
            osc2.type = 'sine';
            osc2.frequency.setValueAtTime(830.61, now + 0.15);
            gain2.gain.setValueAtTime(0.15, now + 0.15);
            gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.7);
            osc2.connect(gain2);
            gain2.connect(ctx.destination);
            osc2.start(now + 0.15);
            osc2.stop(now + 0.7);

            // Note 3: B5
            const osc3 = ctx.createOscillator();
            const gain3 = ctx.createGain();
            osc3.type = 'sine';
            osc3.frequency.setValueAtTime(987.77, now + 0.3);
            gain3.gain.setValueAtTime(0.2, now + 0.3);
            gain3.gain.exponentialRampToValueAtTime(0.001, now + 1.1);
            osc3.connect(gain3);
            gain3.connect(ctx.destination);
            osc3.start(now + 0.3);
            osc3.stop(now + 1.1);
        } catch (e) {
            console.log('Audio notification chime not supported:', e);
        }
    };

    // Auto-refresh control (15-second interval)
    const autoRefreshToggle = document.getElementById('autoRefreshToggle');
    const refreshTimerEl = document.getElementById('adminRefreshTimer');
    
    if (refreshTimerEl) {
        let isAutoRefresh = localStorage.getItem('queueless_auto_refresh') !== 'false';
        if (autoRefreshToggle) {
            autoRefreshToggle.checked = isAutoRefresh;
            autoRefreshToggle.addEventListener('change', function () {
                isAutoRefresh = this.checked;
                localStorage.setItem('queueless_auto_refresh', isAutoRefresh ? 'true' : 'false');
            });
        }

        let secondsRemaining = 15;
        setInterval(() => {
            if (isAutoRefresh) {
                secondsRemaining--;
                refreshTimerEl.textContent = secondsRemaining + 's';
                if (secondsRemaining <= 0) {
                    window.location.reload();
                }
            } else {
                refreshTimerEl.textContent = 'Paused';
            }
        }, 1000);
    }

    // Quick Status Update Modal Handler
    const statusModal = document.getElementById('statusUpdateModal');
    const statusForm = document.getElementById('statusUpdateForm');
    const modalCloseBtn = document.getElementById('closeStatusModal');
    const cancelModalBtn = document.getElementById('cancelStatusModal');

    window.openStatusModal = function (requestId, currentStatus, targetStatus, tokenNumber) {
        if (!statusModal) return;
        document.getElementById('modalRequestId').value = requestId;
        document.getElementById('modalTargetStatus').value = targetStatus;
        document.getElementById('modalTokenBadge').textContent = tokenNumber;
        document.getElementById('modalStatusText').textContent = targetStatus;
        statusModal.classList.add('active');
    };

    if (modalCloseBtn) {
        modalCloseBtn.addEventListener('click', () => statusModal.classList.remove('active'));
    }
    if (cancelModalBtn) {
        cancelModalBtn.addEventListener('click', () => statusModal.classList.remove('active'));
    }

    // Close modal on click outside
    window.addEventListener('click', function (e) {
        if (e.target === statusModal) {
            statusModal.classList.remove('active');
        }
    });

    // Chart.js Visualizations (Dashboard page)
    const dailyChartCanvas = document.getElementById('dailyRequestsChart');
    if (dailyChartCanvas && window.Chart && window.DAILY_CHART_DATA) {
        new Chart(dailyChartCanvas, {
            type: 'line',
            data: {
                labels: window.DAILY_CHART_DATA.labels || [],
                datasets: [{
                    label: 'Requests',
                    data: window.DAILY_CHART_DATA.values || [],
                    borderColor: '#6366f1',
                    backgroundColor: 'rgba(99, 102, 241, 0.15)',
                    borderWidth: 3,
                    pointBackgroundColor: '#38bdf8',
                    pointBorderColor: '#ffffff',
                    pointBorderWidth: 2,
                    pointRadius: 5,
                    fill: true,
                    tension: 0.38
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        backgroundColor: '#111827',
                        titleColor: '#f8fafc',
                        bodyColor: '#cbd5e1',
                        borderColor: 'rgba(255,255,255,0.1)',
                        borderWidth: 1,
                        padding: 12
                    }
                },
                scales: {
                    x: {
                        grid: { color: 'rgba(255, 255, 255, 0.05)' },
                        ticks: { color: '#94a3b8' }
                    },
                    y: {
                        beginAtZero: true,
                        grid: { color: 'rgba(255, 255, 255, 0.05)' },
                        ticks: { color: '#94a3b8', stepSize: 1 }
                    }
                }
            }
        });
    }

    const categoryChartCanvas = document.getElementById('categoryDistributionChart');
    if (categoryChartCanvas && window.Chart && window.CATEGORY_CHART_DATA) {
        new Chart(categoryChartCanvas, {
            type: 'doughnut',
            data: {
                labels: window.CATEGORY_CHART_DATA.labels || [],
                datasets: [{
                    data: window.CATEGORY_CHART_DATA.values || [],
                    backgroundColor: [
                        '#6366f1',
                        '#06b6d4',
                        '#10b981',
                        '#f59e0b',
                        '#8b5cf6',
                        '#64748b'
                    ],
                    borderColor: '#0f172a',
                    borderWidth: 3
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            color: '#94a3b8',
                            boxWidth: 12,
                            padding: 14,
                            font: { size: 12 }
                        }
                    }
                },
                cutout: '70%'
            }
        });
    }
});
