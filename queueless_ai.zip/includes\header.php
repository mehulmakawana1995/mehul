<?php
/**
 * QueueLess AI — Public Layout Header
 */
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/functions.php';

$currentPage = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="QueueLess AI — Smart digital queue management system for hospitals, colleges, banks, and government offices. Skip physical lines and track tokens in real time.">
    <meta name="theme-color" content="#070a13">
    <title><?php echo isset($pageTitle) ? htmlspecialchars($pageTitle) . ' — ' . APP_NAME : APP_NAME . ' — ' . APP_TAGLINE; ?></title>

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

    <!-- Font Awesome 6 CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <!-- Application Stylesheet -->
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/assets/css/style.css">
</head>
<body>
    <header class="site-header">
        <div class="container">
            <nav class="navbar">
                <a href="<?php echo BASE_URL; ?>/index.php" class="brand-logo">
                    <div class="brand-icon">
                        <i class="fa-solid fa-bolt-lightning"></i>
                    </div>
                    <span>Queue<span style="color: var(--cyan);">Less</span> AI</span>
                    <span class="brand-badge">Technothon 2026</span>
                </a>

                <ul class="nav-links">
                    <li><a href="<?php echo BASE_URL; ?>/index.php" class="<?php echo $currentPage === 'index.php' ? 'active' : ''; ?>"><i class="fa-solid fa-house"></i> Home</a></li>
                    <li><a href="<?php echo BASE_URL; ?>/submit-query.php" class="<?php echo $currentPage === 'submit-query.php' ? 'active' : ''; ?>"><i class="fa-solid fa-ticket"></i> Get Token</a></li>
                    <li><a href="<?php echo BASE_URL; ?>/track-token.php" class="<?php echo $currentPage === 'track-token.php' ? 'active' : ''; ?>"><i class="fa-solid fa-magnifying-glass-chart"></i> Track Token</a></li>
                    <li><a href="<?php echo BASE_URL; ?>/my-requests.php" class="<?php echo $currentPage === 'my-requests.php' ? 'active' : ''; ?>"><i class="fa-solid fa-list-check"></i> My Requests</a></li>
                    <li><a href="<?php echo BASE_URL; ?>/feedback.php" class="<?php echo $currentPage === 'feedback.php' ? 'active' : ''; ?>"><i class="fa-solid fa-star"></i> Feedback</a></li>
                </ul>

                <div class="nav-actions">
                    <a href="<?php echo BASE_URL; ?>/admin-login.php" class="btn btn-outline-admin btn-sm">
                        <i class="fa-solid fa-shield-halved"></i> Admin Portal
                    </a>
                    <a href="<?php echo BASE_URL; ?>/submit-query.php" class="btn btn-primary btn-sm">
                        <i class="fa-solid fa-plus-circle"></i> Generate Token
                    </a>
                    <button type="button" class="menu-toggle" aria-label="Toggle Navigation">
                        <i class="fa-solid fa-bars"></i>
                    </button>
                </div>
            </nav>
        </div>
    </header>

    <main class="site-main">
        <div class="container" style="padding-top: 20px;">
            <?php echo renderFlash(); ?>
        </div>
