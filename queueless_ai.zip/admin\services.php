<?php
/**
 * QueueLess AI — Services & Department Configuration
 */

$adminTitle = "Service Departments & Queue Parameters";
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/functions.php';

$pdo = getDB();

// Handle Service Updates or Creations
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    validatePostCsrf();
    $action = $_POST['action'] ?? '';

    if ($action === 'save_service') {
        $serviceId = (int)($_POST['service_id'] ?? 0);
        $serviceName = trim($_POST['service_name'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $avgMinutes = max(1, (int)($_POST['average_service_minutes'] ?? 15));
        $isActive = isset($_POST['is_active']) ? 1 : 0;

        if (empty($serviceName)) {
            setFlash('error', 'Service Name cannot be empty.');
        } else {
            try {
                if ($serviceId > 0) {
                    $upStmt = $pdo->prepare("
                        UPDATE services 
                        SET service_name = :n, description = :d, average_service_minutes = :m, is_active = :a 
                        WHERE id = :id
                    ");
                    $upStmt->execute([
                        'n'  => $serviceName,
                        'd'  => $description,
                        'm'  => $avgMinutes,
                        'a'  => $isActive,
                        'id' => $serviceId
                    ]);
                    setFlash('success', "Service '{$serviceName}' updated successfully.");
                } else {
                    $inStmt = $pdo->prepare("
                        INSERT INTO services (service_name, description, average_service_minutes, is_active, created_at)
                        VALUES (:n, :d, :m, :a, NOW())
                    ");
                    $inStmt->execute([
                        'n' => $serviceName,
                        'd' => $description,
                        'm' => $avgMinutes,
                        'a' => $isActive
                    ]);
                    setFlash('success', "New Service '{$serviceName}' created successfully.");
                }
            } catch (Exception $e) {
                setFlash('error', 'Database Error: ' . $e->getMessage());
            }
        }
        header('Location: ' . BASE_URL . '/admin/services.php');
        exit;
    }
}

// Fetch all services with statistics
$servicesList = $pdo->query("
    SELECT 
        s.id, s.service_name, s.description, s.average_service_minutes, s.is_active, s.created_at,
        COUNT(r.id) AS total_requests,
        SUM(CASE WHEN r.status = 'Waiting' THEN 1 ELSE 0 END) AS waiting_count,
        SUM(CASE WHEN r.status = 'Serving' THEN 1 ELSE 0 END) AS serving_count
    FROM services s
    LEFT JOIN requests r ON r.service_id = s.id
    GROUP BY s.id
    ORDER BY s.id ASC
")->fetchAll();

require_once __DIR__ . '/../includes/admin-header.php';
?>

<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px;">
    <div>
        <h2 style="font-size: 20px; margin-bottom: 4px;">Service Departments & Wait Time Calibration</h2>
        <p style="color: var(--text-muted); font-size: 14px;">
            Configure average service durations per person to adjust automatic waiting time estimations across customer trackers.
        </p>
    </div>
</div>

<div style="display: grid; grid-template-columns: 2fr 1fr; gap: 24px;">
    <!-- Left Column: Services Table -->
    <div class="card-box">
        <div class="card-box-header">
            <h3><i class="fa-solid fa-cubes-stacked"></i> Configured Departments (<?php echo count($servicesList); ?>)</h3>
        </div>

        <div class="table-responsive">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Department</th>
                        <th>Avg Time / Person</th>
                        <th>Waiting</th>
                        <th>Serving</th>
                        <th>Total Requests</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($servicesList as $svc): ?>
                        <tr>
                            <td>
                                <strong style="color: #fff; font-size: 15px;"><?php echo htmlspecialchars($svc['service_name']); ?></strong>
                                <div style="font-size: 12px; color: var(--text-dim); max-width: 250px;">
                                    <?php echo htmlspecialchars($svc['description'] ?? ''); ?>
                                </div>
                            </td>
                            <td>
                                <span style="font-weight: 700; color: #38bdf8; font-size: 15px;">
                                    <?php echo $svc['average_service_minutes']; ?> min
                                </span>
                            </td>
                            <td>
                                <span style="color: #fbbf24; font-weight: 700;"><?php echo $svc['waiting_count']; ?></span>
                            </td>
                            <td>
                                <span style="color: #38bdf8; font-weight: 700;"><?php echo $svc['serving_count']; ?></span>
                            </td>
                            <td style="color: var(--text-muted);"><?php echo $svc['total_requests']; ?></td>
                            <td>
                                <?php if ($svc['is_active']): ?>
                                    <span style="color: var(--success); font-size: 12px;"><i class="fa-solid fa-circle-check"></i> Active</span>
                                <?php else: ?>
                                    <span style="color: var(--danger); font-size: 12px;"><i class="fa-solid fa-circle-xmark"></i> Inactive</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <button type="button" class="btn-action-icon" title="Edit Parameters" onclick='editService(<?php echo json_encode($svc); ?>);'>
                                    <i class="fa-solid fa-pen-to-square"></i>
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Right Column: Add / Edit Service Form -->
    <div class="card-box" id="serviceFormBox">
        <div class="card-box-header">
            <h3 id="formTitle"><i class="fa-solid fa-plus"></i> Add New Department</h3>
        </div>

        <form method="POST" action="<?php echo BASE_URL; ?>/admin/services.php" id="serviceForm">
            <?php echo csrfField(); ?>
            <input type="hidden" name="action" value="save_service">
            <input type="hidden" name="service_id" id="svc_id" value="0">

            <div class="form-group">
                <label for="svc_name">Service Department Name <span class="required">*</span></label>
                <input type="text" id="svc_name" name="service_name" class="form-control" placeholder="e.g. Diagnostic Lab, Finance" required>
            </div>

            <div class="form-group">
                <label for="svc_minutes">Avg Service Minutes per Customer <span class="required">*</span></label>
                <input type="number" id="svc_minutes" name="average_service_minutes" class="form-control" placeholder="15" min="1" max="180" value="15" required>
                <span class="form-text">Used to dynamically compute estimated wait times for all waiting tokens.</span>
            </div>

            <div class="form-group">
                <label for="svc_desc">Short Description:</label>
                <textarea id="svc_desc" name="description" class="form-control" placeholder="Inquiries handled by this counter..." rows="3"></textarea>
            </div>

            <div class="form-group" style="display: flex; align-items: center; gap: 8px;">
                <input type="checkbox" id="svc_active" name="is_active" value="1" checked style="accent-color: var(--primary);">
                <label for="svc_active" style="margin: 0; cursor: pointer;">Enable for public token generation</label>
            </div>

            <div style="display: flex; gap: 10px; margin-top: 20px;">
                <button type="submit" class="btn btn-primary btn-block">
                    <span id="btnSubmitText">Save Department</span>
                </button>
                <button type="button" id="btnCancelEdit" class="btn btn-secondary" style="display: none;" onclick="resetServiceForm();">
                    Cancel
                </button>
            </div>
        </form>
    </div>
</div>

<script>
function editService(svc) {
    document.getElementById('formTitle').innerHTML = '<i class="fa-solid fa-pen"></i> Edit ' + svc.service_name;
    document.getElementById('svc_id').value = svc.id;
    document.getElementById('svc_name').value = svc.service_name;
    document.getElementById('svc_minutes').value = svc.average_service_minutes;
    document.getElementById('svc_desc').value = svc.description || '';
    document.getElementById('svc_active').checked = (parseInt(svc.is_active) === 1);
    document.getElementById('btnSubmitText').textContent = 'Update Parameters';
    document.getElementById('btnCancelEdit').style.display = 'inline-block';
    document.getElementById('serviceFormBox').scrollIntoView({ behavior: 'smooth' });
}

function resetServiceForm() {
    document.getElementById('formTitle').innerHTML = '<i class="fa-solid fa-plus"></i> Add New Department';
    document.getElementById('svc_id').value = '0';
    document.getElementById('serviceForm').reset();
    document.getElementById('btnSubmitText').textContent = 'Save Department';
    document.getElementById('btnCancelEdit').style.display = 'none';
}
</script>

<?php require_once __DIR__ . '/../includes/admin-footer.php'; ?>
