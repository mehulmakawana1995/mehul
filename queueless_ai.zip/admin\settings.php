<?php
/**
 * QueueLess AI — System & Queue Configuration Settings
 */

$adminTitle = "System Configuration & Diagnostics";
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/functions.php';

$pdo = getDB();
$mysqlVersion = $pdo->query("SELECT VERSION()")->fetchColumn();

// Handle Reset Demo Queue Action
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    validatePostCsrf();
    $action = $_POST['action'] ?? '';

    if ($action === 'clear_completed') {
        $del = $pdo->exec("DELETE FROM requests WHERE status IN ('Completed', 'Cancelled')");
        setFlash('success', "Cleaned up {$del} archived (completed & cancelled) requests from database.");
        header('Location: ' . BASE_URL . '/admin/settings.php');
        exit;
    }
}

require_once __DIR__ . '/../includes/admin-header.php';
?>

<div style="max-width: 900px; margin: 0 auto;">

    <!-- System Diagnostics Card -->
    <div class="card-box" style="margin-bottom: 24px;">
        <div class="card-box-header">
            <h3><i class="fa-solid fa-server"></i> System Health & Environment Diagnostics</h3>
            <span class="live-pill" style="font-size: 11px;"><i class="fa-solid fa-circle-check"></i> System Operational</span>
        </div>

        <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 18px; font-size: 14px;">
            <div style="background: rgba(255,255,255,0.02); border: 1px solid var(--admin-card-border); border-radius: var(--radius-sm); padding: 14px;">
                <span style="color: var(--text-dim); display: block; font-size: 12px; text-transform: uppercase;">Application Build</span>
                <strong style="color: #fff;"><?php echo APP_NAME; ?> v<?php echo APP_VERSION; ?></strong>
                <div style="font-size: 12px; color: var(--text-muted); margin-top: 2px;">Prepared for <?php echo ORG_NAME; ?></div>
            </div>

            <div style="background: rgba(255,255,255,0.02); border: 1px solid var(--admin-card-border); border-radius: var(--radius-sm); padding: 14px;">
                <span style="color: var(--text-dim); display: block; font-size: 12px; text-transform: uppercase;">PHP Runtime</span>
                <strong style="color: #38bdf8;">PHP <?php echo phpversion(); ?></strong>
                <div style="font-size: 12px; color: var(--text-muted); margin-top: 2px;">Running on Apache / XAMPP</div>
            </div>

            <div style="background: rgba(255,255,255,0.02); border: 1px solid var(--admin-card-border); border-radius: var(--radius-sm); padding: 14px;">
                <span style="color: var(--text-dim); display: block; font-size: 12px; text-transform: uppercase;">MySQL Database Engine</span>
                <strong style="color: #34d399;">MySQL <?php echo htmlspecialchars($mysqlVersion); ?></strong>
                <div style="font-size: 12px; color: var(--text-muted); margin-top: 2px;">DB: <code><?php echo DB_NAME; ?></code> at <?php echo DB_HOST; ?>:<?php echo DB_PORT; ?></div>
            </div>

            <div style="background: rgba(255,255,255,0.02); border: 1px solid var(--admin-card-border); border-radius: var(--radius-sm); padding: 14px;">
                <span style="color: var(--text-dim); display: block; font-size: 12px; text-transform: uppercase;">Server Timezone & Clock</span>
                <strong style="color: #fff;"><?php echo date_default_timezone_get(); ?></strong>
                <div style="font-size: 12px; color: var(--text-muted); margin-top: 2px; font-family: monospace;"><?php echo date('Y-m-d H:i:s'); ?></div>
            </div>
        </div>
    </div>

    <!-- Queue Management Parameters -->
    <div class="card-box" style="margin-bottom: 24px;">
        <div class="card-box-header">
            <h3><i class="fa-solid fa-sliders"></i> Operational Queue Rules</h3>
        </div>

        <div style="display: flex; flex-direction: column; gap: 16px; font-size: 14px;">
            <div style="display: flex; justify-content: space-between; align-items: center; padding-bottom: 12px; border-bottom: 1px solid var(--admin-card-border);">
                <div>
                    <strong>FIFO Dispatch Algorithm</strong>
                    <div style="font-size: 13px; color: var(--text-dim);">Strict First-In-First-Out ordering enforced within each service department.</div>
                </div>
                <span class="badge-pill" style="color: var(--success);"><i class="fa-solid fa-lock"></i> Enabled (Active)</span>
            </div>

            <div style="display: flex; justify-content: space-between; align-items: center; padding-bottom: 12px; border-bottom: 1px solid var(--admin-card-border);">
                <div>
                    <strong>Concurrency Row-Level Locking</strong>
                    <div style="font-size: 13px; color: var(--text-dim);">Prevents simultaneous multi-admin desk dispatch conflicts using MySQL <code>FOR UPDATE</code> transactions.</div>
                </div>
                <span class="badge-pill" style="color: var(--success);"><i class="fa-solid fa-shield"></i> Enabled (Active)</span>
            </div>

            <div style="display: flex; justify-content: space-between; align-items: center; padding-bottom: 12px; border-bottom: 1px solid var(--admin-card-border);">
                <div>
                    <strong>Live Auto-Refresh Polling Cycle</strong>
                    <div style="font-size: 13px; color: var(--text-dim);">Configured dashboard and live tracker polling countdown interval.</div>
                </div>
                <strong style="color: #38bdf8;">15 Seconds</strong>
            </div>

            <div style="display: flex; justify-content: space-between; align-items: center;">
                <div>
                    <strong>Audio Synthesizer Bell</strong>
                    <div style="font-size: 13px; color: var(--text-dim);">Polyphonic audio chime on "Call Next Customer" dispatch via HTML5 Web Audio API.</div>
                </div>
                <button type="button" class="btn btn-secondary btn-sm" onclick="window.playQueueChime();">
                    <i class="fa-solid fa-volume-high"></i> Test Sound
                </button>
            </div>
        </div>
    </div>

    <!-- Data Maintenance & Cleanup -->
    <div class="card-box">
        <div class="card-box-header">
            <h3 style="color: var(--rose);"><i class="fa-solid fa-triangle-exclamation"></i> Maintenance Actions</h3>
        </div>

        <p style="color: var(--text-muted); font-size: 14px; margin-bottom: 18px;">
            Clean up old completed and cancelled records to refresh the queue board for subsequent live demonstrations.
        </p>

        <form method="POST" action="<?php echo BASE_URL; ?>/admin/settings.php" onsubmit="return confirm('Are you sure you want to delete completed and cancelled requests? Active and waiting requests will be preserved.');">
            <?php echo csrfField(); ?>
            <input type="hidden" name="action" value="clear_completed">
            <button type="submit" class="btn btn-secondary btn-sm" style="color: var(--rose); border-color: rgba(239,68,68,0.3);">
                <i class="fa-solid fa-broom"></i> Clear Finished & Cancelled Requests
            </button>
        </form>
    </div>

</div>

<?php require_once __DIR__ . '/../includes/admin-footer.php'; ?>
