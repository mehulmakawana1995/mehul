<?php
/**
 * QueueLess AI — Registered Customers Directory
 */

$adminTitle = "Registered Customers Directory";
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

$pdo = getDB();
$search = trim($_GET['search'] ?? '');

$sql = "
    SELECT 
        c.id, c.full_name, c.mobile_number, c.email, c.created_at,
        COUNT(r.id) AS total_requests,
        SUM(CASE WHEN r.status = 'Waiting' THEN 1 ELSE 0 END) AS active_waiting,
        SUM(CASE WHEN r.status = 'Serving' THEN 1 ELSE 0 END) AS active_serving,
        SUM(CASE WHEN r.status = 'Completed' THEN 1 ELSE 0 END) AS total_completed,
        MAX(r.created_at) AS last_request_at
    FROM customers c
    LEFT JOIN requests r ON r.customer_id = c.id
";

$params = [];
if (!empty($search)) {
    $sql .= " WHERE (c.full_name LIKE :s OR c.mobile_number LIKE :s OR c.email LIKE :s)";
    $params['s'] = "%{$search}%";
}

$sql .= " GROUP BY c.id ORDER BY last_request_at DESC, c.id DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$customers = $stmt->fetchAll();

require_once __DIR__ . '/../includes/admin-header.php';
?>

<div class="card-box" style="margin-bottom: 24px;">
    <div class="card-box-header">
        <h3><i class="fa-solid fa-address-book"></i> Customers Directory</h3>
        <span style="font-size: 13px; color: var(--text-dim);"><?php echo count($customers); ?> Customer(s) Registered</span>
    </div>

    <form method="GET" action="<?php echo BASE_URL; ?>/admin/customers.php" class="filter-bar">
        <div style="flex: 1; max-width: 400px;">
            <input type="text" name="search" class="admin-search-input" placeholder="Search customer name, mobile, email..." value="<?php echo htmlspecialchars($search); ?>" style="width: 100%;">
        </div>
        <div>
            <button type="submit" class="btn btn-primary btn-sm">
                <i class="fa-solid fa-magnifying-glass"></i> Search
            </button>
            <?php if (!empty($search)): ?>
                <a href="<?php echo BASE_URL; ?>/admin/customers.php" class="btn btn-secondary btn-sm" style="color: var(--rose);">
                    <i class="fa-solid fa-xmark"></i> Clear
                </a>
            <?php endif; ?>
        </div>
    </form>
</div>

<div class="card-box">
    <div class="table-responsive">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Customer Name</th>
                    <th>Mobile Number</th>
                    <th>Email</th>
                    <th>Registered Since</th>
                    <th>Total Requests</th>
                    <th>Active Tokens</th>
                    <th>Last Activity</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($customers)): ?>
                    <?php foreach ($customers as $cust): ?>
                        <tr>
                            <td>
                                <strong style="color: #fff; font-size: 15px;"><?php echo htmlspecialchars($cust['full_name']); ?></strong>
                            </td>
                            <td style="font-family: monospace; color: #38bdf8;">
                                <?php echo htmlspecialchars($cust['mobile_number']); ?>
                            </td>
                            <td style="color: var(--text-muted);">
                                <?php echo !empty($cust['email']) ? htmlspecialchars($cust['email']) : '<span style="color: var(--text-dim);">—</span>'; ?>
                            </td>
                            <td style="color: var(--text-dim); font-size: 13px;">
                                <?php echo formatDateTime($cust['created_at'], false); ?>
                            </td>
                            <td>
                                <span style="font-weight: 700; color: #fff;"><?php echo $cust['total_requests']; ?></span>
                            </td>
                            <td>
                                <?php if ($cust['active_waiting'] > 0 || $cust['active_serving'] > 0): ?>
                                    <span style="color: #fbbf24; font-weight: 700;">
                                        <?php echo ($cust['active_waiting'] + $cust['active_serving']); ?> Active
                                    </span>
                                <?php else: ?>
                                    <span style="color: var(--text-dim);">0</span>
                                <?php endif; ?>
                            </td>
                            <td style="color: var(--text-dim); font-size: 13px;">
                                <?php echo timeAgo($cust['last_request_at']); ?>
                            </td>
                            <td>
                                <a href="<?php echo BASE_URL; ?>/admin/requests.php?search=<?php echo urlencode($cust['mobile_number']); ?>" class="btn btn-secondary btn-sm" title="View customer requests">
                                    <i class="fa-solid fa-list-check"></i> Requests
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="8" style="text-align: center; padding: 40px; color: var(--text-dim);">
                            No registered customers found.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/admin-footer.php'; ?>
