/**
 * QueueLess AI — Public Portal JavaScript
 */

document.addEventListener('DOMContentLoaded', function () {
    // Mobile navigation toggle
    const menuToggle = document.querySelector('.menu-toggle');
    const navLinks = document.querySelector('.nav-links');
    if (menuToggle && navLinks) {
        menuToggle.addEventListener('click', function () {
            navLinks.classList.toggle('open');
            const icon = menuToggle.querySelector('i');
            if (icon) {
                icon.classList.toggle('fa-bars');
                icon.classList.toggle('fa-xmark');
            }
        });
    }

    // Auto-dismiss alert boxes after 6 seconds
    const alerts = document.querySelectorAll('.alert-box');
    alerts.forEach(function (alert) {
        setTimeout(function () {
            alert.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
            alert.style.opacity = '0';
            alert.style.transform = 'translateY(-10px)';
            setTimeout(() => alert.remove(), 500);
        }, 6000);
    });

    // Copy Token to Clipboard
    const copyBtns = document.querySelectorAll('.btn-copy-token');
    copyBtns.forEach(function (btn) {
        btn.addEventListener('click', function () {
            const tokenText = this.getAttribute('data-token');
            if (tokenText && navigator.clipboard) {
                navigator.clipboard.writeText(tokenText).then(() => {
                    const originalHtml = this.innerHTML;
                    this.innerHTML = '<i class="fa-solid fa-check"></i> Copied!';
                    this.classList.add('btn-copied');
                    setTimeout(() => {
                        this.innerHTML = originalHtml;
                        this.classList.remove('btn-copied');
                    }, 2500);
                }).catch(() => {
                    alert('Copied token: ' + tokenText);
                });
            }
        });
    });

    // Print Receipt Handler
    const printBtns = document.querySelectorAll('.btn-print-token');
    printBtns.forEach(function (btn) {
        btn.addEventListener('click', function () {
            window.print();
        });
    });

    // Client-side validation on Query Submission Form
    const submitForm = document.getElementById('querySubmissionForm');
    if (submitForm) {
        submitForm.addEventListener('submit', function (e) {
            const phoneInput = document.getElementById('mobile_number');
            if (phoneInput) {
                const phoneVal = phoneInput.value.replace(/[^0-9]/g, '');
                if (phoneVal.length < 10) {
                    e.preventDefault();
                    alert('Please enter a valid 10-digit mobile number.');
                    phoneInput.focus();
                    return false;
                }
            }

            const submitBtn = submitForm.querySelector('button[type="submit"]');
            if (submitBtn) {
                submitBtn.disabled = true;
                submitBtn.innerHTML = '<i class="fa-solid fa-circle-notch fa-spin"></i> Generating Token...';
            }
        });
    }

    // Live Token Tracker Auto-refresh countdown (if on tracking page)
    const trackerContainer = document.getElementById('liveTokenTracker');
    if (trackerContainer) {
        let refreshSeconds = 15;
        const countdownEl = document.getElementById('refreshCountdown');

        const timer = setInterval(() => {
            refreshSeconds--;
            if (countdownEl) {
                countdownEl.textContent = refreshSeconds;
            }
            if (refreshSeconds <= 0) {
                clearInterval(timer);
                window.location.reload();
            }
        }, 1000);
    }
});
