<?php
/**
 * QueueLess AI — Comprehensive Requests Directory
 * Filtering, Search, and Pagination
 */

$adminTitle = "Customer Requests Directory";
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

$pdo = getDB();
$services = getServices($pdo, false);

// Filter Parameters
$searchQuery = trim($_GET['search'] ?? '');
$statusFilter = trim($_GET['status'] ?? '');
$serviceFilter = (int)($_GET['service_id'] ?? 0);
$fromDate = trim($_GET['from_date'] ?? '');
$toDate = trim($_GET['to_date'] ?? '');

$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 15;
$offset = ($page - 1) * $perPage;

$where = ["1=1"];
$params = [];

if (!empty($searchQuery)) {
    $where[] = "(t.token_number LIKE :q OR c.full_name LIKE :q OR c.mobile_number LIKE :q OR r.request_code LIKE :q OR r.subject LIKE :q)";
    $params['q'] = "%{$searchQuery}%";
}
if (!empty($statusFilter) && in_array($statusFilter, ['Waiting', 'Serving', 'Completed', 'Cancelled'])) {
    $where[] = "r.status = :st";
    $params['st'] = $statusFilter;
}
if ($serviceFilter > 0) {
    $where[] = "r.service_id = :sid";
    $params['sid'] = $serviceFilter;
}
if (!empty($fromDate)) {
    $where[] = "DATE(r.created_at) >= :fdate";
    $params['fdate'] = $fromDate;
}
if (!empty($toDate)) {
    $where[] = "DATE(r.created_at) <= :tdate";
    $params['tdate'] = $toDate;
}

$whereSql = implode(" AND ", $where);

// Count Total Filtered Records
$countSql = "
    SELECT COUNT(*) 
    FROM requests r
    JOIN customers c ON c.id = r.customer_id
    LEFT JOIN tokens t ON t.request_id = r.id
    WHERE {$whereSql}
";
$countStmt = $pdo->prepare($countSql);
$countStmt->execute($params);
$totalRecords = (int)$countStmt->fetchColumn();
$totalPages = max(1, ceil($totalRecords / $perPage));

// Fetch Records for Current Page
$sql = "
    SELECT 
        r.id, r.request_code, r.subject, r.status, r.priority, r.created_at, r.completed_at,
        c.id AS customer_id, c.full_name, c.mobile_number,
        s.service_name,
        t.token_number
    FROM requests r
    JOIN customers c ON c.id = r.customer_id
    JOIN services s ON s.id = r.service_id
    LEFT JOIN tokens t ON t.request_id = r.id
    WHERE {$whereSql}
    ORDER BY r.created_at DESC
    LIMIT {$perPage} OFFSET {$offset}
";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$requests = $stmt->fetchAll();

require_once __DIR__ . '/../includes/admin-header.php';
?>

<div class="card-box" style="margin-bottom: 24px;">
    <div class="card-box-header">
        <h3><i class="fa-solid fa-filter"></i> Search & Multi-Field Filters</h3>
        <span style="font-size: 13px; color: var(--text-dim);"><?php echo number_format($totalRecords); ?> request(s) found</span>
    </div>

    <form method="GET" action="<?php echo BASE_URL; ?>/admin/requests.php" class="filter-bar" style="align-items: flex-end;">
        <div style="flex: 2; min-width: 240px;">
            <label style="font-size: 12px; color: var(--text-dim); margin-bottom: 4px;">Search Keyword</label>
            <input type="text" name="search" class="form-control" placeholder="Search token, customer, phone, code..." value="<?php echo htmlspecialchars($searchQuery); ?>" style="height: 40px; padding-left: 14px;">
        </div>

        <div style="flex: 1; min-width: 170px;">
            <label style="font-size: 12px; color: var(--text-dim); margin-bottom: 4px;">Service Department</label>
            <select name="service_id" class="form-control" style="height: 40px;">
                <option value="">All Services</option>
                <?php foreach ($services as $s): ?>
                    <option value="<?php echo $s['id']; ?>" <?php echo $serviceFilter === (int)$s['id'] ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($s['service_name']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div style="flex: 1; min-width: 140px;">
            <label style="font-size: 12px; color: var(--text-dim); margin-bottom: 4px;">Status</label>
            <select name="status" class="form-control" style="height: 40px;">
                <option value="">All Statuses</option>
                <option value="Waiting" <?php echo $statusFilter === 'Waiting' ? 'selected' : ''; ?>>Waiting</option>
                <option value="Serving" <?php echo $statusFilter === 'Serving' ? 'selected' : ''; ?>>Serving</option>
                <option value="Completed" <?php echo $statusFilter === 'Completed' ? 'selected' : ''; ?>>Completed</option>
                <option value="Cancelled" <?php echo $statusFilter === 'Cancelled' ? 'selected' : ''; ?>>Cancelled</option>
            </select>
        </div>

        <div style="flex: 1; min-width: 140px;">
            <label style="font-size: 12px; color: var(--text-dim); margin-bottom: 4px;">From Date</label>
            <input type="date" name="from_date" class="form-control" value="<?php echo htmlspecialchars($fromDate); ?>" style="height: 40px; padding-left: 14px;">
        </div>

        <div style="flex: 1; min-width: 140px;">
            <label style="font-size: 12px; color: var(--text-dim); margin-bottom: 4px;">To Date</label>
            <input type="date" name="to_date" class="form-control" value="<?php echo htmlspecialchars($toDate); ?>" style="height: 40px; padding-left: 14px;">
        </div>

        <div style="display: flex; gap: 8px;">
            <button type="submit" class="btn btn-primary" style="height: 40px; padding: 0 18px;">
                <i class="fa-solid fa-magnifying-glass"></i> Filter
            </button>
            <a href="<?php echo BASE_URL; ?>/admin/requests.php" class="btn btn-secondary" style="height: 40px; padding: 0 14px;" title="Reset filters">
                <i class="fa-solid fa-rotate-left"></i>
            </a>
        </div>
    </form>
</div>

<!-- Requests Table Card -->
<div class="card-box">
    <div class="table-responsive">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Token Number</th>
                    <th>Request Code</th>
                    <th>Customer Name</th>
                    <th>Mobile</th>
                    <th>Department</th>
                    <th>Subject</th>
                    <th>Created</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($requests)): ?>
                    <?php foreach ($requests as $r): ?>
                        <tr>
                            <td>
                                <span class="table-token-badge">
                                    <?php echo htmlspecialchars($r['token_number'] ?? '—'); ?>
                                </span>
                            </td>
                            <td>
                                <code style="color: #cbd5e1;"><?php echo htmlspecialchars($r['request_code']); ?></code>
                            </td>
                            <td>
                                <strong style="color: #fff;"><?php echo htmlspecialchars($r['full_name']); ?></strong>
                            </td>
                            <td style="font-family: monospace; color: var(--text-muted);">
                                <?php echo htmlspecialchars($r['mobile_number']); ?>
                            </td>
                            <td style="color: #38bdf8;">
                                <?php echo htmlspecialchars($r['service_name']); ?>
                            </td>
                            <td style="color: var(--text-muted); max-width: 200px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                                <?php echo htmlspecialchars($r['subject']); ?>
                            </td>
                            <td style="color: var(--text-dim); font-size: 13px;">
                                <?php echo formatDateTime($r['created_at']); ?>
                            </td>
                            <td>
                                <?php echo getStatusBadge($r['status']); ?>
                            </td>
                            <td>
                                <div style="display: flex; gap: 6px;">
                                    <a href="<?php echo BASE_URL; ?>/admin/request-details.php?id=<?php echo $r['id']; ?>" class="btn-action-icon" title="View Full Details">
                                        <i class="fa-solid fa-eye"></i>
                                    </a>

                                    <?php if ($r['status'] === 'Waiting'): ?>
                                        <button type="button" class="btn-action-icon" style="color: #38bdf8;" title="Call to Serve" onclick="openStatusModal(<?php echo $r['id']; ?>, 'Waiting', 'Serving', '<?php echo htmlspecialchars($r['token_number']); ?>');">
                                            <i class="fa-solid fa-headset"></i>
                                        </button>
                                    <?php elseif ($r['status'] === 'Serving'): ?>
                                        <button type="button" class="btn-action-icon" style="color: #34d399;" title="Complete Service" onclick="openStatusModal(<?php echo $r['id']; ?>, 'Serving', 'Completed', '<?php echo htmlspecialchars($r['token_number']); ?>');">
                                            <i class="fa-solid fa-check"></i>
                                        </button>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="9" style="text-align: center; padding: 40px; color: var(--text-dim);">
                            No request records found matching the specified search parameters.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Pagination Controls -->
    <?php if ($totalPages > 1): ?>
        <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 24px; padding-top: 16px; border-top: 1px solid var(--admin-card-border); flex-wrap: wrap; gap: 12px;">
            <div style="font-size: 13px; color: var(--text-dim);">
                Showing page <strong><?php echo $page; ?></strong> of <strong><?php echo $totalPages; ?></strong> (<?php echo $totalRecords; ?> total)
            </div>

            <div style="display: flex; gap: 6px;">
                <?php 
                $queryParams = $_GET;
                if ($page > 1) {
                    $queryParams['page'] = $page - 1;
                    echo '<a href="' . BASE_URL . '/admin/requests.php?' . http_build_query($queryParams) . '" class="btn btn-secondary btn-sm">&larr; Previous</a>';
                }
                if ($page < $totalPages) {
                    $queryParams['page'] = $page + 1;
                    echo '<a href="' . BASE_URL . '/admin/requests.php?' . http_build_query($queryParams) . '" class="btn btn-secondary btn-sm">Next &rarr;</a>';
                }
                ?>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/admin-footer.php'; ?>
