<?php
/**
 * QueueLess AI — Database Connection Handler (PDO)
 */

require_once __DIR__ . '/config.php';

function getDB(): PDO {
    static $pdo = null;
    if ($pdo !== null) {
        return $pdo;
    }

    $dsn = "mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
        PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci"
    ];

    try {
        $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        return $pdo;
    } catch (PDOException $e) {
        // Render a modern, friendly diagnostic page if MySQL isn't reachable
        http_response_code(500);
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Database Connection Error — QueueLess AI</title>
            <style>
                body {
                    margin: 0;
                    padding: 0;
                    background: #0b0f19;
                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                    color: #f1f5f9;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    min-height: 100vh;
                }
                .error-card {
                    background: #111827;
                    border: 1px solid rgba(239, 68, 68, 0.3);
                    border-radius: 16px;
                    padding: 36px;
                    max-width: 580px;
                    box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.6);
                }
                .badge {
                    display: inline-block;
                    background: rgba(239, 68, 68, 0.15);
                    color: #f87171;
                    padding: 6px 14px;
                    border-radius: 9999px;
                    font-size: 13px;
                    font-weight: 600;
                    margin-bottom: 16px;
                }
                h1 { margin: 0 0 12px; font-size: 24px; color: #ffffff; }
                p { color: #94a3b8; line-height: 1.6; font-size: 15px; }
                .instructions {
                    background: #0a0e1a;
                    border: 1px solid #1f2937;
                    border-radius: 10px;
                    padding: 16px;
                    margin-top: 20px;
                    font-size: 14px;
                }
                ol { margin: 8px 0; padding-left: 20px; color: #cbd5e1; }
                li { margin-bottom: 6px; }
                code { background: #1e293b; color: #38bdf8; padding: 2px 6px; border-radius: 4px; font-size: 13px; }
                .retry-btn {
                    display: inline-block;
                    margin-top: 20px;
                    background: #4f46e5;
                    color: #ffffff;
                    text-decoration: none;
                    padding: 10px 20px;
                    border-radius: 8px;
                    font-weight: 600;
                    transition: background 0.2s;
                }
                .retry-btn:hover { background: #4338ca; }
            </style>
        </head>
        <body>
            <div class="error-card">
                <span class="badge">MySQL Service Disconnected</span>
                <h1>Unable to Connect to Database</h1>
                <p>QueueLess AI was unable to reach the MySQL database server at <code><?php echo htmlspecialchars(DB_HOST . ':' . DB_PORT); ?></code>.</p>
                <div class="instructions">
                    <strong>Quick Fix for XAMPP:</strong>
                    <ol>
                        <li>Open the <strong>XAMPP Control Panel</strong>.</li>
                        <li>Ensure <strong>MySQL</strong> has a green status indicator (Click <em>Start</em> if stopped).</li>
                        <li>Verify database <code><?php echo htmlspecialchars(DB_NAME); ?></code> was imported via phpMyAdmin using <code>database.sql</code>.</li>
                        <li>Check connection credentials in <code>includes/config.php</code>.</li>
                    </ol>
                </div>
                <a href="<?php echo htmlspecialchars($_SERVER['REQUEST_URI'] ?? '/'); ?>" class="retry-btn">Retry Connection</a>
            </div>
        </body>
        </html>
        <?php
        exit;
    }
}
