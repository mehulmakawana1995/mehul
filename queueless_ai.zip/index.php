<?php
/**
 * QueueLess AI — Public Landing Page
 * Technothon 2026 Showcase
 */

$pageTitle = "Skip the Line, Save Your Time";
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/header.php';

$pdo = getDB();
$services = getServices($pdo, true);
$stats = getQueueStats($pdo);

// Fetch currently serving customer for the live showcase card
$nowServingStmt = $pdo->query("
    SELECT r.id, r.request_code, t.token_number, s.service_name, r.branch_name, c.full_name, r.updated_at
    FROM requests r
    JOIN tokens t ON t.request_id = r.id
    JOIN services s ON s.id = r.service_id
    JOIN customers c ON c.id = r.customer_id
    WHERE r.status = 'Serving'
    ORDER BY r.updated_at DESC
    LIMIT 1
");
$nowServing = $nowServingStmt->fetch();
?>

<!-- Hero Section -->
<section class="hero-section">
    <div class="container">
        <div class="hero-grid">
            <div class="hero-content">
                <div class="hero-badge-tag">
                    <i class="fa-solid fa-sparkles"></i>
                    <span>Next-Generation Digital Queue Management</span>
                </div>

                <h1 class="hero-title">
                    Skip the Line, <br>
                    <span class="text-gradient">Save Your Time.</span>
                </h1>

                <p class="hero-desc">
                    QueueLess AI transforms frustrating physical waiting lines into seamless digital queues. Submit your request from your phone, receive an instant digital token, and arrive right when it's your turn.
                </p>

                <div class="hero-cta-group">
                    <a href="<?php echo BASE_URL; ?>/submit-query.php" class="btn btn-primary btn-lg">
                        <i class="fa-solid fa-ticket"></i> Generate Your Token
                    </a>
                    <a href="<?php echo BASE_URL; ?>/track-token.php" class="btn btn-glow-cyan btn-lg">
                        <i class="fa-solid fa-magnifying-glass-location"></i> Track My Token
                    </a>
                    <a href="<?php echo BASE_URL; ?>/admin-login.php" class="btn btn-secondary btn-lg">
                        <i class="fa-solid fa-shield-halved"></i> Admin Console
                    </a>
                </div>

                <div class="hero-trust-metrics">
                    <div class="trust-metric-item">
                        <h4><?php echo number_format($stats['total']); ?>+</h4>
                        <p>Total Digital Tokens Served</p>
                    </div>
                    <div class="trust-metric-item">
                        <h4 style="color: var(--cyan);"><?php echo $stats['waiting']; ?></h4>
                        <p>Currently in Virtual Queue</p>
                    </div>
                    <div class="trust-metric-item">
                        <h4 style="color: var(--success);"><?php echo $stats['completed']; ?></h4>
                        <p>Completed Successfully</p>
                    </div>
                </div>
            </div>

            <!-- Hero Live Card Showcase -->
            <div class="hero-visual">
                <div class="hero-live-card">
                    <div class="hero-card-header">
                        <span class="live-pill">
                            <span class="live-pulse-dot"></span> Live Queue Status
                        </span>
                        <span style="font-size: 13px; color: var(--text-muted); font-family: monospace;">
                            <?php echo date('H:i:s'); ?> IST
                        </span>
                    </div>

                    <?php if ($nowServing): ?>
                        <div class="active-queue-card">
                            <div>
                                <div style="font-size: 12px; color: #a5b4fc; text-transform: uppercase; font-weight: 700; margin-bottom: 4px;">
                                    <i class="fa-solid fa-bell animate-pulse"></i> Now Serving At Desk
                                </div>
                                <div style="font-size: 20px; font-weight: 800; color: #fff;">
                                    <?php echo htmlspecialchars($nowServing['full_name']); ?>
                                </div>
                                <div style="font-size: 13px; color: var(--text-dim); margin-top: 2px;">
                                    <?php echo htmlspecialchars($nowServing['service_name']); ?>
                                    <?php if (!empty($nowServing['branch_name'])): ?>
                                        &bull; <?php echo htmlspecialchars($nowServing['branch_name']); ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="token-big-badge">
                                <?php echo htmlspecialchars($nowServing['token_number']); ?>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="active-queue-card" style="justify-content: center; text-align: center;">
                            <div>
                                <div style="font-size: 14px; color: var(--text-muted);">
                                    <i class="fa-solid fa-circle-check" style="color: var(--success);"></i> All queues currently clear or pending operator call.
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <div style="background: rgba(255,255,255,0.03); border: 1px solid var(--border-subtle); border-radius: var(--radius-md); padding: 20px; margin-bottom: 20px;">
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
                            <span style="font-size: 13px; font-weight: 600; color: #cbd5e1;">Virtual Queue Load</span>
                            <span style="font-size: 12px; color: #38bdf8; font-weight: 700;"><?php echo $stats['waiting']; ?> waiting</span>
                        </div>
                        <div style="height: 8px; background: rgba(255,255,255,0.08); border-radius: 999px; overflow: hidden;">
                            <?php 
                                $loadPercent = min(100, max(15, ($stats['waiting'] * 12))); 
                            ?>
                            <div style="width: <?php echo $loadPercent; ?>%; height: 100%; background: linear-gradient(90deg, var(--primary), var(--cyan)); border-radius: 999px;"></div>
                        </div>
                    </div>

                    <!-- Fast Track Mini Form -->
                    <form action="<?php echo BASE_URL; ?>/track-token.php" method="GET" style="display: flex; gap: 8px;">
                        <input type="text" name="token_number" placeholder="Enter Token (e.g. QL-20261010-0001)" required class="form-control" style="font-size: 13px; padding-left: 14px;">
                        <button type="submit" class="btn btn-glow-cyan btn-sm">
                            <i class="fa-solid fa-magnifying-glass"></i> Track
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- How It Works Section -->
<section class="section-padding" style="background: rgba(14, 21, 38, 0.4); border-top: 1px solid var(--border-subtle); border-bottom: 1px solid var(--border-subtle);">
    <div class="container">
        <div class="section-header">
            <span class="section-tag">Frictionless Experience</span>
            <h2 class="section-title">How <span class="text-gradient">QueueLess AI</span> Works</h2>
            <p class="section-subtitle">A straightforward 4-step workflow that eliminates physical waiting rooms and keeps everyone informed.</p>
        </div>

        <div class="steps-grid">
            <div class="step-card">
                <span class="step-number">01</span>
                <div class="step-icon-wrap">
                    <i class="fa-solid fa-pen-to-square"></i>
                </div>
                <h3>Submit Query Online</h3>
                <p>Fill out a short digital form with your contact info, service category, and inquiry description from any mobile or desktop device.</p>
            </div>

            <div class="step-card">
                <span class="step-number">02</span>
                <div class="step-icon-wrap">
                    <i class="fa-solid fa-qrcode"></i>
                </div>
                <h3>Receive Digital Token</h3>
                <p>Instantly generate an authenticated token number with your exact position in queue and an estimated waiting time calculation.</p>
            </div>

            <div class="step-card">
                <span class="step-number">03</span>
                <div class="step-icon-wrap">
                    <i class="fa-solid fa-satellite-dish"></i>
                </div>
                <h3>Live Status Tracking</h3>
                <p>Track your token live from home, your car, or the cafeteria. Watch the status transition in real-time as admins serve requests.</p>
            </div>

            <div class="step-card">
                <span class="step-number">04</span>
                <div class="step-icon-wrap">
                    <i class="fa-solid fa-champagne-glasses"></i>
                </div>
                <h3>Direct Priority Service</h3>
                <p>Walk straight up to the assigned service desk when your token is called, finish your appointment, and share instant feedback.</p>
            </div>
        </div>
    </div>
</section>

<!-- Available Services Section -->
<section class="section-padding" id="services">
    <div class="container">
        <div class="section-header">
            <span class="section-tag">Supported Departments</span>
            <h2 class="section-title">Public & Private <span class="text-gradient">Service Desks</span></h2>
            <p class="section-subtitle">Optimized queue algorithms calibrated for healthcare, academic institutions, financial offices, and citizen centers.</p>
        </div>

        <div class="services-grid">
            <?php 
            $iconMap = [
                'Hospital'          => ['icon' => 'fa-hospital', 'class' => 'icon-hospital'],
                'School / College'  => ['icon' => 'fa-graduation-cap', 'class' => 'icon-college'],
                'Government Office' => ['icon' => 'fa-landmark', 'class' => 'icon-gov'],
                'Banking'           => ['icon' => 'fa-building-columns', 'class' => 'icon-bank'],
                'Customer Service'  => ['icon' => 'fa-headset', 'class' => 'icon-support'],
                'Other Services'    => ['icon' => 'fa-layer-group', 'class' => 'icon-other']
            ];

            foreach ($services as $service): 
                $cfg = $iconMap[$service['service_name']] ?? ['icon' => 'fa-briefcase', 'class' => 'icon-other'];
                
                // Count current waiting in this specific service
                $waitCountStmt = $pdo->prepare("SELECT COUNT(*) FROM requests WHERE service_id = :sid AND status = 'Waiting'");
                $waitCountStmt->execute(['sid' => $service['id']]);
                $catWaiting = (int)$waitCountStmt->fetchColumn();
            ?>
                <div class="service-box">
                    <div>
                        <div class="service-box-header">
                            <div class="service-icon <?php echo $cfg['class']; ?>">
                                <i class="fa-solid <?php echo $cfg['icon']; ?>"></i>
                            </div>
                            <span class="service-time-badge">
                                <i class="fa-regular fa-clock"></i> ~<?php echo $service['average_service_minutes']; ?> min / person
                            </span>
                        </div>
                        <h3><?php echo htmlspecialchars($service['service_name']); ?></h3>
                        <p><?php echo htmlspecialchars($service['description']); ?></p>
                    </div>

                    <div>
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; font-size: 13px;">
                            <span style="color: var(--text-dim);">Live Queue Depth:</span>
                            <span style="font-weight: 700; color: <?php echo $catWaiting > 0 ? '#fbbf24' : '#34d399'; ?>;">
                                <?php echo $catWaiting; ?> <?php echo $catWaiting === 1 ? 'person' : 'people'; ?> waiting
                            </span>
                        </div>
                        <a href="<?php echo BASE_URL; ?>/submit-query.php?service_id=<?php echo $service['id']; ?>" class="btn btn-secondary btn-block btn-sm">
                            <span>Get Token For <?php echo htmlspecialchars($service['service_name']); ?></span>
                            <i class="fa-solid fa-arrow-right"></i>
                        </a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- Quick Token Tracking Spotlight Section -->
<section class="section-padding" style="background: radial-gradient(circle at center, rgba(99, 102, 241, 0.08) 0%, transparent 70%);">
    <div class="container">
        <div style="max-width: 720px; margin: 0 auto;">
            <div class="form-card" style="text-align: center;">
                <div style="width: 60px; height: 60px; border-radius: 18px; background: rgba(6, 182, 212, 0.15); border: 1px solid rgba(6, 182, 212, 0.3); color: var(--cyan); display: flex; align-items: center; justify-content: center; margin: 0 auto 20px; font-size: 24px;">
                    <i class="fa-solid fa-magnifying-glass-arrow-right"></i>
                </div>
                <h2 style="font-size: 28px; margin-bottom: 10px;">Already Have a Token?</h2>
                <p style="color: var(--text-muted); font-size: 15px; margin-bottom: 30px;">
                    Enter your token number and registered mobile number to check your current place in line and estimated service time.
                </p>

                <form action="<?php echo BASE_URL; ?>/track-token.php" method="GET" style="text-align: left;">
                    <div class="form-row">
                        <div class="form-group">
                            <label for="track_token_input">Token Number <span class="required">*</span></label>
                            <div class="input-with-icon">
                                <i class="fa-solid fa-ticket"></i>
                                <input type="text" id="track_token_input" name="token_number" class="form-control" placeholder="e.g. QL-20261010-0001" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="track_mobile_input">Mobile Number <span class="required">*</span></label>
                            <div class="input-with-icon">
                                <i class="fa-solid fa-phone"></i>
                                <input type="tel" id="track_mobile_input" name="mobile_number" class="form-control" placeholder="10-digit mobile number" required pattern="[0-9]{10}">
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary btn-block btn-lg" style="margin-top: 10px;">
                        <i class="fa-solid fa-radar"></i> Check Live Queue Status
                    </button>
                </form>
            </div>
        </div>
    </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
