<?php
/**
 * QueueLess AI — Live Token Tracker
 */

$pageTitle = "Track My Token";
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';

$pdo = getDB();

$tokenNumber = trim($_REQUEST['token_number'] ?? '');
$mobileNumber = trim($_REQUEST['mobile_number'] ?? '');
$cleanMobile = preg_replace('/[^0-9]/', '', $mobileNumber);

$tokenData = null;
$statusHistory = [];
$searchError = null;

if (!empty($tokenNumber)) {
    // If mobile number wasn't provided, check if token exists alone first to prompt for mobile verification
    if (empty($cleanMobile)) {
        $searchError = "Please enter your registered 10-digit mobile number to verify and view this token's details.";
    } else {
        $stmt = $pdo->prepare("
            SELECT 
                r.id AS request_id,
                r.request_code,
                r.subject,
                r.description,
                r.status,
                r.priority,
                r.branch_name,
                r.created_at AS request_created_at,
                r.completed_at,
                c.id AS customer_id,
                c.full_name,
                c.mobile_number,
                c.email,
                s.id AS service_id,
                s.service_name,
                s.average_service_minutes,
                t.id AS token_id,
                t.token_number,
                t.queue_date,
                t.queue_position AS original_position
            FROM tokens t
            JOIN requests r ON r.id = t.request_id
            JOIN customers c ON c.id = r.customer_id
            JOIN services s ON s.id = r.service_id
            WHERE t.token_number = :tn AND c.mobile_number = :mn
            LIMIT 1
        ");
        $stmt->execute([
            'tn' => $tokenNumber,
            'mn' => $cleanMobile
        ]);
        $tokenData = $stmt->fetch();

        if (!$tokenData) {
            $searchError = "No request found matching token '{$tokenNumber}' with mobile number '{$cleanMobile}'. Please check your input.";
        } else {
            // Fetch status history audit log
            $histStmt = $pdo->prepare("
                SELECT sh.old_status, sh.new_status, sh.note, sh.changed_at, a.name AS admin_name
                FROM status_history sh
                LEFT JOIN admins a ON a.id = sh.changed_by_admin_id
                WHERE sh.request_id = :rid
                ORDER BY sh.changed_at ASC, sh.id ASC
            ");
            $histStmt->execute(['rid' => $tokenData['request_id']]);
            $statusHistory = $histStmt->fetchAll();

            // Calculate current live queue position
            $currentQueuePos = calculateQueuePosition($pdo, (int)$tokenData['service_id'], (int)$tokenData['request_id']);
            $estimatedWaitMins = calculateEstimatedWaitMinutes($pdo, (int)$tokenData['service_id'], $currentQueuePos);

            $tokenData['current_position'] = $currentQueuePos;
            $tokenData['estimated_wait_mins'] = $estimatedWaitMins;
        }
    }
}

require_once __DIR__ . '/includes/header.php';
?>

<div class="container section-padding" style="padding-top: 40px;" id="liveTokenTracker">

    <!-- Tracker Search Header -->
    <div style="max-width: 780px; margin: 0 auto 36px; text-align: center;">
        <span class="section-tag">Live Queue Radar</span>
        <h1 style="font-size: 34px; margin-bottom: 12px;">Track Your <span class="text-gradient">Token Status</span></h1>
        <p style="color: var(--text-muted); font-size: 15px;">
            Verify your token number and mobile number to see real-time updates as administrators call and process the queue.
        </p>

        <!-- Compact Search Form -->
        <div class="form-card" style="padding: 24px; margin-top: 24px; text-align: left;">
            <form action="<?php echo BASE_URL; ?>/track-token.php" method="GET" style="display: flex; gap: 14px; flex-wrap: wrap;">
                <div style="flex: 1; min-width: 220px;">
                    <label for="search_token" style="font-size: 13px;">Token Number</label>
                    <input type="text" id="search_token" name="token_number" class="form-control" placeholder="e.g. QL-20261010-0001" value="<?php echo htmlspecialchars($tokenNumber); ?>" required>
                </div>
                <div style="flex: 1; min-width: 220px;">
                    <label for="search_mobile" style="font-size: 13px;">Registered Mobile</label>
                    <input type="tel" id="search_mobile" name="mobile_number" class="form-control" placeholder="10-digit mobile number" value="<?php echo htmlspecialchars($cleanMobile); ?>" required pattern="[0-9]{10}" maxlength="10">
                </div>
                <div style="align-self: flex-end;">
                    <button type="submit" class="btn btn-primary" style="height: 48px; padding: 0 24px;">
                        <i class="fa-solid fa-radar"></i> Track
                    </button>
                </div>
            </form>
        </div>
    </div>

    <?php if ($searchError): ?>
        <div style="max-width: 780px; margin: 0 auto 30px;">
            <div class="alert-box alert-error">
                <i class="fa-solid fa-triangle-exclamation"></i>
                <span><?php echo htmlspecialchars($searchError); ?></span>
            </div>
        </div>
    <?php endif; ?>

    <?php if ($tokenData): ?>
        <!-- Main Token Status Showcase -->
        <div style="max-width: 820px; margin: 0 auto;">

            <!-- Status Banner Header -->
            <div class="card-box" style="margin-bottom: 24px; border-color: rgba(99, 102, 241, 0.3); background: rgba(17, 24, 43, 0.85);">
                <div style="display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 16px; margin-bottom: 20px;">
                    <div>
                        <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 6px;">
                            <span class="table-token-badge" style="font-size: 20px; padding: 6px 14px;">
                                <?php echo htmlspecialchars($tokenData['token_number']); ?>
                            </span>
                            <?php echo getStatusBadge($tokenData['status']); ?>
                        </div>
                        <div style="color: var(--text-muted); font-size: 14px;">
                            Customer: <strong><?php echo htmlspecialchars($tokenData['full_name']); ?></strong> &bull; <?php echo htmlspecialchars($tokenData['mobile_number']); ?>
                        </div>
                    </div>

                    <div style="text-align: right;">
                        <div class="auto-refresh-tag" style="display: inline-flex;">
                            <span class="refresh-dot"></span>
                            <span>Auto-refreshing in <strong id="refreshCountdown">15</strong>s</span>
                        </div>
                        <div style="margin-top: 8px;">
                            <a href="<?php echo BASE_URL; ?>/track-token.php?token_number=<?php echo urlencode($tokenData['token_number']); ?>&mobile_number=<?php echo urlencode($tokenData['mobile_number']); ?>" class="btn btn-secondary btn-sm" title="Refresh Now">
                                <i class="fa-solid fa-arrows-rotate"></i> Refresh Now
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Live Queue Situation Callout -->
                <?php if ($tokenData['status'] === 'Serving'): ?>
                    <div style="background: linear-gradient(135deg, rgba(99, 102, 241, 0.25), rgba(6, 182, 212, 0.2)); border: 1px solid var(--primary); border-radius: var(--radius-md); padding: 20px; margin-bottom: 24px; text-align: center;">
                        <div style="font-size: 13px; font-weight: 700; color: #38bdf8; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 4px;">
                            <i class="fa-solid fa-bell animate-pulse"></i> Attention Required
                        </div>
                        <div style="font-size: 24px; font-weight: 800; color: #fff; margin-bottom: 6px;">
                            Your Token is Currently Being Served!
                        </div>
                        <p style="color: #cbd5e1; font-size: 14px;">
                            Please proceed immediately to <strong><?php echo htmlspecialchars($tokenData['service_name']); ?></strong> 
                            (<?php echo htmlspecialchars($tokenData['branch_name'] ?? 'Counter Desk'); ?>).
                        </p>
                    </div>
                <?php elseif ($tokenData['status'] === 'Waiting'): ?>
                    <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; margin-bottom: 24px;">
                        <div style="background: rgba(245, 158, 11, 0.08); border: 1px solid rgba(245, 158, 11, 0.25); border-radius: var(--radius-md); padding: 18px; text-align: center;">
                            <div style="font-size: 12px; color: #fbbf24; text-transform: uppercase; font-weight: 700;">Position In Line</div>
                            <div style="font-size: 32px; font-weight: 800; color: #fff; margin-top: 4px;">
                                #<?php echo $tokenData['current_position']; ?>
                            </div>
                        </div>

                        <div style="background: rgba(99, 102, 241, 0.08); border: 1px solid rgba(99, 102, 241, 0.25); border-radius: var(--radius-md); padding: 18px; text-align: center;">
                            <div style="font-size: 12px; color: #a5b4fc; text-transform: uppercase; font-weight: 700;">Customers Ahead</div>
                            <div style="font-size: 32px; font-weight: 800; color: #fff; margin-top: 4px;">
                                <?php echo max(0, $tokenData['current_position'] - 1); ?>
                            </div>
                        </div>

                        <div style="background: rgba(6, 182, 212, 0.08); border: 1px solid rgba(6, 182, 212, 0.25); border-radius: var(--radius-md); padding: 18px; text-align: center;">
                            <div style="font-size: 12px; color: #67e8f9; text-transform: uppercase; font-weight: 700;">Estimated Wait</div>
                            <div style="font-size: 32px; font-weight: 800; color: #fff; margin-top: 4px;">
                                ~<?php echo $tokenData['estimated_wait_mins']; ?><span style="font-size: 16px; font-weight: 600;">m</span>
                            </div>
                        </div>
                    </div>
                <?php elseif ($tokenData['status'] === 'Completed'): ?>
                    <div style="background: rgba(16, 185, 129, 0.12); border: 1px solid rgba(16, 185, 129, 0.35); border-radius: var(--radius-md); padding: 20px; margin-bottom: 24px; display: flex; align-items: center; justify-content: space-between; flex-wrap: gap; gap: 14px;">
                        <div>
                            <div style="font-size: 18px; font-weight: 700; color: #34d399;">
                                <i class="fa-solid fa-circle-check"></i> Request Completed Successfully
                            </div>
                            <div style="font-size: 13px; color: var(--text-muted); margin-top: 4px;">
                                Completed on <?php echo formatDateTime($tokenData['completed_at'] ?? $tokenData['request_created_at']); ?>.
                            </div>
                        </div>
                        <a href="<?php echo BASE_URL; ?>/feedback.php?request_id=<?php echo $tokenData['request_id']; ?>" class="btn btn-glow-cyan btn-sm">
                            <i class="fa-solid fa-star"></i> Leave Feedback
                        </a>
                    </div>
                <?php elseif ($tokenData['status'] === 'Cancelled'): ?>
                    <div style="background: rgba(239, 68, 68, 0.12); border: 1px solid rgba(239, 68, 68, 0.35); border-radius: var(--radius-md); padding: 20px; margin-bottom: 24px;">
                        <div style="font-size: 18px; font-weight: 700; color: #f87171;">
                            <i class="fa-solid fa-circle-xmark"></i> Request Was Cancelled
                        </div>
                        <div style="font-size: 13px; color: var(--text-muted); margin-top: 4px;">
                            This token is no longer active in the virtual queue. Please submit a new query if you require further assistance.
                        </div>
                    </div>
                <?php endif; ?>

                <!-- Progress Stepper / Timeline -->
                <div class="timeline-tracker">
                    <div class="timeline-steps">
                        <?php 
                        $isWaitingDone = true;
                        $isServingActive = in_array($tokenData['status'], ['Serving', 'Completed']);
                        $isCompletedActive = ($tokenData['status'] === 'Completed');
                        ?>
                        <div class="timeline-step <?php echo $isWaitingDone ? 'completed' : 'active'; ?>">
                            <div class="timeline-step-icon">
                                <i class="fa-solid fa-ticket"></i>
                            </div>
                            <div class="timeline-step-label">Token Issued</div>
                            <div style="font-size: 11px; color: var(--text-dim);"><?php echo date('h:i A', strtotime($tokenData['request_created_at'])); ?></div>
                        </div>

                        <div class="timeline-step <?php echo $isServingActive ? ($isCompletedActive ? 'completed' : 'active') : ''; ?>">
                            <div class="timeline-step-icon">
                                <i class="fa-solid fa-headset"></i>
                            </div>
                            <div class="timeline-step-label">Serving at Desk</div>
                            <div style="font-size: 11px; color: var(--text-dim);">
                                <?php echo $tokenData['status'] === 'Serving' ? 'In Progress' : ($isCompletedActive ? 'Served' : 'Pending'); ?>
                            </div>
                        </div>

                        <div class="timeline-step <?php echo $isCompletedActive ? 'completed active' : ''; ?>">
                            <div class="timeline-step-icon">
                                <i class="fa-solid fa-flag-checkered"></i>
                            </div>
                            <div class="timeline-step-label">Completed</div>
                            <div style="font-size: 11px; color: var(--text-dim);">
                                <?php echo $isCompletedActive ? 'Resolved' : 'Pending'; ?>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Request Query Details Overview -->
                <div style="border-top: 1px solid var(--border-subtle); padding-top: 20px; margin-top: 20px;">
                    <div style="font-size: 14px; font-weight: 700; color: #cbd5e1; margin-bottom: 12px;">Query Details:</div>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 14px; font-size: 14px; margin-bottom: 16px;">
                        <div>
                            <span style="color: var(--text-dim);">Service Category:</span>
                            <div style="font-weight: 600; color: #fff;"><?php echo htmlspecialchars($tokenData['service_name']); ?></div>
                        </div>
                        <div>
                            <span style="color: var(--text-dim);">Department/Branch:</span>
                            <div style="font-weight: 600; color: #fff;"><?php echo htmlspecialchars($tokenData['branch_name'] ?? 'Main Desk'); ?></div>
                        </div>
                    </div>

                    <div style="background: rgba(255,255,255,0.02); border: 1px solid var(--border-subtle); border-radius: var(--radius-sm); padding: 14px;">
                        <div style="font-size: 12px; color: var(--text-dim); text-transform: uppercase;">Subject</div>
                        <div style="font-weight: 600; color: #fff; margin-bottom: 6px;"><?php echo htmlspecialchars($tokenData['subject']); ?></div>
                        <div style="font-size: 12px; color: var(--text-dim); text-transform: uppercase;">Description</div>
                        <div style="color: var(--text-muted); font-size: 13px; line-height: 1.5;"><?php echo nl2br(htmlspecialchars($tokenData['description'])); ?></div>
                    </div>
                </div>
            </div>

            <!-- Status History Audit Log -->
            <div class="card-box">
                <div class="card-box-header">
                    <h3><i class="fa-solid fa-clock-rotate-left"></i> Status Audit History</h3>
                    <span style="font-size: 12px; color: var(--text-dim);"><?php echo count($statusHistory); ?> event(s) recorded</span>
                </div>

                <?php if (!empty($statusHistory)): ?>
                    <div class="table-responsive">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Event Timestamp</th>
                                    <th>Transition</th>
                                    <th>Handled By</th>
                                    <th>Remarks / Desk Notes</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($statusHistory as $hist): ?>
                                    <tr>
                                        <td style="color: var(--text-muted); font-size: 13px;">
                                            <?php echo formatDateTime($hist['changed_at']); ?>
                                        </td>
                                        <td>
                                            <?php if ($hist['old_status']): ?>
                                                <?php echo getStatusBadge($hist['old_status']); ?> &rarr;
                                            <?php endif; ?>
                                            <?php echo getStatusBadge($hist['new_status']); ?>
                                        </td>
                                        <td style="color: #cbd5e1; font-size: 13px;">
                                            <?php echo htmlspecialchars($hist['admin_name'] ?? 'System / Online'); ?>
                                        </td>
                                        <td style="color: var(--text-muted); font-size: 13px;">
                                            <?php echo htmlspecialchars($hist['note'] ?? 'Status updated'); ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <p style="color: var(--text-muted); font-size: 14px;">No historical status changes recorded yet.</p>
                <?php endif; ?>
            </div>

        </div>
    <?php endif; ?>

</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
