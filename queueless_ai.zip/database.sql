-- ============================================================================
-- QueueLess AI — Smart Digital Queue Management System
-- Technothon Full-Stack Database Schema
-- Compatible with MySQL 5.7+ / MariaDB 10.4+ / XAMPP Apache + MySQL
-- ============================================================================

CREATE DATABASE IF NOT EXISTS `queueless_ai`
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE `queueless_ai`;

-- 1. Admins Table
CREATE TABLE IF NOT EXISTS `admins` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `username` VARCHAR(60) NOT NULL UNIQUE,
  `email` VARCHAR(120) NULL UNIQUE,
  `password_hash` VARCHAR(255) NOT NULL,
  `role` ENUM('superadmin', 'admin', 'operator') NOT NULL DEFAULT 'admin',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_admin_username` (`username`),
  INDEX `idx_admin_role` (`role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. Customers Table
CREATE TABLE IF NOT EXISTS `customers` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `full_name` VARCHAR(120) NOT NULL,
  `mobile_number` VARCHAR(20) NOT NULL,
  `email` VARCHAR(120) NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_customer_mobile` (`mobile_number`),
  INDEX `idx_customer_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. Services Table
CREATE TABLE IF NOT EXISTS `services` (
  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `service_name` VARCHAR(100) NOT NULL UNIQUE,
  `description` TEXT NULL,
  `average_service_minutes` INT UNSIGNED NOT NULL DEFAULT 15,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. Requests Table
CREATE TABLE IF NOT EXISTS `requests` (
  `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `request_code` VARCHAR(40) NOT NULL UNIQUE,
  `customer_id` INT UNSIGNED NOT NULL,
  `service_id` INT UNSIGNED NOT NULL,
  `branch_name` VARCHAR(120) NULL,
  `subject` VARCHAR(250) NOT NULL,
  `description` TEXT NOT NULL,
  `status` ENUM('Waiting', 'Serving', 'Completed', 'Cancelled') NOT NULL DEFAULT 'Waiting',
  `priority` ENUM('Low', 'Normal', 'High') NOT NULL DEFAULT 'Normal',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `completed_at` TIMESTAMP NULL DEFAULT NULL,
  FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`service_id`) REFERENCES `services` (`id`) ON DELETE RESTRICT,
  INDEX `idx_req_status` (`status`),
  INDEX `idx_req_service` (`service_id`),
  INDEX `idx_req_created` (`created_at`),
  INDEX `idx_req_customer` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. Tokens Table
CREATE TABLE IF NOT EXISTS `tokens` (
  `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `request_id` BIGINT UNSIGNED NOT NULL UNIQUE,
  `token_number` VARCHAR(50) NOT NULL UNIQUE,
  `queue_date` DATE NOT NULL,
  `queue_position` INT UNSIGNED NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`request_id`) REFERENCES `requests` (`id`) ON DELETE CASCADE,
  INDEX `idx_token_number` (`token_number`),
  INDEX `idx_queue_date` (`queue_date`),
  INDEX `idx_queue_position` (`queue_position`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6. Status History Table
CREATE TABLE IF NOT EXISTS `status_history` (
  `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `request_id` BIGINT UNSIGNED NOT NULL,
  `old_status` VARCHAR(30) NULL,
  `new_status` VARCHAR(30) NOT NULL,
  `changed_by_admin_id` INT UNSIGNED NULL DEFAULT NULL,
  `note` VARCHAR(500) NULL,
  `changed_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`request_id`) REFERENCES `requests` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`changed_by_admin_id`) REFERENCES `admins` (`id`) ON DELETE SET NULL,
  INDEX `idx_sh_request` (`request_id`),
  INDEX `idx_sh_changed_at` (`changed_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 7. Notifications Table
CREATE TABLE IF NOT EXISTS `notifications` (
  `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `customer_id` INT UNSIGNED NOT NULL,
  `request_id` BIGINT UNSIGNED NOT NULL,
  `title` VARCHAR(160) NOT NULL,
  `message` TEXT NOT NULL,
  `is_read` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  FOREIGN KEY (`request_id`) REFERENCES `requests` (`id`) ON DELETE CASCADE,
  INDEX `idx_notif_customer` (`customer_id`),
  INDEX `idx_notif_read` (`is_read`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 8. Feedback Table
CREATE TABLE IF NOT EXISTS `feedback` (
  `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `request_id` BIGINT UNSIGNED NOT NULL UNIQUE,
  `rating` TINYINT UNSIGNED NOT NULL,
  `comments` TEXT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`request_id`) REFERENCES `requests` (`id`) ON DELETE CASCADE,
  INDEX `idx_fb_rating` (`rating`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================================
-- Seed Default Services
-- ============================================================================
INSERT INTO `services` (`id`, `service_name`, `description`, `average_service_minutes`, `is_active`)
VALUES
  (1, 'Hospital', 'Healthcare inquiries, OPD registration, doctor consultation queues, and diagnostic reports', 15, 1),
  (2, 'School / College', 'Admissions, student document verification, scholarship desks, and fee queries', 10, 1),
  (3, 'Government Office', 'Citizen certificates, licensing, municipal clearance, and public grievance desks', 20, 1),
  (4, 'Banking', 'Account openings, loan consultations, forex services, and cash desk token assistance', 12, 1),
  (5, 'Customer Service', 'Hardware/software tech support, warranty replacements, and service ticketing', 8, 1),
  (6, 'Other Services', 'General utility helpdesk, front office queries, and customized administrative queues', 15, 1)
ON DUPLICATE KEY UPDATE
  `description` = VALUES(`description`),
  `average_service_minutes` = VALUES(`average_service_minutes`);

-- ============================================================================
-- Seed Default Administrator
-- Username: admin
-- Password: Admin@12345
-- Verified with password_hash('Admin@12345', PASSWORD_BCRYPT)
-- ============================================================================
INSERT INTO `admins` (`id`, `name`, `username`, `email`, `password_hash`, `role`, `is_active`)
VALUES
  (1, 'Lead Queue Officer', 'admin', 'admin@queueless.local', '$2y$10$/A4fSsVa6uG6dwF63TeNQuvkK5AVJSalJ06ChOpuwzlwQGp7NAHB.', 'superadmin', 1)
ON DUPLICATE KEY UPDATE
  `name` = VALUES(`name`),
  `password_hash` = VALUES(`password_hash`);

-- ============================================================================
-- Seed Demo Customer and Requests (for immediate live demo & presentation)
-- ============================================================================
INSERT INTO `customers` (`id`, `full_name`, `mobile_number`, `email`)
VALUES
  (1, 'Aarav Sharma', '9876543210', 'aarav.sharma@example.com'),
  (2, 'Priya Patel', '9812345678', 'priya.patel@example.com'),
  (3, 'Rohan Verma', '9898989898', 'rohan.verma@example.com'),
  (4, 'Sneha Kulkarni', '9765432109', 'sneha.k@example.com')
ON DUPLICATE KEY UPDATE `full_name` = VALUES(`full_name`);

-- Insert Sample Requests
INSERT INTO `requests` (`id`, `request_code`, `customer_id`, `service_id`, `branch_name`, `subject`, `description`, `status`, `priority`, `created_at`)
VALUES
  (1, 'REQ-20261010-001', 1, 1, 'Central Hospital - OPD 2', 'Consultation with Orthopedic Specialist', 'Patient experiencing knee joint pain following sports activity. Requires initial physical evaluation and x-ray prescription.', 'Serving', 'High', DATE_SUB(NOW(), INTERVAL 45 MINUTE)),
  (2, 'REQ-20261010-002', 2, 4, 'Downtown Branch', 'Current Account Opening & KYC Update', 'Requesting digital verification and submitting GST documents for a newly registered IT consultancy firm.', 'Waiting', 'Normal', DATE_SUB(NOW(), INTERVAL 30 MINUTE)),
  (3, 'REQ-20261010-003', 3, 2, 'Main Campus Admin Wing', 'Semester Grade Sheet Attestation', 'Final year engineering graduate needing official transcripts and university stamp for higher studies application.', 'Waiting', 'Normal', DATE_SUB(NOW(), INTERVAL 15 MINUTE)),
  (4, 'REQ-20261010-004', 4, 3, 'City Civic Center', 'Domicile Certificate Verification', 'Submitting domicile and identity proofs for state competitive examination eligibility verification.', 'Completed', 'Normal', DATE_SUB(NOW(), INTERVAL 90 MINUTE))
ON DUPLICATE KEY UPDATE `subject` = VALUES(`subject`);

-- Insert Sample Tokens
INSERT INTO `tokens` (`id`, `request_id`, `token_number`, `queue_date`, `queue_position`, `created_at`)
VALUES
  (1, 1, 'QL-20261010-0001', CURRENT_DATE(), 1, DATE_SUB(NOW(), INTERVAL 45 MINUTE)),
  (2, 2, 'QL-20261010-0002', CURRENT_DATE(), 1, DATE_SUB(NOW(), INTERVAL 30 MINUTE)),
  (3, 3, 'QL-20261010-0003', CURRENT_DATE(), 2, DATE_SUB(NOW(), INTERVAL 15 MINUTE)),
  (4, 4, 'QL-20261010-0004', CURRENT_DATE(), 0, DATE_SUB(NOW(), INTERVAL 90 MINUTE))
ON DUPLICATE KEY UPDATE `token_number` = VALUES(`token_number`);

-- Insert Sample Status History
INSERT INTO `status_history` (`request_id`, `old_status`, `new_status`, `changed_by_admin_id`, `note`, `changed_at`)
VALUES
  (1, NULL, 'Waiting', NULL, 'Token generated online by customer', DATE_SUB(NOW(), INTERVAL 45 MINUTE)),
  (1, 'Waiting', 'Serving', 1, 'Customer called to Desk 01 for consultation', DATE_SUB(NOW(), INTERVAL 10 MINUTE)),
  (2, NULL, 'Waiting', NULL, 'Token generated online by customer', DATE_SUB(NOW(), INTERVAL 30 MINUTE)),
  (3, NULL, 'Waiting', NULL, 'Token generated online by customer', DATE_SUB(NOW(), INTERVAL 15 MINUTE)),
  (4, NULL, 'Waiting', NULL, 'Token generated online by customer', DATE_SUB(NOW(), INTERVAL 90 MINUTE)),
  (4, 'Waiting', 'Serving', 1, 'Called for document verification', DATE_SUB(NOW(), INTERVAL 60 MINUTE)),
  (4, 'Serving', 'Completed', 1, 'Documents verified and attested successfully', DATE_SUB(NOW(), INTERVAL 40 MINUTE));

-- Insert Sample Feedback for Request 4
INSERT INTO `feedback` (`request_id`, `rating`, `comments`, `created_at`)
VALUES
  (4, 5, 'Super smooth experience! No waiting in the sun, got my certificate attested in 10 minutes.', DATE_SUB(NOW(), INTERVAL 35 MINUTE))
ON DUPLICATE KEY UPDATE `rating` = VALUES(`rating`);
