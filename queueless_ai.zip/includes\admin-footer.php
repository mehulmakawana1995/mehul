<?php
/**
 * QueueLess AI — Admin Layout Footer & Global Modals
 */
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/csrf.php';
?>
        </main>
    </div>

    <!-- Quick Status Transition Modal -->
    <div id="statusUpdateModal" class="modal-overlay">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Update Queue Request Status</h3>
                <button type="button" id="closeStatusModal" class="modal-close-btn">&times;</button>
            </div>
            <form id="statusUpdateForm" method="POST" action="<?php echo BASE_URL; ?>/admin/queue.php">
                <?php echo csrfField(); ?>
                <input type="hidden" name="action" value="update_status">
                <input type="hidden" name="request_id" id="modalRequestId" value="">
                <input type="hidden" name="new_status" id="modalTargetStatus" value="">

                <div style="margin-bottom: 18px; padding: 12px; background: rgba(255, 255, 255, 0.04); border-radius: var(--radius-sm); border: 1px solid var(--admin-card-border);">
                    <div style="font-size: 13px; color: var(--text-dim); margin-bottom: 4px;">Target Request Token:</div>
                    <div id="modalTokenBadge" style="font-size: 18px; font-weight: 800; color: #38bdf8; font-family: monospace;">—</div>
                    <div style="margin-top: 8px; font-size: 13px; color: var(--text-muted);">
                        Transitioning status to: <strong id="modalStatusText" style="color: #fff; text-transform: uppercase;">—</strong>
                    </div>
                </div>

                <div class="form-group">
                    <label for="adminStatusNote">Audit Note / Desk Remark (Optional):</label>
                    <textarea name="note" id="adminStatusNote" class="form-control" placeholder="e.g. Desk 02 called customer, documents verified, or issue resolved." rows="3"></textarea>
                </div>

                <div class="modal-footer">
                    <button type="button" id="cancelStatusModal" class="btn btn-secondary btn-sm">Cancel</button>
                    <button type="submit" class="btn btn-primary btn-sm">Confirm Status Change</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Admin Client Scripts -->
    <script src="<?php echo BASE_URL; ?>/assets/js/admin.js"></script>
</body>
</html>
