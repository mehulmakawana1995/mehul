<?php
/**
 * QueueLess AI — Comprehensive Request Inspection & Audit Details
 */

$adminTitle = "Request Audit Details";
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/functions.php';

$pdo = getDB();
$admin = getCurrentAdmin();
$requestId = (int)($_GET['id'] ?? 0);

if ($requestId <= 0) {
    setFlash('error', 'Invalid Request ID.');
    header('Location: ' . BASE_URL . '/admin/requests.php');
    exit;
}

// Fetch complete request record
$stmt = $pdo->prepare("
    SELECT 
        r.id, r.request_code, r.subject, r.description, r.status, r.priority, r.branch_name,
        r.created_at, r.updated_at, r.completed_at,
        c.id AS customer_id, c.full_name, c.mobile_number, c.email, c.created_at AS customer_since,
        s.id AS service_id, s.service_name, s.average_service_minutes,
        t.id AS token_id, t.token_number, t.queue_date, t.queue_position
    FROM requests r
    JOIN customers c ON c.id = r.customer_id
    JOIN services s ON s.id = r.service_id
    LEFT JOIN tokens t ON t.request_id = r.id
    WHERE r.id = :id
    LIMIT 1
");
$stmt->execute(['id' => $requestId]);
$req = $stmt->fetch();

if (!$req) {
    setFlash('error', 'Request not found in database.');
    header('Location: ' . BASE_URL . '/admin/requests.php');
    exit;
}

// Fetch status history audit log
$histStmt = $pdo->prepare("
    SELECT sh.old_status, sh.new_status, sh.note, sh.changed_at, a.name AS admin_name, a.username
    FROM status_history sh
    LEFT JOIN admins a ON a.id = sh.changed_by_admin_id
    WHERE sh.request_id = :rid
    ORDER BY sh.changed_at ASC, sh.id ASC
");
$histStmt->execute(['rid' => $requestId]);
$history = $histStmt->fetchAll();

// Fetch feedback if any
$fbStmt = $pdo->prepare("SELECT rating, comments, created_at FROM feedback WHERE request_id = :rid LIMIT 1");
$fbStmt->execute(['rid' => $requestId]);
$feedback = $fbStmt->fetch();

// Fetch customer lifetime request count
$countStmt = $pdo->prepare("SELECT COUNT(*) FROM requests WHERE customer_id = :cid");
$countStmt->execute(['cid' => $req['customer_id']]);
$customerLifetimeCount = (int)$countStmt->fetchColumn();

require_once __DIR__ . '/../includes/admin-header.php';
?>

<!-- Top Action Header -->
<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; flex-wrap: wrap; gap: 14px;">
    <div>
        <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 6px;">
            <a href="<?php echo BASE_URL; ?>/admin/requests.php" class="btn btn-secondary btn-sm" title="Back to Requests">
                &larr; Back
            </a>
            <span class="table-token-badge" style="font-size: 20px; padding: 6px 14px;">
                <?php echo htmlspecialchars($req['token_number'] ?? 'NO-TOKEN'); ?>
            </span>
            <?php echo getStatusBadge($req['status']); ?>
        </div>
        <div style="font-size: 13px; color: var(--text-dim);">
            Request Code: <code><?php echo htmlspecialchars($req['request_code']); ?></code> &bull; Submitted <?php echo formatDateTime($req['created_at']); ?>
        </div>
    </div>

    <!-- Quick Status Change Action Bar -->
    <div style="display: flex; gap: 8px; flex-wrap: wrap;">
        <?php if ($req['status'] === 'Waiting'): ?>
            <button type="button" class="btn btn-primary btn-sm" onclick="openStatusModal(<?php echo $req['id']; ?>, 'Waiting', 'Serving', '<?php echo htmlspecialchars($req['token_number']); ?>');">
                <i class="fa-solid fa-headset"></i> Call to Desk (Serve)
            </button>
            <button type="button" class="btn btn-secondary btn-sm" style="color: var(--rose);" onclick="openStatusModal(<?php echo $req['id']; ?>, 'Waiting', 'Cancelled', '<?php echo htmlspecialchars($req['token_number']); ?>');">
                <i class="fa-solid fa-ban"></i> Cancel Request
            </button>
        <?php elseif ($req['status'] === 'Serving'): ?>
            <button type="button" class="btn btn-primary btn-sm" onclick="openStatusModal(<?php echo $req['id']; ?>, 'Serving', 'Completed', '<?php echo htmlspecialchars($req['token_number']); ?>');">
                <i class="fa-solid fa-check"></i> Mark Completed
            </button>
            <button type="button" class="btn btn-secondary btn-sm" onclick="openStatusModal(<?php echo $req['id']; ?>, 'Serving', 'Waiting', '<?php echo htmlspecialchars($req['token_number']); ?>');">
                <i class="fa-solid fa-rotate-left"></i> Return to Waiting
            </button>
            <button type="button" class="btn btn-secondary btn-sm" style="color: var(--rose);" onclick="openStatusModal(<?php echo $req['id']; ?>, 'Serving', 'Cancelled', '<?php echo htmlspecialchars($req['token_number']); ?>');">
                <i class="fa-solid fa-ban"></i> Cancel Request
            </button>
        <?php elseif ($req['status'] === 'Completed' || $req['status'] === 'Cancelled'): ?>
            <button type="button" class="btn btn-secondary btn-sm" onclick="openStatusModal(<?php echo $req['id']; ?>, '<?php echo $req['status']; ?>', 'Waiting', '<?php echo htmlspecialchars($req['token_number']); ?>');">
                <i class="fa-solid fa-arrows-rotate"></i> Reopen into Waiting Queue
            </button>
        <?php endif; ?>
    </div>
</div>

<div style="display: grid; grid-template-columns: 2fr 1fr; gap: 24px;">
    <!-- Left Column: Inquiry & Audit Details -->
    <div>
        <!-- Query Subject and Details Card -->
        <div class="card-box" style="margin-bottom: 24px;">
            <div class="card-box-header">
                <h3><i class="fa-solid fa-file-lines"></i> Inquiry Details</h3>
                <span style="font-size: 13px; color: var(--text-dim);"><?php echo htmlspecialchars($req['service_name']); ?></span>
            </div>

            <div style="margin-bottom: 20px;">
                <div style="font-size: 12px; color: var(--text-dim); text-transform: uppercase; margin-bottom: 4px;">Subject</div>
                <div style="font-size: 18px; font-weight: 700; color: #fff; margin-bottom: 16px;">
                    <?php echo htmlspecialchars($req['subject']); ?>
                </div>

                <div style="font-size: 12px; color: var(--text-dim); text-transform: uppercase; margin-bottom: 4px;">Detailed Query / Problem Description</div>
                <div style="background: rgba(255, 255, 255, 0.03); border: 1px solid var(--admin-card-border); border-radius: var(--radius-sm); padding: 18px; color: #e2e8f0; font-size: 14px; line-height: 1.6; white-space: pre-wrap;">
                    <?php echo htmlspecialchars($req['description']); ?>
                </div>
            </div>

            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 14px; padding-top: 16px; border-top: 1px solid var(--admin-card-border); font-size: 13px;">
                <div>
                    <span style="color: var(--text-dim); display: block;">Service Department:</span>
                    <strong style="color: #38bdf8;"><?php echo htmlspecialchars($req['service_name']); ?></strong>
                </div>
                <div>
                    <span style="color: var(--text-dim); display: block;">Specific Branch / Desk:</span>
                    <strong style="color: #fff;"><?php echo htmlspecialchars($req['branch_name'] ?? 'General Helpdesk'); ?></strong>
                </div>
                <div>
                    <span style="color: var(--text-dim); display: block;">Avg Service Duration:</span>
                    <strong style="color: #fff;">~<?php echo $req['average_service_minutes']; ?> minutes</strong>
                </div>
            </div>
        </div>

        <!-- Status History Audit Trail Card -->
        <div class="card-box">
            <div class="card-box-header">
                <h3><i class="fa-solid fa-clock-rotate-left"></i> Status Transition History (Audit Log)</h3>
                <span style="font-size: 12px; color: var(--text-dim);"><?php echo count($history); ?> Event(s)</span>
            </div>

            <div class="table-responsive">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Timestamp</th>
                            <th>Transition</th>
                            <th>Action By</th>
                            <th>Desk Notes / Reason</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($history)): ?>
                            <?php foreach ($history as $h): ?>
                                <tr>
                                    <td style="color: var(--text-dim); font-size: 13px; white-space: nowrap;">
                                        <?php echo formatDateTime($h['changed_at']); ?>
                                    </td>
                                    <td>
                                        <?php if ($h['old_status']): ?>
                                            <?php echo getStatusBadge($h['old_status']); ?> &rarr;
                                        <?php endif; ?>
                                        <?php echo getStatusBadge($h['new_status']); ?>
                                    </td>
                                    <td style="color: #cbd5e1; font-size: 13px;">
                                        <?php echo htmlspecialchars($h['admin_name'] ?? 'System / Online'); ?>
                                    </td>
                                    <td style="color: var(--text-muted); font-size: 13px;">
                                        <?php echo htmlspecialchars($h['note'] ?? 'No remark entered'); ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="4" style="text-align: center; color: var(--text-dim);">No status history recorded.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Right Column: Customer Info & Feedback -->
    <div>
        <!-- Customer Profile Card -->
        <div class="card-box" style="margin-bottom: 24px;">
            <div class="card-box-header">
                <h3><i class="fa-solid fa-user"></i> Customer Profile</h3>
                <span class="badge-pill" style="font-size: 11px; color: var(--cyan);">ID #<?php echo $req['customer_id']; ?></span>
            </div>

            <div style="text-align: center; margin-bottom: 20px;">
                <div style="width: 56px; height: 56px; border-radius: 50%; background: linear-gradient(135deg, var(--primary), var(--cyan)); display: inline-flex; align-items: center; justify-content: center; font-size: 22px; font-weight: 700; color: #fff; margin-bottom: 10px;">
                    <?php echo strtoupper(substr($req['full_name'], 0, 1)); ?>
                </div>
                <div style="font-size: 18px; font-weight: 700; color: #fff;"><?php echo htmlspecialchars($req['full_name']); ?></div>
                <div style="font-size: 13px; color: var(--text-dim);">First Registered <?php echo formatDateTime($req['customer_since'], false); ?></div>
            </div>

            <div style="display: flex; flex-direction: column; gap: 12px; font-size: 14px;">
                <div style="display: flex; justify-content: space-between; padding-bottom: 8px; border-bottom: 1px solid var(--admin-card-border);">
                    <span style="color: var(--text-dim);"><i class="fa-solid fa-phone"></i> Mobile:</span>
                    <strong style="color: #38bdf8; font-family: monospace;"><?php echo htmlspecialchars($req['mobile_number']); ?></strong>
                </div>

                <div style="display: flex; justify-content: space-between; padding-bottom: 8px; border-bottom: 1px solid var(--admin-card-border);">
                    <span style="color: var(--text-dim);"><i class="fa-solid fa-envelope"></i> Email:</span>
                    <strong><?php echo !empty($req['email']) ? htmlspecialchars($req['email']) : 'Not provided'; ?></strong>
                </div>

                <div style="display: flex; justify-content: space-between; padding-bottom: 8px; border-bottom: 1px solid var(--admin-card-border);">
                    <span style="color: var(--text-dim);"><i class="fa-solid fa-list-check"></i> Lifetime Requests:</span>
                    <strong><?php echo $customerLifetimeCount; ?> request(s)</strong>
                </div>
            </div>

            <div style="margin-top: 18px;">
                <a href="<?php echo BASE_URL; ?>/admin/requests.php?search=<?php echo urlencode($req['mobile_number']); ?>" class="btn btn-secondary btn-block btn-sm">
                    <i class="fa-solid fa-clock-rotate-left"></i> View All Requests for Customer
                </a>
            </div>
        </div>

        <!-- Feedback Card (if submitted) -->
        <div class="card-box">
            <div class="card-box-header">
                <h3><i class="fa-solid fa-star"></i> Customer Feedback</h3>
            </div>

            <?php if ($feedback): ?>
                <div style="text-align: center; margin-bottom: 14px;">
                    <div style="font-size: 28px; color: #fbbf24; margin-bottom: 6px;">
                        <?php for ($i = 1; $i <= 5; $i++): ?>
                            <i class="fa-solid fa-star" style="color: <?php echo $i <= $feedback['rating'] ? '#fbbf24' : 'rgba(255,255,255,0.1)'; ?>;"></i>
                        <?php endfor; ?>
                    </div>
                    <div style="font-size: 16px; font-weight: 700; color: #fff;">
                        <?php echo $feedback['rating']; ?> / 5 Stars
                    </div>
                    <div style="font-size: 12px; color: var(--text-dim);">
                        Submitted <?php echo formatDateTime($feedback['created_at']); ?>
                    </div>
                </div>

                <?php if (!empty($feedback['comments'])): ?>
                    <div style="background: rgba(255,255,255,0.03); border: 1px solid var(--admin-card-border); border-radius: var(--radius-sm); padding: 14px; font-size: 13px; font-style: italic; color: #cbd5e1;">
                        "<?php echo htmlspecialchars($feedback['comments']); ?>"
                    </div>
                <?php endif; ?>
            <?php else: ?>
                <p style="color: var(--text-dim); font-size: 13px; text-align: center; padding: 20px 0;">
                    No feedback has been submitted for this request yet.
                </p>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/admin-footer.php'; ?>
