<?php
/**
 * QueueLess AI — Admin Account Provisioning & Setup Utility
 * Supports both Web Interface & CLI execution
 */

require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/csrf.php';
require_once __DIR__ . '/includes/functions.php';

$pdo = getDB();

// CLI Mode Execution Support
if (php_sapi_name() === 'cli') {
    echo "=== QueueLess AI Admin Provisioning CLI ===\n";
    $username = $argv[1] ?? 'admin';
    $password = $argv[2] ?? 'Admin@12345';
    $name = $argv[3] ?? 'Lead Queue Officer';
    $role = $argv[4] ?? 'superadmin';

    $hash = password_hash($password, PASSWORD_BCRYPT);
    $stmt = $pdo->prepare("
        INSERT INTO admins (name, username, email, password_hash, role, is_active, created_at)
        VALUES (:n, :u, :e, :h, :r, 1, NOW())
        ON DUPLICATE KEY UPDATE name = :n, password_hash = :h, role = :r, is_active = 1
    ");
    $stmt->execute([
        'n' => $name,
        'u' => $username,
        'e' => $username . '@queueless.local',
        'h' => $hash,
        'r' => $role
    ]);
    echo "SUCCESS: Admin '{$username}' created/updated successfully with password '{$password}'.\n";
    exit(0);
}

// Web Mode Execution
$pageTitle = "Admin Provisioning Setup";
$message = null;
$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrfToken = $_POST['csrf_token'] ?? '';
    if (!verifyCsrfToken($csrfToken)) {
        $error = 'Invalid security token. Please refresh the page.';
    } else {
        $name = trim($_POST['name'] ?? '');
        $username = trim($_POST['username'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $password = trim($_POST['password'] ?? '');
        $role = trim($_POST['role'] ?? 'admin');

        if (empty($name) || empty($username) || empty($password)) {
            $error = 'Name, Username, and Password are all required.';
        } elseif (strlen($password) < 6) {
            $error = 'Password must be at least 6 characters.';
        } else {
            try {
                $hash = password_hash($password, PASSWORD_BCRYPT);
                $stmt = $pdo->prepare("
                    INSERT INTO admins (name, username, email, password_hash, role, is_active, created_at)
                    VALUES (:n, :u, :e, :h, :r, 1, NOW())
                    ON DUPLICATE KEY UPDATE name = :n, email = :e, password_hash = :h, role = :r, is_active = 1
                ");
                $stmt->execute([
                    'n' => $name,
                    'u' => $username,
                    'e' => !empty($email) ? $email : null,
                    'h' => $hash,
                    'r' => in_array($role, ['superadmin', 'admin', 'operator']) ? $role : 'admin'
                ]);

                $message = "Admin user '<strong>" . htmlspecialchars($username) . "</strong>' was created/updated successfully! You can now log in.";
            } catch (Exception $e) {
                $error = 'Database Error: ' . $e->getMessage();
            }
        }
    }
}

// Fetch list of current admins
$admins = $pdo->query("SELECT id, name, username, email, role, is_active, created_at FROM admins ORDER BY id ASC")->fetchAll();

require_once __DIR__ . '/includes/header.php';
?>

<div class="container section-padding" style="padding-top: 40px;">
    <div style="max-width: 760px; margin: 0 auto;">

        <div style="text-align: center; margin-bottom: 30px;">
            <span class="section-tag">System Initialization</span>
            <h1 style="font-size: 32px; margin-bottom: 10px;">Admin <span class="text-gradient">Provisioning</span> Utility</h1>
            <p style="color: var(--text-muted); font-size: 14px;">
                Use this setup interface to create, reset, or provision admin credentials for QueueLess AI.
            </p>
        </div>

        <div style="background: rgba(245, 158, 11, 0.1); border: 1px solid rgba(245, 158, 11, 0.3); border-radius: var(--radius-md); padding: 16px; margin-bottom: 24px; font-size: 13px; color: #fbbf24;">
            <i class="fa-solid fa-triangle-exclamation"></i>
            <strong>Security Notice:</strong> In a production environment outside of local evaluation, delete or restrict access to <code>create-admin.php</code> to prevent unauthorized account creation.
        </div>

        <?php if ($message): ?>
            <div class="alert-box alert-success">
                <i class="fa-solid fa-circle-check"></i>
                <span><?php echo $message; ?></span>
            </div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="alert-box alert-error">
                <i class="fa-solid fa-triangle-exclamation"></i>
                <span><?php echo htmlspecialchars($error); ?></span>
            </div>
        <?php endif; ?>

        <div class="form-card" style="margin-bottom: 36px;">
            <h3 style="font-size: 18px; margin-bottom: 20px;">Provision / Reset Administrator</h3>
            <form method="POST" action="<?php echo BASE_URL; ?>/create-admin.php">
                <?php echo csrfField(); ?>

                <div class="form-row">
                    <div class="form-group">
                        <label for="admin_name">Officer Full Name <span class="required">*</span></label>
                        <input type="text" id="admin_name" name="name" class="form-control" placeholder="e.g. Lead Queue Officer" value="Lead Queue Officer" required>
                    </div>
                    <div class="form-group">
                        <label for="admin_username">Login Username <span class="required">*</span></label>
                        <input type="text" id="admin_username" name="username" class="form-control" placeholder="e.g. admin" value="admin" required>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="admin_email">Email Address (Optional)</label>
                        <input type="email" id="admin_email" name="email" class="form-control" placeholder="e.g. admin@queueless.local" value="admin@queueless.local">
                    </div>
                    <div class="form-group">
                        <label for="admin_role">Administrative Role</label>
                        <select id="admin_role" name="role" class="form-control">
                            <option value="superadmin">Super Admin (Full System Access)</option>
                            <option value="admin" selected>Queue Admin (Desk Operations)</option>
                            <option value="operator">Desk Operator (Call & Complete only)</option>
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label for="admin_pass">Password <span class="required">*</span></label>
                    <input type="text" id="admin_pass" name="password" class="form-control" placeholder="Enter secure password" value="Admin@12345" required>
                    <span class="form-text">Will be encrypted using PHP <code>password_hash()</code> with BCRYPT.</span>
                </div>

                <div style="display: flex; gap: 16px; margin-top: 24px;">
                    <button type="submit" class="btn btn-primary">
                        <i class="fa-solid fa-user-shield"></i> Save Administrator
                    </button>
                    <a href="<?php echo BASE_URL; ?>/admin-login.php" class="btn btn-secondary">
                        <i class="fa-solid fa-right-to-bracket"></i> Go To Admin Login
                    </a>
                </div>
            </form>
        </div>

        <!-- Current Registered Admins Table -->
        <div class="card-box">
            <h3 style="font-size: 16px; margin-bottom: 16px;"><i class="fa-solid fa-users-gear"></i> Existing Administrators in Database</h3>
            <div class="table-responsive">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Officer Name</th>
                            <th>Username</th>
                            <th>Role</th>
                            <th>Status</th>
                            <th>Registered</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($admins as $adm): ?>
                            <tr>
                                <td>#<?php echo $adm['id']; ?></td>
                                <td><strong style="color: #fff;"><?php echo htmlspecialchars($adm['name']); ?></strong></td>
                                <td><code><?php echo htmlspecialchars($adm['username']); ?></code></td>
                                <td><span class="badge-pill" style="color: var(--cyan); text-transform: uppercase; font-size: 11px;"><?php echo htmlspecialchars($adm['role']); ?></span></td>
                                <td>
                                    <?php if ($adm['is_active']): ?>
                                        <span style="color: var(--success); font-size: 12px;"><i class="fa-solid fa-circle-check"></i> Active</span>
                                    <?php else: ?>
                                        <span style="color: var(--danger); font-size: 12px;"><i class="fa-solid fa-circle-xmark"></i> Disabled</span>
                                    <?php endif; ?>
                                </td>
                                <td style="color: var(--text-dim); font-size: 12px;"><?php echo formatDateTime($adm['created_at']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
